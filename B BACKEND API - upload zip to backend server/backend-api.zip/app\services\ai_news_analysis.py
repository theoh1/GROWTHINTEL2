from __future__ import annotations

from datetime import datetime, timezone


BULLISH_KEYWORDS = (
    "beat",
    "raises",
    "record",
    "growth",
    "surge",
    "upgrade",
    "breakout",
    "new high",
    "strong demand",
)
BEARISH_KEYWORDS = (
    "miss",
    "cuts",
    "downgrade",
    "probe",
    "lawsuit",
    "warning",
    "recall",
    "decline",
    "weak demand",
)


def classify_impact(headline: str, summary: str) -> str:
    blob = f"{headline} {summary}".lower()
    bullish_hits = sum(1 for keyword in BULLISH_KEYWORDS if keyword in blob)
    bearish_hits = sum(1 for keyword in BEARISH_KEYWORDS if keyword in blob)
    if bullish_hits > bearish_hits:
        return "bullish"
    if bearish_hits > bullish_hits:
        return "bearish"
    return "neutral"


def canslim_tags(headline: str, summary: str) -> list[str]:
    blob = f"{headline} {summary}".lower()
    tags: list[str] = []
    if any(token in blob for token in ("earnings", "eps", "revenue", "margin", "guidance")):
        tags.append("C")
    if any(token in blob for token in ("launch", "new product", "new service", "ceo", "cfo", "management")):
        tags.append("N")
    if any(token in blob for token in ("nasdaq", "s&p", "fed", "market", "macro", "rate")):
        tags.append("M")
    return tags or ["M"]


def ai_summary(headline: str, summary: str, impact: str) -> str:
    tone = {"bullish": "constructive", "bearish": "cautious", "neutral": "balanced"}[impact]
    seed = summary.strip() or headline.strip()
    seed = seed.replace("\n", " ").strip()
    if len(seed) > 180:
        seed = f"{seed[:177]}..."
    return f"{seed} The near-term signal reads {tone} for momentum-focused CANSLIM workflows."


def time_ago_iso(published_at: datetime | None) -> str:
    if published_at is None:
        return "unknown"
    now = datetime.now(timezone.utc)
    delta = max(now - published_at, now - now)
    minutes = int(delta.total_seconds() // 60)
    if minutes < 1:
        return "just now"
    if minutes < 60:
        return f"{minutes}m ago"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h ago"
    days = hours // 24
    return f"{days}d ago"
