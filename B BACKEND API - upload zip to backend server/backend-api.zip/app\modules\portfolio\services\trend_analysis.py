from __future__ import annotations

from typing import Any


def _linear_regression_prediction(values: list[float]) -> float:
    n = len(values)
    if n < 2:
        return values[-1] if values else 0.0
    x_mean = (n - 1) / 2
    y_mean = sum(values) / n
    numerator = 0.0
    denominator = 0.0
    for idx, value in enumerate(values):
        dx = idx - x_mean
        numerator += dx * (value - y_mean)
        denominator += dx * dx
    slope = numerator / denominator if denominator else 0.0
    intercept = y_mean - (slope * x_mean)
    return intercept + slope * (n - 1)


def analyze_trend(closes: list[float], volumes: list[float], current_price: float, thresholds: dict[str, Any]) -> list[dict]:
    alerts: list[dict] = []
    if len(closes) < 60:
        return alerts

    ma21 = sum(closes[-21:]) / 21
    ma50 = sum(closes[-50:]) / 50
    ma50_prev = sum(closes[-55:-5]) / 50 if len(closes) >= 55 else ma50
    trendline_prediction = _linear_regression_prediction(closes[-30:])
    trendline_break = current_price < trendline_prediction * 0.985

    if current_price < ma21:
        alerts.append(
            {
                "alert_type": "Trend Weakening",
                "message": "Price moved below the 21-day moving average.",
                "severity": "yellow",
                "code": "below_ma21",
            }
        )
    if current_price < ma50:
        alerts.append(
            {
                "alert_type": "Trend Breakdown",
                "message": "Price moved below the 50-day moving average.",
                "severity": "red",
                "code": "below_ma50",
            }
        )
    if ma50 < ma50_prev:
        alerts.append(
            {
                "alert_type": "Trend Weakening",
                "message": "50-day moving average has turned down.",
                "severity": "yellow",
                "code": "ma50_down",
            }
        )
    if trendline_break:
        volume_confirmation = False
        if len(volumes) >= 20:
            avg_vol = sum(volumes[-20:]) / 20
            volume_confirmation = volumes[-1] > avg_vol
        alerts.append(
            {
                "alert_type": "Trend Breakdown",
                "message": "Price broke below the short-term uptrend line." + (" Volume confirms weakness." if volume_confirmation else ""),
                "severity": "red" if volume_confirmation else "yellow",
                "code": "trendline_break",
            }
        )

    return alerts
