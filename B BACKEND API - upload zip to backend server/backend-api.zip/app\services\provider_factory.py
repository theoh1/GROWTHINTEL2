from app.core.config import get_settings
from app.services.alpha_vantage_provider import AlphaVantageProvider
from app.services.providers import MarketDataProvider, NewsSignalProvider
from app.services.yahoo_finance_provider import YahooFinanceProvider


def build_market_provider() -> MarketDataProvider:
    settings = get_settings()
    if not settings.alpha_vantage_api_key:
        return YahooFinanceProvider()
    return AlphaVantageProvider(
        api_key=settings.alpha_vantage_api_key,
        rate_limit_per_minute=settings.alpha_vantage_rate_limit_per_minute,
    )


def build_news_provider() -> NewsSignalProvider:
    return NullNewsProvider()


class NullNewsProvider(NewsSignalProvider):
    async def enrich(self, stocks: list[dict]) -> list[dict]:
        return stocks
