from abc import ABC, abstractmethod


class MarketDataProvider(ABC):
    @abstractmethod
    async def fetch_market_overview(self) -> list[dict]:
        raise NotImplementedError

    @abstractmethod
    async def fetch_stock_universe(self, tickers: list[str] | None = None) -> list[dict]:
        raise NotImplementedError


class NewsSignalProvider(ABC):
    @abstractmethod
    async def enrich(self, stocks: list[dict]) -> list[dict]:
        raise NotImplementedError
