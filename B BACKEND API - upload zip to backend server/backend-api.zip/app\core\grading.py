def numeric_to_grade(score: float) -> str:
    if score >= 90:
        return "A+"
    if score >= 84:
        return "A"
    if score >= 78:
        return "A-"
    if score >= 72:
        return "B+"
    if score >= 66:
        return "B"
    if score >= 60:
        return "B-"
    if score >= 54:
        return "C+"
    if score >= 48:
        return "C"
    if score >= 42:
        return "C-"
    if score >= 34:
        return "D"
    return "F"
