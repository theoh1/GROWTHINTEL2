from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

import yfinance as yf

from app.services.ai_news_analysis import ai_summary, canslim_tags, classify_impact


def _extract_earnings_event(symbol: str) -> dict | None:
    try:
        ticker = yf.Ticker(symbol)
        calendar = ticker.calendar
        if calendar is None or calendar.empty:
            return None
        value = calendar.iloc[0, 0]
        event_date: datetime | None = None
        if hasattr(value, "to_pydatetime"):
            event_date = value.to_pydatetime().replace(tzinfo=timezone.utc)
        elif isinstance(value, datetime):
            event_date = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        if event_date is None:
            return None

        window_start = datetime.now(timezone.utc) - timedelta(days=2)
        window_end = datetime.now(timezone.utc) + timedelta(days=21)
        if event_date < window_start or event_date > window_end:
            return None

        headline = f"{symbol} earnings window approaching"
        summary = "Upcoming report may reset momentum expectations and near-term trend strength."
        impact = classify_impact(headline, summary)
        return {
            "id": f"earnings:{symbol}:{event_date.date().isoformat()}",
            "ticker": symbol,
            "event_date": event_date.isoformat(),
            "headline": headline,
            "source": "Yahoo Finance",
            "impact": impact,
            "tags": list(dict.fromkeys(canslim_tags(headline, summary) + ["C"])),
            "ai_summary": ai_summary(headline, summary, impact),
        }
    except Exception:
        return None


async def build_earnings_payload(top_symbols: list[str]) -> dict:
    unique = list(dict.fromkeys(symbol.strip().upper() for symbol in top_symbols if symbol))
    tasks = [asyncio.to_thread(_extract_earnings_event, symbol) for symbol in unique[:16]]
    raw = await asyncio.gather(*tasks, return_exceptions=True)
    items = [item for item in raw if isinstance(item, dict)]
    items.sort(key=lambda item: item["event_date"])
    return {
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "items": items,
    }
