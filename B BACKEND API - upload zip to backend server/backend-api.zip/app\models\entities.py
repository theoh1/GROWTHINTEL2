from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, Float, Integer, JSON, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class StockDaily(Base):
    __tablename__ = "stocks_daily"
    __table_args__ = (UniqueConstraint("ticker", "date", name="uq_stocks_daily_ticker_date"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticker: Mapped[str] = mapped_column(String(16), index=True)
    company_name: Mapped[str] = mapped_column(String(255))
    sector: Mapped[str] = mapped_column(String(128), index=True)
    industry: Mapped[str] = mapped_column(String(128), index=True)
    date: Mapped[date] = mapped_column(Date, index=True)
    rank: Mapped[int] = mapped_column(Integer, index=True)
    score: Mapped[float] = mapped_column(Float, index=True)
    raw_score: Mapped[float] = mapped_column(Float)
    confidence_score: Mapped[float] = mapped_column(Float)
    risk_level: Mapped[str] = mapped_column(String(16))
    grade: Mapped[str] = mapped_column(String(8))
    data_source: Mapped[str] = mapped_column(String(64), default="LIVE")
    market_cap_factor: Mapped[float] = mapped_column(Float, default=1.0)
    current_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_volume: Mapped[float | None] = mapped_column(Float, nullable=True)
    average_volume_50d: Mapped[float | None] = mapped_column(Float, nullable=True)
    breakdown: Mapped[dict] = mapped_column(JSON)
    strengths: Mapped[list] = mapped_column(JSON)
    weaknesses: Mapped[list] = mapped_column(JSON)
    flags: Mapped[list] = mapped_column(JSON)
    fundamentals: Mapped[dict] = mapped_column(JSON)
    institutional: Mapped[dict] = mapped_column(JSON)
    catalyst_signals: Mapped[dict] = mapped_column(JSON)
    recent_headlines: Mapped[list] = mapped_column(JSON)
    sparkline: Mapped[list] = mapped_column(JSON)
    why_this_stock: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


class DataCache(Base):
    __tablename__ = "data_cache"
    __table_args__ = (UniqueConstraint("cache_key", name="uq_data_cache_key"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cache_key: Mapped[str] = mapped_column(String(255), index=True)
    payload: Mapped[dict] = mapped_column(JSON)
    expires_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ScanRun(Base):
    __tablename__ = "scan_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    triggered_by: Mapped[str] = mapped_column(String(32), default="scheduler")
    status: Mapped[str] = mapped_column(String(32), default="completed")
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    scanned_count: Mapped[int] = mapped_column(Integer, default=0)
    top_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    market_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)


class WatchlistEntry(Base):
    __tablename__ = "watchlist_entries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticker: Mapped[str] = mapped_column(String(16), unique=True, index=True)
    note: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class AlertRule(Base):
    __tablename__ = "alert_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ticker: Mapped[str | None] = mapped_column(String(16), nullable=True, index=True)
    min_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    top_n_rank: Mapped[int | None] = mapped_column(Integer, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class TesterFeedback(Base):
    __tablename__ = "tester_feedback"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    feedback_type: Mapped[str] = mapped_column(String(40), index=True)
    message: Mapped[str] = mapped_column(Text)
    page: Mapped[str | None] = mapped_column(String(255), nullable=True)
    tester_identifier: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    browser_info: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default="new", index=True)
    screenshot_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
