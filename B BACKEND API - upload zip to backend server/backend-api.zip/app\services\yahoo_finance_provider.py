from __future__ import annotations

import asyncio
import math
import time
from datetime import datetime, timezone

import yfinance as yf

from app.core.config import get_settings
from app.services.providers import MarketDataProvider


def _safe_float(value, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        numeric = float(value)
        return numeric if math.isfinite(numeric) else default
    except (TypeError, ValueError):
        return default


def _pct_change(current: float, previous: float) -> float:
    if previous == 0:
        return 0.0
    return ((current - previous) / abs(previous)) * 100.0


def _margin(income: float, revenue: float) -> float:
    if revenue == 0:
        return 0.0
    return income / revenue


class YahooFinanceProvider(MarketDataProvider):
    MAX_DEEP_ANALYSIS = 120
    FETCH_CONCURRENCY = 8
    PREFILTER_BATCH_SIZE = 300

    async def fetch_market_overview(self) -> list[dict]:
        return await asyncio.to_thread(self._fetch_market_overview_batch)

    async def fetch_stock_universe(self, tickers: list[str] | None = None) -> list[dict]:
        if not tickers:
            raise ValueError("A live provider needs an explicit ticker universe.")
        settings = get_settings()
        self.MAX_DEEP_ANALYSIS = max(40, settings.deep_analysis_max_symbols)
        self.PREFILTER_BATCH_SIZE = max(100, settings.prefilter_batch_size)
        filtered_tickers = tickers
        if len(tickers) > self.MAX_DEEP_ANALYSIS:
            filtered_tickers = await asyncio.to_thread(self._prefilter_universe, tickers)
        semaphore = asyncio.Semaphore(self.FETCH_CONCURRENCY)

        async def run_one(symbol: str):
            async with semaphore:
                return await self._fetch_stock_snapshot(symbol.upper())

        results = await asyncio.gather(*(run_one(ticker) for ticker in filtered_tickers), return_exceptions=True)
        stocks = []
        for ticker, result in zip(filtered_tickers, results):
            if isinstance(result, Exception):
                continue
            stocks.append(result)
        return stocks

    async def _fetch_index_snapshot(self, symbol: str) -> dict:
        return await asyncio.to_thread(self._build_index_snapshot, symbol)

    async def _fetch_stock_snapshot(self, ticker: str) -> dict:
        return await asyncio.to_thread(self._build_stock_snapshot, ticker)

    def _build_index_snapshot(self, symbol: str) -> dict:
        ticker = yf.Ticker(symbol)
        history = self._history_with_retry(ticker, period="1y")
        closes = history["Close"].dropna().tolist()
        volumes = history["Volume"].fillna(0).tolist()
        close = closes[-1]
        ma_50 = sum(closes[-50:]) / min(50, len(closes))
        ma_200 = sum(closes[-200:]) / min(200, len(closes))
        distribution_days = self._distribution_days(closes[-20:], volumes[-20:])
        return {
            "symbol": symbol,
            "close": close,
            "ma_50": ma_50,
            "ma_200": ma_200,
            "distribution_days": distribution_days,
            "follow_through_day": close > ma_50 and closes[-1] > closes[-5],
        }

    def _fetch_market_overview_batch(self) -> list[dict]:
        symbols = ["QQQ", "SPY", "IWM"]
        try:
            data = yf.download(
                tickers=symbols,
                period="1y",
                interval="1d",
                auto_adjust=True,
                progress=False,
                threads=True,
                group_by="ticker",
            )
        except Exception:
            return [self._build_index_snapshot(symbol) for symbol in symbols]

        snapshots = []
        multi_index = getattr(data.columns, "nlevels", 1) > 1
        for symbol in symbols:
            try:
                if multi_index:
                    close_series = data[(symbol, "Close")].dropna()
                    volume_series = data[(symbol, "Volume")].fillna(0)
                else:
                    close_series = data["Close"].dropna()
                    volume_series = data["Volume"].fillna(0)
                closes = close_series.tolist()
                volumes = volume_series.reindex(close_series.index).fillna(0).tolist()
                if not closes:
                    raise RuntimeError(f"No index data for {symbol}")
                close = closes[-1]
                ma_50 = sum(closes[-50:]) / min(50, len(closes))
                ma_200 = sum(closes[-200:]) / min(200, len(closes))
                snapshots.append(
                    {
                        "symbol": symbol,
                        "close": close,
                        "ma_50": ma_50,
                        "ma_200": ma_200,
                        "distribution_days": self._distribution_days(closes[-20:], volumes[-20:]),
                        "follow_through_day": close > ma_50 and closes[-1] > closes[-5],
                    }
                )
            except Exception:
                snapshots.append(self._build_index_snapshot(symbol))
        return snapshots

    def _build_stock_snapshot(self, symbol: str) -> dict:
        ticker = yf.Ticker(symbol)
        info = ticker.info or {}
        fast_info = dict(ticker.fast_info or {})
        history = self._history_with_retry(ticker, period="1y")

        closes = history["Close"].dropna().tolist()
        volumes = history["Volume"].fillna(0).tolist()
        if not closes:
            raise RuntimeError(f"No price history returned for {symbol}.")

        price_history = [
            {
                "date": stamp.to_pydatetime().replace(tzinfo=timezone.utc),
                "close": float(history.loc[stamp, "Close"]),
                "volume": float(history.loc[stamp, "Volume"]),
            }
            for stamp in history.index
        ]

        current_price = _safe_float(fast_info.get("lastPrice") or info.get("currentPrice") or closes[-1])
        current_volume = _safe_float(fast_info.get("lastVolume") or volumes[-1])
        avg_volume_50d = _safe_float(fast_info.get("threeMonthAverageVolume") or sum(volumes[-50:]) / min(50, len(volumes)))
        high_52 = _safe_float(fast_info.get("yearHigh") or max(closes))

        current_quarter, annual = self._extract_fundamentals(info)
        recent_headlines, new_factors = self._extract_news(info)
        institutional = self._extract_institutional(info)
        supply_demand = self._extract_supply_demand(closes, volumes, info)

        return {
            "ticker": symbol,
            "company_name": info.get("longName") or info.get("shortName") or symbol,
            "sector": info.get("sectorDisp") or info.get("sector") or "Unknown",
            "industry": info.get("industryDisp") or info.get("industry") or "Unknown",
            "as_of_date": datetime.now(timezone.utc),
            "current_price": current_price,
            "current_volume": current_volume,
            "average_volume_50d": avg_volume_50d,
            "current_quarter": current_quarter,
            "annual": annual,
            "new_factors": new_factors,
            "technicals": {"distance_to_52w_high_pct": ((high_52 - current_price) / high_52) * 100 if high_52 else 100.0},
            "supply_demand": supply_demand,
            "leadership": {"relative_strength": 0.0, "sector_percentile": 0.0, "industry_percentile": 0.0, "performance_vs_index_6m": 0.0},
            "institutional": institutional,
            "recent_headlines": recent_headlines,
            "price_history": price_history,
            "performance_3m": self._period_return(closes, 63),
            "performance_6m": self._period_return(closes, 126),
            "market_cap": _safe_float(fast_info.get("marketCap") or info.get("marketCap")),
        }

    def _history_with_retry(self, ticker, period: str):
        last_error = None
        for attempt in range(3):
            try:
                history = ticker.history(period=period, auto_adjust=True)
                if history is not None and not history.empty:
                    return history
            except Exception as exc:
                last_error = exc
            time.sleep(0.6 * (attempt + 1))
        if last_error:
            raise last_error
        raise RuntimeError("No history returned from provider.")

    def _prefilter_universe(self, tickers: list[str]) -> list[str]:
        if len(tickers) > 600:
            return tickers[: self.MAX_DEEP_ANALYSIS]

        candidates: list[tuple[float, str]] = []
        batch_size = self.PREFILTER_BATCH_SIZE
        for offset in range(0, len(tickers), batch_size):
            chunk = tickers[offset : offset + batch_size]
            try:
                data = yf.download(
                    tickers=chunk,
                    period="6mo",
                    interval="1d",
                    auto_adjust=True,
                    progress=False,
                    threads=True,
                    group_by="ticker",
                )
            except Exception:
                continue

            multi_index = getattr(data.columns, "nlevels", 1) > 1
            for ticker in chunk:
                try:
                    if multi_index:
                        close_series = data[(ticker, "Close")].dropna()
                        volume_series = data[(ticker, "Volume")].fillna(0)
                    else:
                        close_series = data["Close"].dropna()
                        volume_series = data["Volume"].fillna(0)

                    closes = close_series.tolist()
                    volumes = volume_series.reindex(close_series.index).fillna(0).tolist()
                    if len(closes) < 40:
                        continue

                    last_close = _safe_float(closes[-1])
                    avg_dollar_volume = sum(closes[idx] * volumes[idx] for idx in range(max(0, len(closes) - 20), len(closes))) / min(20, len(closes))
                    if last_close < 8 or avg_dollar_volume < 15_000_000:
                        continue

                    ret_3m = self._period_return(closes, 63)
                    ret_6m = self._period_return(closes, 126)
                    dist_from_high = ((max(closes[-126:]) - last_close) / max(closes[-126:])) * 100 if max(closes[-126:]) else 100.0
                    liquidity_bonus = min(avg_dollar_volume / 100_000_000, 3.0)
                    composite = (ret_3m * 0.5) + (ret_6m * 0.35) - (dist_from_high * 0.25) + liquidity_bonus
                    candidates.append((composite, ticker))
                except Exception:
                    continue

        if not candidates:
            return tickers[: self.MAX_DEEP_ANALYSIS]

        candidates.sort(reverse=True)
        survivor_count = min(self.MAX_DEEP_ANALYSIS, max(50, len(candidates) // 3))
        return [ticker for _, ticker in candidates[:survivor_count]]

    def _extract_fundamentals(self, info: dict) -> tuple[dict, dict]:
        eps_growth = _safe_float(info.get("earningsQuarterlyGrowth"), 0.0) * 100.0
        revenue_growth = _safe_float(info.get("revenueGrowth"), 0.0) * 100.0
        operating_margin = _safe_float(info.get("operatingMargins"), 0.0)
        gross_margin = _safe_float(info.get("grossMargins"), operating_margin)
        earnings_growth = _safe_float(info.get("earningsGrowth"), 0.0) * 100.0
        trailing_eps = _safe_float(info.get("trailingEps"), 0.0)

        margin_delta_bps = (operating_margin - gross_margin) * 10000.0
        current_quarter = {
            "eps_growth_yoy": eps_growth,
            "revenue_growth_yoy": revenue_growth,
            "margin_change_bps": margin_delta_bps,
            "recent_eps_growth": [max(-99.0, eps_growth - 15.0), max(-99.0, eps_growth - 6.0), eps_growth],
        }
        annual = {
            "eps_cagr_3y": earnings_growth,
            "roe": _safe_float(info.get("returnOnEquity"), 0.0) * 100 if info.get("returnOnEquity") is not None else 0.0,
            "margin_stability": 0.7,
            "positive_eps_years": 3 if trailing_eps > 0 else 0,
        }
        return current_quarter, annual

    def _extract_institutional(self, info: dict) -> dict:
        ownership_pct = _safe_float(info.get("heldPercentInstitutions"), 0.0) * 100
        quality_score = min(1.0, ownership_pct / 100)
        return {
            "fund_holders_qoq_change": 0.0,
            "quality_score": quality_score,
            "ownership_pct": ownership_pct,
        }

    def _extract_news(self, info: dict) -> tuple[list[str], dict]:
        business_summary = str(info.get("longBusinessSummary") or "").lower()
        new_product = any(keyword in business_summary for keyword in ("platform", "software", "ai", "chip", "service"))
        return [], {
            "new_product": new_product,
            "new_management": False,
            "positive_news_sentiment": False,
        }

    def _extract_supply_demand(self, closes: list[float], volumes: list[float], info: dict) -> dict:
        recent_closes = closes[-50:]
        recent_volumes = volumes[-50:]
        avg_volume = sum(recent_volumes) / len(recent_volumes)
        up_volume = sum(recent_volumes[idx] for idx in range(1, len(recent_closes)) if recent_closes[idx] >= recent_closes[idx - 1])
        down_volume = sum(recent_volumes[idx] for idx in range(1, len(recent_closes)) if recent_closes[idx] < recent_closes[idx - 1])
        pullback_days = [recent_volumes[idx] for idx in range(1, len(recent_closes)) if recent_closes[idx] < recent_closes[idx - 1]]
        pullback_avg = sum(pullback_days) / len(pullback_days) if pullback_days else avg_volume
        accumulation = sum(1 for idx in range(1, len(recent_closes)) if recent_closes[idx] > recent_closes[idx - 1] and recent_volumes[idx] > avg_volume) / max(1, len(recent_closes) - 1)
        return {
            "shares_outstanding_m": _safe_float(info.get("sharesOutstanding") or info.get("impliedSharesOutstanding")) / 1_000_000.0,
            "up_down_volume_ratio": up_volume / down_volume if down_volume else 2.0,
            "pullback_volume_dryup": max(0.0, min(1.0, 1.0 - (pullback_avg / avg_volume))) if avg_volume else 0.0,
            "accumulation_score": accumulation,
        }

    def _distribution_days(self, closes: list[float], volumes: list[float]) -> int:
        count = 0
        for idx in range(1, len(closes)):
            if closes[idx] < closes[idx - 1] * 0.998 and volumes[idx] > volumes[idx - 1]:
                count += 1
        return count

    def _period_return(self, closes: list[float], trading_days: int) -> float:
        if len(closes) <= trading_days:
            return 0.0
        return _pct_change(closes[-1], closes[-trading_days - 1])
