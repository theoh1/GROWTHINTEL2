from statistics import mean


class MarketTrendAnalyzer:
    def evaluate(self, indices: list[dict]) -> dict:
        indices_above_50 = mean(1.0 if index["close"] > index["ma_50"] else 0.0 for index in indices)
        indices_above_200 = mean(1.0 if index["close"] > index["ma_200"] else 0.0 for index in indices)
        distribution_pressure = mean(index["distribution_days"] for index in indices)
        follow_through = any(index["follow_through_day"] for index in indices)

        if indices_above_50 >= 0.75 and indices_above_200 >= 0.67 and follow_through and distribution_pressure <= 3:
            trend = "confirmed_uptrend"
        elif indices_above_50 >= 0.5 and distribution_pressure <= 4:
            trend = "uptrend_under_pressure"
        else:
            trend = "market_in_correction"

        health_score = round(
            (
                (indices_above_50 * 35)
                + (indices_above_200 * 30)
                + (15 if follow_through else 0)
                + max(0, (6 - distribution_pressure) * 3.5)
            ),
            2,
        )
        warning_banner = None
        if trend != "confirmed_uptrend":
            warning_banner = "Market is not in a confirmed uptrend. Final CANSLIM scores are reduced by 20%."

        return {
            "trend": trend,
            "follow_through_day": follow_through,
            "indices_above_50dma_ratio": round(indices_above_50, 2),
            "indices_above_200dma_ratio": round(indices_above_200, 2),
            "distribution_day_pressure": round(distribution_pressure, 2),
            "health_score": health_score,
            "warning_banner": warning_banner,
            "indices": indices,
        }
