from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import desc, select
from sqlalchemy.orm import Session

from app.models.entities import AlertRule, DataCache, ScanRun, StockDaily, WatchlistEntry


class ScreeningRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_cache(self, cache_key: str) -> dict | None:
        entry = self.db.execute(
            select(DataCache).where(
                DataCache.cache_key == cache_key,
                DataCache.expires_at > datetime.utcnow(),
            )
        ).scalar_one_or_none()
        return entry.payload if entry else None

    def set_cache(self, cache_key: str, payload: dict, expires_at: datetime) -> None:
        entry = self.db.execute(select(DataCache).where(DataCache.cache_key == cache_key)).scalar_one_or_none()
        if entry:
            entry.payload = payload
            entry.expires_at = expires_at
        else:
            self.db.add(DataCache(cache_key=cache_key, payload=payload, expires_at=expires_at))
        self.db.commit()

    def replace_daily_rows(self, rows: list[dict], run_date: date) -> None:
        existing = self.db.execute(select(StockDaily).where(StockDaily.date == run_date)).scalars().all()
        for row in existing:
            self.db.delete(row)
        self.db.commit()
        for row in rows:
            self.db.add(StockDaily(**row))
        self.db.commit()

    def latest_scan_rows(self, threshold: float = 0, sector: str | None = None, limit: int = 100) -> list[StockDaily]:
        latest_date = self.latest_snapshot_date()
        if latest_date is None:
            return []
        query = select(StockDaily).where(StockDaily.date == latest_date, StockDaily.score >= threshold)
        if sector:
            query = query.where(StockDaily.sector == sector)
        query = query.order_by(StockDaily.rank.asc()).limit(limit)
        return list(self.db.execute(query).scalars())

    def latest_snapshot_date(self) -> date | None:
        row = self.db.execute(select(StockDaily.date).order_by(desc(StockDaily.date)).limit(1)).first()
        return row[0] if row else None

    def history_for_ticker(self, ticker: str) -> list[StockDaily]:
        return list(
            self.db.execute(
                select(StockDaily)
                .where(StockDaily.ticker == ticker.upper())
                .order_by(StockDaily.date.asc())
            ).scalars()
        )

    def previous_rows_by_ticker(self, current_date: date) -> dict[str, StockDaily]:
        previous_date = self.db.execute(
            select(StockDaily.date)
            .where(StockDaily.date < current_date)
            .order_by(desc(StockDaily.date))
            .limit(1)
        ).scalar_one_or_none()
        if previous_date is None:
            return {}
        rows = self.db.execute(select(StockDaily).where(StockDaily.date == previous_date)).scalars().all()
        return {row.ticker: row for row in rows}

    def record_scan_run(self, triggered_by: str, scanned_count: int, top_score: float | None, market_snapshot: dict) -> ScanRun:
        run = ScanRun(
            triggered_by=triggered_by,
            completed_at=datetime.utcnow(),
            scanned_count=scanned_count,
            top_score=top_score,
            market_snapshot=market_snapshot,
        )
        self.db.add(run)
        self.db.commit()
        self.db.refresh(run)
        return run

    def latest_scan_run(self) -> ScanRun | None:
        return self.db.execute(select(ScanRun).order_by(desc(ScanRun.started_at)).limit(1)).scalar_one_or_none()

    def upsert_watchlist(self, ticker: str, note: str | None) -> WatchlistEntry:
        ticker = ticker.upper()
        entry = self.db.execute(select(WatchlistEntry).where(WatchlistEntry.ticker == ticker)).scalar_one_or_none()
        if entry:
            entry.note = note
        else:
            entry = WatchlistEntry(ticker=ticker, note=note)
            self.db.add(entry)
        self.db.commit()
        self.db.refresh(entry)
        return entry

    def list_watchlist(self) -> list[WatchlistEntry]:
        return list(self.db.execute(select(WatchlistEntry).order_by(desc(WatchlistEntry.created_at))).scalars())

    def create_alert(self, ticker: str | None, min_score: float | None, top_n_rank: int | None) -> AlertRule:
        alert = AlertRule(ticker=ticker.upper() if ticker else None, min_score=min_score, top_n_rank=top_n_rank)
        self.db.add(alert)
        self.db.commit()
        self.db.refresh(alert)
        return alert

    def active_alerts(self) -> list[AlertRule]:
        return list(self.db.execute(select(AlertRule).where(AlertRule.is_active.is_(True))).scalars())
