from __future__ import annotations


def breakout_status(
    *,
    buy_point: float,
    current_price: float,
    previous_close: float,
    current_volume: float,
    average_volume: float,
    day_high: float,
    day_low: float,
    pattern_confidence: float,
) -> dict:
    if buy_point <= 0:
        return {
            "status": "Faulty Base",
            "distance_from_buy_point_pct": 0.0,
            "volume_vs_average_pct": 0.0,
            "close_strength": 0.0,
            "is_valid_breakout": False,
        }

    distance_pct = ((current_price - buy_point) / buy_point) * 100.0
    volume_ratio = (current_volume / average_volume) if average_volume > 0 else 0.0
    volume_vs_average_pct = (volume_ratio - 1.0) * 100.0
    intraday_range = max(0.01, day_high - day_low)
    close_strength = (current_price - day_low) / intraday_range

    crossed_today = previous_close < buy_point <= current_price
    strong_volume = volume_ratio >= 1.4
    strong_close = close_strength >= 0.7
    valid_breakout = crossed_today and strong_volume and strong_close

    if pattern_confidence < 55:
        status = "Faulty Base"
    elif valid_breakout:
        status = "Breaking Out"
    elif 0 <= distance_pct <= 5:
        status = "In Buy Zone"
    elif distance_pct > 5:
        status = "Extended"
    elif distance_pct < 0:
        status = "Below Buy Point"
    else:
        status = "Faulty Base"

    return {
        "status": status,
        "distance_from_buy_point_pct": round(distance_pct, 2),
        "volume_vs_average_pct": round(volume_vs_average_pct, 2),
        "close_strength": round(close_strength * 100.0, 2),
        "is_valid_breakout": valid_breakout,
    }
