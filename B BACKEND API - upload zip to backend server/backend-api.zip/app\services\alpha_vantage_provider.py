from __future__ import annotations

import asyncio
import math
from datetime import datetime, timezone

import httpx

from app.services.providers import MarketDataProvider


def _safe_float(value, default: float = 0.0) -> float:
    if value in (None, "", "None", "null"):
        return default
    try:
        return float(str(value).replace("%", ""))
    except (TypeError, ValueError):
        return default


def _safe_int(value, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _pct_change(current: float, previous: float) -> float:
    if previous == 0:
        return 0.0
    return ((current - previous) / abs(previous)) * 100.0


def _margin(income: float, revenue: float) -> float:
    if revenue == 0:
        return 0.0
    return income / revenue


def _cagr(values: list[float]) -> float:
    positives = [value for value in values if value > 0]
    if len(positives) < 2:
        return 0.0
    start = positives[0]
    end = positives[-1]
    periods = len(positives) - 1
    if start <= 0 or periods <= 0:
        return 0.0
    return ((end / start) ** (1 / periods) - 1) * 100.0


class AlphaVantageProvider(MarketDataProvider):
    base_url = "https://www.alphavantage.co/query"

    def __init__(self, api_key: str, rate_limit_per_minute: int = 75):
        self.api_key = api_key
        self.rate_limit_per_minute = max(1, rate_limit_per_minute)
        self.request_interval = 60.0 / self.rate_limit_per_minute
        self._lock = asyncio.Lock()
        self._last_request_at = 0.0

    async def fetch_market_overview(self) -> list[dict]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            return [
                await self._fetch_index_snapshot(client, "QQQ"),
                await self._fetch_index_snapshot(client, "SPY"),
                await self._fetch_index_snapshot(client, "IWM"),
            ]

    async def fetch_stock_universe(self, tickers: list[str] | None = None) -> list[dict]:
        if not tickers:
            raise ValueError("Live screening needs an explicit ticker universe.")

        async with httpx.AsyncClient(timeout=30.0) as client:
            stocks = []
            for ticker in tickers:
                stocks.append(await self._fetch_stock_snapshot(client, ticker.upper()))
            return stocks

    async def _throttled_get(self, client: httpx.AsyncClient, params: dict) -> dict:
        async with self._lock:
            now = asyncio.get_running_loop().time()
            delay = self.request_interval - (now - self._last_request_at)
            if delay > 0:
                await asyncio.sleep(delay)
            response = await client.get(self.base_url, params={**params, "apikey": self.api_key})
            self._last_request_at = asyncio.get_running_loop().time()

        response.raise_for_status()
        payload = response.json()
        if "Note" in payload:
            raise RuntimeError(payload["Note"])
        if "Information" in payload:
            raise RuntimeError(payload["Information"])
        return payload

    async def _fetch_index_snapshot(self, client: httpx.AsyncClient, symbol: str) -> dict:
        payload = await self._throttled_get(
            client,
            {"function": "TIME_SERIES_DAILY_ADJUSTED", "symbol": symbol, "outputsize": "full"},
        )
        series = payload.get("Time Series (Daily)", {})
        closes = [float(day["5. adjusted close"]) for _, day in sorted(series.items())]
        close = closes[-1]
        ma_50 = sum(closes[-50:]) / min(50, len(closes))
        ma_200 = sum(closes[-200:]) / min(200, len(closes))
        distribution_days = self._distribution_days(series)
        return {
            "symbol": symbol,
            "close": close,
            "ma_50": ma_50,
            "ma_200": ma_200,
            "distribution_days": distribution_days,
            "follow_through_day": close > ma_50 and closes[-1] > closes[-5],
        }

    async def _fetch_stock_snapshot(self, client: httpx.AsyncClient, ticker: str) -> dict:
        daily_payload = await self._throttled_get(
            client,
            {"function": "TIME_SERIES_DAILY_ADJUSTED", "symbol": ticker, "outputsize": "full"},
        )
        overview_payload = await self._throttled_get(client, {"function": "OVERVIEW", "symbol": ticker})
        earnings_payload = await self._throttled_get(client, {"function": "EARNINGS", "symbol": ticker})
        income_payload = await self._throttled_get(client, {"function": "INCOME_STATEMENT", "symbol": ticker})

        news_payload = {}
        try:
            news_payload = await self._throttled_get(client, {"function": "NEWS_SENTIMENT", "tickers": ticker, "limit": 20})
        except RuntimeError:
            news_payload = {}

        institutional_payload = {}
        try:
            institutional_payload = await self._throttled_get(client, {"function": "INSTITUTIONAL_HOLDINGS", "symbol": ticker})
        except RuntimeError:
            institutional_payload = {}

        price_history = self._parse_price_history(daily_payload)
        latest_close = price_history[-1]["close"]
        latest_volume = price_history[-1]["volume"]
        avg_volume_50d = sum(day["volume"] for day in price_history[-50:]) / min(50, len(price_history))
        high_52 = max(day["close"] for day in price_history[-252:])
        current_quarter, annual, news_factors, headlines = self._parse_fundamentals(overview_payload, earnings_payload, income_payload, news_payload)
        supply_demand = self._parse_supply_demand(price_history, overview_payload)
        institutional = self._parse_institutional(institutional_payload)
        performance_3m = self._period_return(price_history, 63)
        performance_6m = self._period_return(price_history, 126)

        return {
            "ticker": ticker,
            "company_name": overview_payload.get("Name", ticker),
            "sector": overview_payload.get("Sector", "Unknown"),
            "industry": overview_payload.get("Industry", "Unknown"),
            "as_of_date": price_history[-1]["date"],
            "current_price": latest_close,
            "current_volume": latest_volume,
            "average_volume_50d": avg_volume_50d,
            "current_quarter": current_quarter,
            "annual": annual,
            "new_factors": news_factors,
            "technicals": {"distance_to_52w_high_pct": ((high_52 - latest_close) / high_52) * 100 if high_52 else 100.0},
            "supply_demand": supply_demand,
            "leadership": {
                "relative_strength": 0.0,
                "sector_percentile": 0.0,
                "industry_percentile": 0.0,
                "performance_vs_index_6m": 0.0,
            },
            "institutional": institutional,
            "recent_headlines": headlines,
            "price_history": price_history,
            "performance_3m": performance_3m,
            "performance_6m": performance_6m,
            "market_cap": _safe_float(overview_payload.get("MarketCapitalization")),
        }

    def _parse_price_history(self, payload: dict) -> list[dict]:
        series = payload.get("Time Series (Daily)", {})
        history = []
        for date_text, row in sorted(series.items()):
            history.append(
                {
                    "date": datetime.strptime(date_text, "%Y-%m-%d").replace(tzinfo=timezone.utc),
                    "open": _safe_float(row.get("1. open")),
                    "high": _safe_float(row.get("2. high")),
                    "low": _safe_float(row.get("3. low")),
                    "close": _safe_float(row.get("5. adjusted close") or row.get("4. close")),
                    "volume": _safe_float(row.get("6. volume") or row.get("5. volume")),
                }
            )
        if len(history) < 30:
            raise RuntimeError("Insufficient price history returned from Alpha Vantage.")
        return history

    def _parse_fundamentals(self, overview: dict, earnings: dict, income: dict, news: dict) -> tuple[dict, dict, dict, list[str]]:
        quarterly_eps = earnings.get("quarterlyEarnings", [])
        annual_eps = earnings.get("annualEarnings", [])
        quarterly_reports = income.get("quarterlyReports", [])
        annual_reports = income.get("annualReports", [])

        latest_eps = quarterly_eps[0] if quarterly_eps else {}
        year_ago_eps = quarterly_eps[4] if len(quarterly_eps) > 4 else {}
        recent_eps_growth = []
        for idx in range(min(3, max(0, len(quarterly_eps) - 4))):
            current_report = quarterly_eps[idx]
            prior_report = quarterly_eps[idx + 4]
            recent_eps_growth.append(
                _pct_change(_safe_float(current_report.get("reportedEPS")), _safe_float(prior_report.get("reportedEPS")))
            )

        current_report = quarterly_reports[0] if quarterly_reports else {}
        year_ago_report = quarterly_reports[4] if len(quarterly_reports) > 4 else {}
        current_revenue = _safe_float(current_report.get("totalRevenue"))
        prior_revenue = _safe_float(year_ago_report.get("totalRevenue"))
        current_margin = _margin(_safe_float(current_report.get("operatingIncome")), current_revenue)
        prior_margin = _margin(_safe_float(year_ago_report.get("operatingIncome")), prior_revenue)

        annual_eps_values = [_safe_float(item.get("reportedEPS")) for item in reversed(annual_eps[:5])]
        annual_margin_values = []
        for report in reversed(annual_reports[:5]):
            total_revenue = _safe_float(report.get("totalRevenue"))
            annual_margin_values.append(_margin(_safe_float(report.get("operatingIncome")), total_revenue))

        news_items = news.get("feed", []) if isinstance(news, dict) else []
        sentiment_scores = [_safe_float(item.get("overall_sentiment_score"), 0.0) for item in news_items]
        avg_sentiment = sum(sentiment_scores) / len(sentiment_scores) if sentiment_scores else 0.0
        keyword_blob = " ".join(
            f"{item.get('title', '')} {item.get('summary', '')}".lower()
            for item in news_items[:10]
        )
        headlines = [item.get("title", "") for item in news_items[:5] if item.get("title")]

        current_quarter = {
            "eps_growth_yoy": _pct_change(
                _safe_float(latest_eps.get("reportedEPS")),
                _safe_float(year_ago_eps.get("reportedEPS")),
            ),
            "revenue_growth_yoy": _pct_change(current_revenue, prior_revenue),
            "margin_change_bps": (current_margin - prior_margin) * 10000.0,
            "recent_eps_growth": list(reversed(recent_eps_growth)),
        }
        annual = {
            "eps_cagr_3y": _cagr(annual_eps_values[-4:]) if len(annual_eps_values) >= 4 else _cagr(annual_eps_values),
            "roe": _safe_float(overview.get("ReturnOnEquityTTM")),
            "margin_stability": self._margin_stability_score(annual_margin_values),
            "positive_eps_years": sum(1 for value in annual_eps_values if value > 0),
        }
        new_factors = {
            "new_product": any(keyword in keyword_blob for keyword in ("launch", "introduc", "new product", "release", "platform")),
            "new_management": any(keyword in keyword_blob for keyword in ("ceo", "cfo", "appoint", "management", "chairman")),
            "positive_news_sentiment": avg_sentiment > 0.15,
        }
        return current_quarter, annual, new_factors, headlines

    def _parse_supply_demand(self, price_history: list[dict], overview: dict) -> dict:
        recent = price_history[-50:]
        up_volume = sum(day["volume"] for idx, day in enumerate(recent[1:], start=1) if day["close"] >= recent[idx - 1]["close"])
        down_volume = sum(day["volume"] for idx, day in enumerate(recent[1:], start=1) if day["close"] < recent[idx - 1]["close"])
        up_down_ratio = up_volume / down_volume if down_volume else 2.0

        trailing_avg = sum(day["volume"] for day in recent) / len(recent)
        pullback_days = [day["volume"] for idx, day in enumerate(recent[1:], start=1) if day["close"] < recent[idx - 1]["close"]]
        pullback_avg = sum(pullback_days) / len(pullback_days) if pullback_days else trailing_avg
        dryup = max(0.0, min(1.0, 1.0 - (pullback_avg / trailing_avg))) if trailing_avg else 0.0

        accumulation = self._accumulation_score(recent)
        return {
            "shares_outstanding_m": _safe_float(overview.get("SharesOutstanding")) / 1_000_000.0,
            "up_down_volume_ratio": up_down_ratio,
            "pullback_volume_dryup": dryup,
            "accumulation_score": accumulation,
        }

    def _parse_institutional(self, payload: dict) -> dict:
        holdings = payload.get("data") or payload.get("holdings") or []
        if not holdings:
            return {"fund_holders_qoq_change": 0.0, "quality_score": 0.5, "ownership_pct": 50.0}

        by_period: dict[str, list[dict]] = {}
        for row in holdings:
            period = str(row.get("reportDate") or row.get("dateReported") or "")[:7]
            if period:
                by_period.setdefault(period, []).append(row)

        periods = sorted(by_period.keys(), reverse=True)
        latest = by_period.get(periods[0], []) if periods else []
        previous = by_period.get(periods[1], []) if len(periods) > 1 else []
        latest_holder_count = len({row.get("institution") or row.get("name") for row in latest})
        previous_holder_count = len({row.get("institution") or row.get("name") for row in previous})
        ownership_pct = sum(_safe_float(row.get("percentHeld"), 0.0) for row in latest[:20])
        top_positions = sorted((_safe_float(row.get("percentHeld"), 0.0) for row in latest), reverse=True)[:10]
        quality_score = min(1.0, (sum(top_positions) / max(1, len(top_positions))) / 5.0) if top_positions else 0.5

        return {
            "fund_holders_qoq_change": float(latest_holder_count - previous_holder_count),
            "quality_score": quality_score,
            "ownership_pct": ownership_pct,
        }

    def _period_return(self, history: list[dict], trading_days: int) -> float:
        if len(history) <= trading_days:
            return 0.0
        current = history[-1]["close"]
        prior = history[-trading_days - 1]["close"]
        return _pct_change(current, prior)

    def _distribution_days(self, series: dict) -> int:
        items = [(date_text, row) for date_text, row in sorted(series.items())][-20:]
        count = 0
        for idx in range(1, len(items)):
            _, current = items[idx]
            _, previous = items[idx - 1]
            current_close = _safe_float(current.get("5. adjusted close") or current.get("4. close"))
            previous_close = _safe_float(previous.get("5. adjusted close") or previous.get("4. close"))
            current_volume = _safe_float(current.get("6. volume") or current.get("5. volume"))
            previous_volume = _safe_float(previous.get("6. volume") or previous.get("5. volume"))
            if current_close < previous_close * 0.998 and current_volume > previous_volume:
                count += 1
        return count

    def _accumulation_score(self, recent: list[dict]) -> float:
        score = 0.0
        comparisons = 0
        avg_volume = sum(day["volume"] for day in recent) / len(recent)
        for idx in range(1, len(recent)):
            comparisons += 1
            price_up = recent[idx]["close"] > recent[idx - 1]["close"]
            volume_above_avg = recent[idx]["volume"] > avg_volume
            if price_up and volume_above_avg:
                score += 1.0
            elif price_up:
                score += 0.6
            elif recent[idx]["volume"] < avg_volume:
                score += 0.3
        return score / max(1, comparisons)

    def _margin_stability_score(self, margins: list[float]) -> float:
        if len(margins) < 2:
            return 0.0
        mean_margin = sum(margins) / len(margins)
        if mean_margin == 0:
            return 0.0
        variance = sum((margin - mean_margin) ** 2 for margin in margins) / len(margins)
        volatility = math.sqrt(variance)
        return max(0.0, min(1.0, 1.0 - (volatility / max(abs(mean_margin), 0.01))))
