from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


_GROUPS: dict[str, dict[str, Any]] = {
    "hedge_funds": {
        "label": "Hedge Funds",
        "insight": "Focused Portfolio",
        "investors": [
            {
                "id": "citadel",
                "name": "Citadel Advisors",
                "holdings": [("NVDA", 19.2, "buying"), ("MSFT", 15.1, "buying"), ("AMZN", 12.4, "flat"), ("META", 10.8, "selling"), ("GOOGL", 9.3, "buying"), ("AAPL", 8.7, "flat"), ("AVGO", 7.2, "buying"), ("TSLA", 6.4, "selling")],
            },
            {
                "id": "point72",
                "name": "Point72",
                "holdings": [("AMZN", 17.3, "buying"), ("META", 14.9, "buying"), ("NVDA", 13.7, "buying"), ("MSFT", 11.8, "flat"), ("CRM", 9.5, "buying"), ("AAPL", 8.1, "selling"), ("AMD", 7.6, "buying"), ("GOOGL", 6.3, "flat")],
            },
        ],
    },
    "top_investors": {
        "label": "Top Investors",
        "insight": "Heavy in Tech",
        "investors": [
            {
                "id": "buffett",
                "name": "Warren Buffett",
                "holdings": [("AAPL", 31.2, "flat"), ("BAC", 13.8, "selling"), ("AXP", 12.1, "buying"), ("KO", 8.4, "flat"), ("OXY", 7.8, "buying"), ("CVX", 7.1, "selling"), ("MCO", 6.0, "buying"), ("AMZN", 5.4, "buying")],
            },
            {
                "id": "ackman",
                "name": "Bill Ackman",
                "holdings": [("GOOGL", 21.5, "buying"), ("CMG", 18.3, "flat"), ("HHH", 15.9, "buying"), ("QSR", 13.2, "selling"), ("Lowe", 10.1, "flat"), ("NFLX", 8.2, "buying"), ("HIL", 6.9, "flat"), ("DPZ", 5.9, "selling")],
            },
        ],
    },
    "institutions": {
        "label": "Institutions",
        "insight": "Diversified",
        "investors": [
            {
                "id": "vanguard",
                "name": "Vanguard",
                "holdings": [("MSFT", 15.9, "buying"), ("AAPL", 15.4, "flat"), ("NVDA", 11.8, "buying"), ("AMZN", 10.2, "flat"), ("META", 9.6, "buying"), ("GOOGL", 8.9, "flat"), ("BRK-B", 7.5, "buying"), ("TSLA", 6.1, "selling")],
            },
            {
                "id": "blackrock",
                "name": "BlackRock",
                "holdings": [("AAPL", 16.1, "flat"), ("MSFT", 15.0, "buying"), ("NVDA", 12.4, "buying"), ("AMZN", 10.5, "flat"), ("META", 9.8, "buying"), ("GOOGL", 8.7, "flat"), ("LLY", 7.2, "buying"), ("JPM", 5.5, "selling")],
            },
        ],
    },
    "growth_investors": {
        "label": "Growth Investors",
        "insight": "Focused Portfolio",
        "investors": [
            {
                "id": "ark",
                "name": "ARK Invest",
                "holdings": [("TSLA", 23.8, "buying"), ("ROKU", 14.1, "buying"), ("COIN", 12.8, "buying"), ("CRSP", 10.9, "flat"), ("PATH", 9.2, "selling"), ("SHOP", 8.6, "buying"), ("SQ", 7.1, "flat"), ("ZM", 5.6, "selling")],
            },
            {
                "id": "tiger",
                "name": "Tiger Global",
                "holdings": [("META", 18.9, "buying"), ("AMZN", 16.4, "buying"), ("MSFT", 13.0, "flat"), ("NVDA", 12.2, "buying"), ("SHOP", 9.1, "buying"), ("SE", 8.3, "selling"), ("PDD", 7.0, "buying"), ("GOOGL", 6.1, "flat")],
            },
        ],
    },
    "value_investors": {
        "label": "Value Investors",
        "insight": "Diversified",
        "investors": [
            {
                "id": "baupost",
                "name": "Baupost",
                "holdings": [("GOOGL", 17.8, "buying"), ("MSFT", 14.0, "flat"), ("QCOM", 12.9, "buying"), ("AAPL", 11.5, "flat"), ("AMZN", 10.2, "buying"), ("CVX", 9.4, "selling"), ("JPM", 8.1, "flat"), ("ORCL", 6.0, "buying")],
            },
            {
                "id": "valueact",
                "name": "ValueAct",
                "holdings": [("MSFT", 20.6, "buying"), ("KKR", 16.8, "buying"), ("SPGI", 13.2, "flat"), ("CBRE", 11.4, "flat"), ("FIS", 9.9, "selling"), ("AON", 8.5, "buying"), ("ADBE", 7.1, "flat"), ("NKE", 5.4, "selling")],
            },
        ],
    },
}


def _normalize_top(holdings: list[tuple[str, float, str]], top_n: int = 8) -> list[dict[str, Any]]:
    ordered = holdings[:top_n]
    total = sum(weight for _, weight, _ in ordered)
    if total <= 0:
        return [{"ticker": ticker, "allocation_pct": round(weight, 2), "trend": trend} for ticker, weight, trend in ordered]
    return [
        {
            "ticker": ticker,
            "allocation_pct": round((weight / total) * 100.0, 2),
            "trend": trend,
        }
        for ticker, weight, trend in ordered
    ]


def get_smart_money_payload(group: str | None = None, investor: str | None = None) -> dict[str, Any]:
    group_key = (group or "hedge_funds").strip().lower()
    if group_key not in _GROUPS:
        group_key = "hedge_funds"
    group_block = _GROUPS[group_key]
    investors = group_block["investors"]

    selected_investor = next((item for item in investors if item["id"] == (investor or "").strip().lower()), investors[0])
    holdings = _normalize_top(selected_investor["holdings"], top_n=8)
    trending_moves = [{"ticker": item["ticker"], "action": "Buying more" if item["trend"] == "buying" else "Selling" if item["trend"] == "selling" else "Steady"} for item in holdings[:4]]

    return {
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "data_source": "STRUCTURED_FALLBACK",
        "groups": [{"key": key, "label": block["label"]} for key, block in _GROUPS.items()],
        "group": group_key,
        "group_label": group_block["label"],
        "insight": group_block["insight"],
        "investors": [{"id": item["id"], "name": item["name"]} for item in investors],
        "selected_investor": {"id": selected_investor["id"], "name": selected_investor["name"]},
        "holdings": holdings,
        "trending_moves": trending_moves,
    }
