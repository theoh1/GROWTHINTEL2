from __future__ import annotations

import json
from pathlib import Path


LIQUID_US_UNIVERSE = [
    "AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "GOOG", "META", "TSLA", "AVGO", "AMD",
    "NFLX", "ORCL", "CRM", "ADBE", "CSCO", "INTC", "QCOM", "TXN", "AMAT", "MU",
    "LRCX", "KLAC", "PANW", "CRWD", "NOW", "SHOP", "UBER", "PLTR", "SNOW", "DDOG",
    "MDB", "NET", "ZS", "TEAM", "SQ", "PYPL", "INTU", "ADP", "WDAY", "APP",
    "ANET", "SNPS", "CDNS", "MRVL", "ARM", "SMCI", "DELL", "HPQ", "IBM", "HPE",
    "GE", "ETN", "CAT", "PH", "RTX", "LMT", "NOC", "BA", "HWM", "GEV",
    "JPM", "GS", "MS", "BAC", "WFC", "BLK", "V", "MA", "AXP", "COST",
    "WMT", "TGT", "HD", "LOW", "MCD", "CMG", "DIS", "LLY", "JNJ", "UNH",
    "XOM", "CVX", "COP", "EOG", "LIN", "APD", "NUE", "CSX", "UNP", "UPS",
]


def _load_us_tickers() -> list[str]:
    path = Path(__file__).with_name("us_tickers.json")
    if not path.exists():
        return LIQUID_US_UNIVERSE
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return LIQUID_US_UNIVERSE
    return [ticker for ticker in raw if isinstance(ticker, str) and ticker]


FULL_US_UNIVERSE = _load_us_tickers()

UNIVERSE_PRESETS = {
    "LIQUID_US": LIQUID_US_UNIVERSE,
    "BROAD_US": LIQUID_US_UNIVERSE,
    "ULTRA_BROAD_US": LIQUID_US_UNIVERSE,
    "FULL_US_FREE": FULL_US_UNIVERSE,
}
