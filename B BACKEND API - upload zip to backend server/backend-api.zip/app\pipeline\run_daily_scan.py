from __future__ import annotations

from app.repositories.screening_repository import ScreeningRepository
from app.services.data_service import DataService
from app.services.provider_factory import build_market_provider, build_news_provider
from app.services.screener_service import ScreenerService


async def run_daily_scan(repository: ScreeningRepository, triggered_by: str = "scheduler") -> dict:
    market_provider = build_market_provider()
    news_provider = build_news_provider()
    data_service = DataService(repository, market_provider)
    service = ScreenerService(market_provider, news_provider, repository, data_service)
    return await service.run_screen(force_refresh=True, triggered_by=triggered_by)
