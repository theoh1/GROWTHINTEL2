from __future__ import annotations

from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


class BreakdownItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    score: float
    max_score: float


class MarketIndexSnapshot(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    symbol: str
    close: float
    ma_50: float
    ma_200: float
    distribution_days: int
    follow_through_day: bool


class MarketSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    trend: str
    follow_through_day: bool
    indices_above_50dma_ratio: float
    indices_above_200dma_ratio: float
    distribution_day_pressure: float
    health_score: float
    warning_banner: str | None = None
    indices: list[MarketIndexSnapshot] = Field(default_factory=list)


class StockResult(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    ticker: str
    company_name: str
    sector: str
    industry: str
    as_of_date: datetime
    rank: int
    score: float = Field(ge=0, le=100)
    raw_score: float = Field(ge=0, le=100)
    confidence_score: float = Field(ge=0, le=100)
    confidence_label: str
    risk_level: str
    grade: str
    data_source: str
    market_cap_factor: float
    breakdown: dict[str, BreakdownItem]
    strengths: list[str]
    weaknesses: list[str]
    flags: list[str]
    current_price: float | None = None
    current_volume: float | None = None
    average_volume_50d: float | None = None
    fundamentals: dict = Field(default_factory=dict)
    institutional: dict = Field(default_factory=dict)
    catalyst_signals: dict = Field(default_factory=dict)
    recent_headlines: list[str] = Field(default_factory=list)
    sparkline: list[float] = Field(default_factory=list)
    why_this_stock: str
    reason_summary: str
    score_delta: float | None = None
    rank_delta: int | None = None


class ScreeningResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    market: MarketSummary
    results: list[StockResult]
    threshold: float
    scanned_count: int
    last_updated: datetime | None = None
    data_source: str


class RefreshResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    status: str
    triggered_by: str
    scanned_count: int
    last_updated: datetime
    data_source: str


class WatchlistCreate(BaseModel):
    ticker: str
    note: str | None = None


class AlertCreate(BaseModel):
    ticker: str | None = None
    min_score: float | None = Field(default=None, ge=0, le=100)
    top_n_rank: int | None = Field(default=None, ge=1, le=50)


class HistoryPoint(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    date: date
    score: float
    rank: int
    confidence_score: float


class HistoryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    ticker: str
    history: list[HistoryPoint]
