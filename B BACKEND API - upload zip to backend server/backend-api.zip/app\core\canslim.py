from __future__ import annotations

from dataclasses import dataclass


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def linear_ratio(value: float, floor: float, ceiling: float) -> float:
    if value <= floor:
        return 0.0
    if value >= ceiling:
        return 1.0
    return (value - floor) / (ceiling - floor)


def inverse_ratio(value: float, best: float, worst: float) -> float:
    if value <= best:
        return 1.0
    if value >= worst:
        return 0.0
    return 1.0 - ((value - best) / (worst - best))


def trend_bonus(points: list[float], max_bonus: float) -> float:
    if len(points) < 3:
        return 0.0
    return max_bonus if points[-3] < points[-2] < points[-1] else 0.0


@dataclass
class CategoryScore:
    name: str
    score: float
    max_score: float
    strengths: list[str]
    weaknesses: list[str]
    flags: list[str]


class CANSLIMScorer:
    weights = {"C": 20.0, "A": 15.0, "N": 15.0, "S": 10.0, "L": 15.0, "I": 10.0, "M": 15.0}

    def score_current_earnings(self, stock: dict) -> CategoryScore:
        q_eps = stock["current_quarter"]["eps_growth_yoy"]
        q_sales = stock["current_quarter"]["revenue_growth_yoy"]
        q_margin = stock["current_quarter"]["margin_change_bps"]
        recent_eps = stock["current_quarter"].get("recent_eps_growth", [])

        eps_component = 11.0 * linear_ratio(q_eps, 10.0, 100.0)
        sales_component = 5.0 * linear_ratio(q_sales, 10.0, 50.0)
        margin_component = 2.0 * linear_ratio(q_margin, 0.0, 600.0)
        accel_component = trend_bonus(list(recent_eps), 2.0)

        penalty = 0.0
        weaknesses: list[str] = []
        strengths: list[str] = []
        flags: list[str] = []

        if q_eps >= 25:
            strengths.append(f"Quarterly EPS growth is strong at {q_eps:.1f}% YoY")
        else:
            weaknesses.append(f"Quarterly EPS growth is only {q_eps:.1f}% YoY")
            penalty += 1.5

        if q_sales >= 20:
            strengths.append(f"Revenue growth is healthy at {q_sales:.1f}% YoY")
        else:
            weaknesses.append(f"Revenue growth trails CANSLIM preference at {q_sales:.1f}%")
            penalty += 0.75

        if q_margin > 0:
            strengths.append("Operating margin is expanding")
        else:
            weaknesses.append("Margin expansion is absent")
            penalty += 0.75

        if accel_component > 0:
            strengths.append("EPS growth is accelerating across recent quarters")

        total = clamp((eps_component + sales_component + margin_component + accel_component - penalty) / 20.0) * 20.0
        if total < 10:
            flags.append("Current earnings profile is below elite growth-stock standards")
        return CategoryScore("C", round(total, 2), 20.0, strengths, weaknesses, flags)

    def score_annual_earnings(self, stock: dict) -> CategoryScore:
        annual_cagr = stock["annual"]["eps_cagr_3y"]
        roe = stock["annual"]["roe"]
        margin_stability = stock["annual"]["margin_stability"]
        consistency = stock["annual"]["positive_eps_years"]

        cagr_component = 7.0 * linear_ratio(annual_cagr, 10.0, 45.0)
        roe_component = 4.0 * linear_ratio(roe, 10.0, 35.0)
        margin_component = 2.0 * clamp(margin_stability)
        consistency_component = 2.0 * linear_ratio(consistency, 2.0, 5.0)

        penalty = 0.0
        strengths: list[str] = []
        weaknesses: list[str] = []
        flags: list[str] = []

        if annual_cagr >= 25:
            strengths.append(f"Annual EPS CAGR is {annual_cagr:.1f}%")
        else:
            weaknesses.append(f"Annual EPS CAGR is under target at {annual_cagr:.1f}%")
            penalty += 1.0

        if roe >= 17:
            strengths.append(f"ROE clears the CANSLIM hurdle at {roe:.1f}%")
        else:
            weaknesses.append(f"ROE is weak at {roe:.1f}%")
            penalty += 0.75

        if consistency < 4:
            weaknesses.append("Earnings history is inconsistent")
            penalty += 0.75
            flags.append("Inconsistent annual earnings history")
        else:
            strengths.append("Earnings record is consistent")

        total = clamp((cagr_component + roe_component + margin_component + consistency_component - penalty) / 15.0) * 15.0
        return CategoryScore("A", round(total, 2), 15.0, strengths, weaknesses, flags)

    def score_new(self, stock: dict) -> CategoryScore:
        catalysts = stock["new_factors"]
        new_high_pct = stock["technicals"]["distance_to_52w_high_pct"]

        catalyst_score = 0.0
        strengths: list[str] = []
        weaknesses: list[str] = []
        flags: list[str] = []

        for key, label in (
            ("new_product", "New product or service catalyst"),
            ("new_management", "New management catalyst"),
            ("positive_news_sentiment", "Constructive news/sentiment backdrop"),
        ):
            if catalysts.get(key):
                catalyst_score += 3.0
                strengths.append(label)

        high_score = 6.0 * inverse_ratio(abs(new_high_pct), 0.0, 15.0)
        if new_high_pct <= 3:
            strengths.append("Trading near a 52-week high")
        else:
            weaknesses.append("Not near a fresh high")
            if new_high_pct > 10:
                flags.append("Lacks a convincing new-high technical setup")

        total = min(15.0, catalyst_score + high_score)
        return CategoryScore("N", round(total, 2), 15.0, strengths, weaknesses, flags)

    def score_supply_demand(self, stock: dict) -> CategoryScore:
        shares = stock["supply_demand"]["shares_outstanding_m"]
        up_down_volume = stock["supply_demand"]["up_down_volume_ratio"]
        pullback_dryup = stock["supply_demand"]["pullback_volume_dryup"]
        accumulation = stock["supply_demand"]["accumulation_score"]

        shares_component = 2.5 * inverse_ratio(shares, 50.0, 1500.0)
        volume_component = 3.0 * linear_ratio(up_down_volume, 1.0, 2.0)
        dryup_component = 2.0 * clamp(pullback_dryup)
        accumulation_component = 2.5 * clamp(accumulation)

        strengths: list[str] = []
        weaknesses: list[str] = []
        flags: list[str] = []
        penalty = 0.0

        if up_down_volume > 1.2:
            strengths.append("Up-day volume is beating down-day volume")
        else:
            weaknesses.append("Volume confirmation is weak")
            penalty += 0.5

        if accumulation >= 0.65:
            strengths.append("Institutional accumulation pattern is favorable")
        else:
            weaknesses.append("Accumulation is not convincing")

        if shares > 1200:
            weaknesses.append("Very large float reduces scarcity")
            penalty += 0.5

        total = clamp((shares_component + volume_component + dryup_component + accumulation_component - penalty) / 10.0) * 10.0
        if total < 5:
            flags.append("Supply and demand setup is below preferred range")
        return CategoryScore("S", round(total, 2), 10.0, strengths, weaknesses, flags)

    def score_leader(self, stock: dict) -> CategoryScore:
        rs = stock["leadership"]["relative_strength"]
        sector_rank = stock["leadership"]["sector_percentile"]
        industry_rank = stock["leadership"]["industry_percentile"]
        performance_vs_index = stock["leadership"]["performance_vs_index_6m"]

        rs_component = 8.0 * linear_ratio(rs, 60.0, 98.0)
        sector_component = 3.0 * clamp(sector_rank)
        industry_component = 2.0 * clamp(industry_rank)
        perf_component = 2.0 * linear_ratio(performance_vs_index, 0.0, 35.0)

        strengths: list[str] = []
        weaknesses: list[str] = []
        flags: list[str] = []
        penalty = 0.0

        if rs >= 90:
            strengths.append(f"Relative strength is elite at {rs:.0f}")
        elif rs >= 80:
            strengths.append(f"Relative strength is acceptable at {rs:.0f}")
        else:
            weaknesses.append(f"Relative strength is weak at {rs:.0f}")
            penalty += 1.0
            flags.append("Leader/Laggard test is not fully met")

        if sector_rank >= 0.8 and industry_rank >= 0.8:
            strengths.append("Stock sits in a leading sector and industry group")
        else:
            weaknesses.append("Industry leadership is mixed")

        total = clamp((rs_component + sector_component + industry_component + perf_component - penalty) / 15.0) * 15.0
        return CategoryScore("L", round(total, 2), 15.0, strengths, weaknesses, flags)

    def score_institutional(self, stock: dict) -> CategoryScore:
        holders_delta = stock["institutional"]["fund_holders_qoq_change"]
        quality = stock["institutional"]["quality_score"]
        saturation = stock["institutional"]["ownership_pct"]

        holders_component = 4.0 * linear_ratio(holders_delta, -5.0, 30.0)
        quality_component = 4.0 * clamp(quality)
        saturation_component = 2.0 * inverse_ratio(saturation, 25.0, 90.0)

        strengths: list[str] = []
        weaknesses: list[str] = []
        flags: list[str] = []
        penalty = 0.0

        if holders_delta > 0:
            strengths.append("Institutional sponsorship is increasing")
        else:
            weaknesses.append("Institutional holder count is falling")
            penalty += 0.75

        if saturation > 85:
            weaknesses.append("Ownership appears crowded")
            penalty += 0.5
            flags.append("Institutional sponsorship may be saturated")

        total = clamp((holders_component + quality_component + saturation_component - penalty) / 10.0) * 10.0
        return CategoryScore("I", round(total, 2), 10.0, strengths, weaknesses, flags)

    def score_market(self, market: dict) -> CategoryScore:
        trend = market["trend"]
        ftd = market["follow_through_day"]
        above_50 = market["indices_above_50dma_ratio"]
        above_200 = market["indices_above_200dma_ratio"]
        distribution = market["distribution_day_pressure"]

        trend_component = 6.0 if trend == "confirmed_uptrend" else 3.0 if trend == "uptrend_under_pressure" else 0.5
        ftd_component = 3.0 if ftd else 0.0
        ma_component = 4.0 * (0.6 * clamp(above_50) + 0.4 * clamp(above_200))
        distribution_component = 2.0 * inverse_ratio(distribution, 1.0, 6.0)

        strengths: list[str] = []
        weaknesses: list[str] = []
        flags: list[str] = []

        if trend == "confirmed_uptrend":
            strengths.append("General market is in a confirmed uptrend")
        elif trend == "uptrend_under_pressure":
            weaknesses.append("Market uptrend is under pressure")
            flags.append("Position sizing should stay selective")
        else:
            weaknesses.append("General market is not in a confirmed uptrend")
            flags.append("Not in confirmed uptrend")

        if ftd:
            strengths.append("Follow-through day condition is present")
        else:
            weaknesses.append("No recent follow-through day confirmation")

        total = clamp((trend_component + ftd_component + ma_component + distribution_component) / 15.0) * 15.0
        return CategoryScore("M", round(total, 2), 15.0, strengths, weaknesses, flags)

    def final_score(self, stock: dict, market: dict) -> dict:
        categories = [
            self.score_current_earnings(stock),
            self.score_annual_earnings(stock),
            self.score_new(stock),
            self.score_supply_demand(stock),
            self.score_leader(stock),
            self.score_institutional(stock),
            self.score_market(market),
        ]

        market_score = next(category.score for category in categories if category.name == "M")
        market_cap_factor = 1.0 if market["trend"] == "confirmed_uptrend" else 0.8
        raw_total = sum(category.score for category in categories)
        total = round(raw_total * market_cap_factor, 2)

        strengths = [item for category in categories for item in category.strengths][:6]
        weaknesses = [item for category in categories for item in category.weaknesses][:6]
        flags = list(dict.fromkeys(item for category in categories for item in category.flags))

        return {
            "score": total,
            "raw_score": round(raw_total, 2),
            "market_cap_factor": market_cap_factor,
            "breakdown": {category.name: {"score": category.score, "max_score": category.max_score} for category in categories},
            "strengths": strengths,
            "weaknesses": weaknesses,
            "flags": flags,
        }
