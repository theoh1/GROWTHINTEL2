from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

from app.data.universe import UNIVERSE_PRESETS


class Settings(BaseSettings):
    app_name: str = "CANSLIM Screener"
    api_v1_prefix: str = "/api/v1"
    database_url: str = "sqlite:///./canslim.db"
    frontend_origin: str = "http://localhost:3000"
    market_proxy_symbol: str = "QQQ"
    sp500_symbol: str = "SPY"
    use_mock_data: bool = False
    alpha_vantage_api_key: str | None = None
    openai_api_key: str | None = None
    openai_model: str = "gpt-5.4"
    local_ai_model: str = "Phi-3-mini-4k-instruct.Q4_0.gguf"
    alpha_vantage_rate_limit_per_minute: int = 75
    fmp_api_key: str | None = None
    youtube_api_key: str | None = None
    default_screen_universe: str = "FULL_US_FREE"
    universe_scan_budget: int = 1400
    breakout_scan_budget: int = 48
    breakout_results_limit: int = 20
    prefilter_batch_size: int = 300
    deep_analysis_max_symbols: int = 120
    price_cache_hours: int = 24
    financial_cache_hours: int = 24 * 90
    schedule_enabled: bool = True
    daily_refresh_hour: int = 9
    daily_refresh_minute: int = 0
    scheduler_timezone: str = "Europe/London"
    request_timeout_seconds: int = 30
    slow_request_ms: int = 2500
    rate_limit_per_minute: int = 180

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    @property
    def default_screen_universe_list(self) -> list[str]:
        preset = UNIVERSE_PRESETS.get(self.default_screen_universe.strip().upper())
        if preset:
            raw = preset
        else:
            raw = [ticker.strip().upper() for ticker in self.default_screen_universe.split(",") if ticker.strip()]

        deduped: list[str] = []
        seen: set[str] = set()
        for ticker in raw:
            normalized = ticker.strip().upper()
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            deduped.append(normalized)
        return deduped


@lru_cache
def get_settings() -> Settings:
    return Settings()
