from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import yfinance as yf

from app.modules.portfolio.services.trend_analysis import analyze_trend
from app.modules.portfolio.services.volume_analysis import analyze_volume


def _safe_number(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _history(symbol: str, period: str = "6mo"):
    try:
        return yf.Ticker(symbol).history(period=period, auto_adjust=True)
    except Exception:
        return None


def _payload_alert(ticker: str | None, position_id: str | None, item: dict, now_iso: str) -> dict:
    base_ticker = ticker or "PORTFOLIO"
    code = item.get("code", "event")
    return {
        "id": f"{base_ticker}:{code}",
        "position_id": position_id,
        "ticker": base_ticker,
        "alert_type": item["alert_type"],
        "message": item["message"],
        "severity": item["severity"],
        "timestamp": now_iso,
    }


def _price_alerts(position: dict, current_price: float, now_iso: str, thresholds: dict[str, Any]) -> list[dict]:
    ticker = str(position.get("ticker", "")).upper()
    position_id = position.get("id")
    entry = _safe_number(position.get("entryPrice"))
    stop = _safe_number(position.get("stopLoss"))
    buy_point = _safe_number(position.get("buyPoint"), 0.0)
    profit_marks = thresholds.get("profitMilestones", [5, 10, 20])
    near_stop_pct = _safe_number(thresholds.get("nearStopPct", 2.0), 2.0)

    alerts: list[dict] = []
    if stop > 0:
        pct_from_stop = ((current_price - stop) / stop) * 100.0
        if pct_from_stop <= 0:
            alerts.append(_payload_alert(ticker, position_id, {"alert_type": "Price Alert", "message": "Price hit or broke below stop loss.", "severity": "red", "code": "stop_hit"}, now_iso))
        elif pct_from_stop <= near_stop_pct:
            alerts.append(_payload_alert(ticker, position_id, {"alert_type": "Price Alert", "message": f"Price is within {near_stop_pct:.1f}% of stop loss.", "severity": "yellow", "code": "near_stop"}, now_iso))

    if entry > 0:
        move_pct = ((current_price - entry) / entry) * 100.0
        for milestone in profit_marks:
            mark = _safe_number(milestone)
            if mark <= 0:
                continue
            if move_pct >= mark:
                alerts.append(
                    _payload_alert(
                        ticker,
                        position_id,
                        {"alert_type": "Price Alert", "message": f"Profit milestone reached: +{int(mark)}%.", "severity": "green", "code": f"profit_{int(mark)}"},
                        now_iso,
                    )
                )

    if buy_point > 0:
        # Breakout failure check handled with history where available.
        pass
    return alerts


def _relative_weakness_alerts(ticker: str, position_id: str | None, closes: list[float], spy_closes: list[float], now_iso: str, thresholds: dict[str, Any]) -> list[dict]:
    if len(closes) < 25 or len(spy_closes) < 25:
        return []
    stock_ret = ((closes[-1] - closes[-21]) / closes[-21]) * 100 if closes[-21] else 0.0
    spy_ret = ((spy_closes[-1] - spy_closes[-21]) / spy_closes[-21]) * 100 if spy_closes[-21] else 0.0
    gap = stock_ret - spy_ret
    weakness_threshold = _safe_number(thresholds.get("relativeWeaknessThreshold", -8.0), -8.0)
    if gap <= weakness_threshold:
        return [
            _payload_alert(
                ticker,
                position_id,
                {
                    "alert_type": "Losing Leadership",
                    "message": f"Stock underperformed the market by {abs(gap):.1f}% over the last month.",
                    "severity": "yellow",
                    "code": "relative_weakness",
                },
                now_iso,
            )
        ]
    return []


def _breakout_failure_alerts(position: dict, ticker: str, position_id: str | None, closes: list[float], now_iso: str) -> list[dict]:
    buy_point = _safe_number(position.get("buyPoint"), 0.0)
    if buy_point <= 0 or len(closes) < 12:
        return []
    recent_high = max(closes[-10:])
    current = closes[-1]
    if recent_high >= buy_point * 1.01 and current < buy_point:
        return [
            _payload_alert(
                ticker,
                position_id,
                {
                    "alert_type": "Failed Breakout",
                    "message": "Stock broke out but fell back below buy point.",
                    "severity": "red",
                    "code": "failed_breakout",
                },
                now_iso,
            )
        ]
    return []


def evaluate_alerts(positions: list[dict], settings: dict | None = None, alert_settings: dict | None = None) -> dict:
    now_iso = datetime.now(timezone.utc).isoformat()
    settings = settings or {}
    alert_settings = alert_settings or {}
    enabled_types = alert_settings.get("enabledTypes", {}) if isinstance(alert_settings.get("enabledTypes", {}), dict) else {}
    thresholds = alert_settings.get("thresholds", {}) if isinstance(alert_settings.get("thresholds", {}), dict) else {}

    alerts: list[dict] = []
    by_position: dict[str, list[dict]] = {}
    spy_history = _history("SPY", period="6mo")
    spy_closes = spy_history["Close"].dropna().tolist() if spy_history is not None and not spy_history.empty else []

    total_risk_pct = 0.0
    account_size = _safe_number(settings.get("accountSize"), 0.0)
    open_positions = len(positions)
    max_positions = int(_safe_number(thresholds.get("maxPositions", 10), 10))
    portfolio_risk_limit = _safe_number(thresholds.get("portfolioRiskLimitPct", 8), 8)
    single_risk_limit = _safe_number(thresholds.get("singlePositionRiskLimitPct", 2), 2)
    volume_spike_mult = _safe_number(thresholds.get("volumeSpikeMultiplier", 1.5), 1.5)

    for position in positions:
        ticker = str(position.get("ticker", "")).strip().upper()
        position_id = str(position.get("id", "")) or None
        if not ticker:
            continue

        history = _history(ticker, period="6mo")
        if history is None or history.empty:
            continue
        closes = history["Close"].dropna().tolist()
        volumes = history["Volume"].fillna(0).tolist()
        if not closes:
            continue
        current_price = closes[-1]

        entry = _safe_number(position.get("entryPrice"))
        stop = _safe_number(position.get("stopLoss"))
        shares = _safe_number(position.get("shares"))
        risk_amount = max(0.0, (entry - stop) * shares)
        risk_pct = ((risk_amount / account_size) * 100.0) if account_size > 0 else 0.0
        total_risk_pct += risk_pct

        position_alerts: list[dict] = []

        if enabled_types.get("priceAlerts", True):
            position_alerts.extend(_price_alerts(position, current_price, now_iso, thresholds))
        if enabled_types.get("trendAlerts", True):
            position_alerts.extend(
                _payload_alert(ticker, position_id, item, now_iso)
                for item in analyze_trend(closes, volumes, current_price, thresholds)
            )
        if enabled_types.get("volumeAlerts", True):
            position_alerts.extend(
                _payload_alert(ticker, position_id, item, now_iso)
                for item in analyze_volume(closes, volumes, volume_spike_mult)
            )
        if enabled_types.get("breakoutFailureAlerts", True):
            position_alerts.extend(_breakout_failure_alerts(position, ticker, position_id, closes, now_iso))
        if enabled_types.get("relativeWeaknessAlerts", True):
            position_alerts.extend(_relative_weakness_alerts(ticker, position_id, closes, spy_closes, now_iso, thresholds))
        if enabled_types.get("riskAlerts", True) and risk_pct > single_risk_limit:
            position_alerts.append(
                _payload_alert(
                    ticker,
                    position_id,
                    {
                        "alert_type": "Risk Alert",
                        "message": f"Single-position risk is {risk_pct:.2f}% of account, above {single_risk_limit:.2f}%.",
                        "severity": "red",
                        "code": "single_risk_high",
                    },
                    now_iso,
                )
            )

        if position_alerts:
            unique = list({item["id"]: item for item in position_alerts}.values())
            by_position[position_id or ticker] = unique
            alerts.extend(unique)

    if enabled_types.get("riskAlerts", True):
        if total_risk_pct > portfolio_risk_limit:
            alerts.append(
                _payload_alert(
                    None,
                    None,
                    {
                        "alert_type": "Risk Alert",
                        "message": f"Portfolio risk exposure is {total_risk_pct:.2f}%, above the {portfolio_risk_limit:.2f}% limit.",
                        "severity": "red",
                        "code": "portfolio_risk_high",
                    },
                    now_iso,
                )
            )
        elif total_risk_pct > portfolio_risk_limit * 0.75:
            alerts.append(
                _payload_alert(
                    None,
                    None,
                    {
                        "alert_type": "Risk Alert",
                        "message": f"Portfolio risk exposure is elevated at {total_risk_pct:.2f}%.",
                        "severity": "yellow",
                        "code": "portfolio_risk_elevated",
                    },
                    now_iso,
                )
            )

        if open_positions > max_positions:
            alerts.append(
                _payload_alert(
                    None,
                    None,
                    {
                        "alert_type": "Risk Alert",
                        "message": f"Open positions ({open_positions}) exceed max positions setting ({max_positions}).",
                        "severity": "yellow",
                        "code": "too_many_positions",
                    },
                    now_iso,
                )
            )

    severity_rank = {"red": 0, "yellow": 1, "green": 2}
    alerts = sorted({item["id"]: item for item in alerts}.values(), key=lambda item: severity_rank.get(item["severity"], 3))

    return {
        "last_updated": now_iso,
        "alerts": alerts,
        "by_position": by_position,
        "summary": {
            "total_alerts": len(alerts),
            "critical": sum(1 for item in alerts if item["severity"] == "red"),
            "warnings": sum(1 for item in alerts if item["severity"] == "yellow"),
            "info": sum(1 for item in alerts if item["severity"] == "green"),
            "portfolio_risk_pct": round(total_risk_pct, 3),
            "open_positions": open_positions,
        },
    }
