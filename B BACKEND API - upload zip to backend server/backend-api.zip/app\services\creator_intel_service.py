from __future__ import annotations

import math
import re
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any

import httpx

from app.core.config import get_settings
from app.repositories.screening_repository import ScreeningRepository


STARTER_CHANNELS = [
    ("MarketBeat", 82, "UCDMRj2UMCY4Jp49Waf_2X9g"),
    ("Zacks Investment Research", 86, None),
    ("The Motley Fool", 74, None),
    ("Schwab Network", 88, "UCqoSrYgusd8ZddtMoWhjHYA"),
    ("CNBC Television", 78, "UCrp_UI8XtuYfpiqluWLD7Lw"),
    ("Yahoo Finance", 80, "UCEAZeUIeJs0IjQiqTCdVSIg"),
    ("Benzinga", 72, None),
    ("Investor's Business Daily", 90, "UC5fZv7bPcF5j2RsfO-9OiLA"),
    ("Seeking Alpha", 84, "UC9ZGkLwawKeG5C0Dt9FS-lQ"),
    ("Barron's", 86, None),
    ("Bloomberg Television", 88, "UCIALMKvObZNtJ6AmdCLP7Lg"),
    ("Stock Market Live", 68, None),
    ("Everything Money", 82, "UChBVf9YnourrEDTsbbwJPRA"),
    ("Joseph Carlson", 78, "UCbta0n8i6Rljh0obO7HzG9A"),
    ("Ticker Symbol: YOU", 76, "UC7kCeZ53sli_9XwuQeFxLqw"),
    ("HyperChange", 70, None),
    ("MyWallSt", 74, None),
    ("Best of Us Investors", 72, None),
    ("Financial Education", 62, None),
    ("Meet Kevin", 60, None),
    ("ZipTrader", 58, None),
    ("Stock Moe", 56, None),
    ("Larry Jones / Stock Up", 56, None),
    ("Paul Barron Network", 64, None),
    ("The Trading Fraternity", 62, None),
    ("Figuring Out Money", 80, None),
    ("Sven Carlin", 86, "UCrTTBSUr0zhPU56UQljag5A"),
    ("New Money", 76, None),
    ("Adam Khoo", 82, "UCK-aOjEvZNJl3HINja0gAiQ"),
    ("TradingLab", 72, None),
]

COMMON_WORDS = {
    "A",
    "AI",
    "ALL",
    "AND",
    "ARE",
    "AS",
    "AT",
    "BE",
    "BY",
    "CEO",
    "CPI",
    "ETF",
    "EPS",
    "FOR",
    "FROM",
    "GDP",
    "IN",
    "IPO",
    "IS",
    "IT",
    "NEW",
    "NOW",
    "OF",
    "ON",
    "OR",
    "PE",
    "SEC",
    "THE",
    "TO",
    "USA",
    "WAS",
    "WITH",
}
POSITIVE_TERMS = {"buy", "bull", "bullish", "breakout", "undervalued", "surging", "beats", "growth", "opportunity", "upside"}
NEGATIVE_TERMS = {"sell", "bear", "bearish", "crash", "risk", "overvalued", "miss", "warning", "avoid", "downside"}
THEME_MAP = {
    "ai": "AI / Tech",
    "semiconductor": "Semiconductors",
    "chip": "Semiconductors",
    "dividend": "Dividend Stocks",
    "earnings": "Earnings Related",
    "growth": "Growth Stocks",
    "market": "Market",
}
COMPANY_TICKER_ALIASES = {
    "adobe": "ADBE",
    "alphabet": "GOOGL",
    "amazon": "AMZN",
    "amd": "AMD",
    "apple": "AAPL",
    "broadcom": "AVGO",
    "coinbase": "COIN",
    "costco": "COST",
    "crowdstrike": "CRWD",
    "eli lilly": "LLY",
    "google": "GOOGL",
    "meta": "META",
    "microsoft": "MSFT",
    "micron": "MU",
    "netflix": "NFLX",
    "nvidia": "NVDA",
    "novo nordisk": "NVO",
    "on semiconductor": "ON",
    "palantir": "PLTR",
    "paypal": "PYPL",
    "robinhood": "HOOD",
    "salesforce": "CRM",
    "super micro": "SMCI",
    "tesla": "TSLA",
    "tsmc": "TSM",
    "walmart": "WMT",
}


def _channel_payload(name: str, trust_score: int, channel_id: str | None = None, verified: bool = False) -> dict[str, Any]:
    return {
        "name": name,
        "channel_id": channel_id,
        "verified": verified,
        "trust_score": trust_score,
        "trust_basis": [
            "Evidence/data orientation",
            "Balanced risk discussion",
            "Analysis focus over hype",
        ],
    }


def _strip_comparative_aliases(text: str, known_tickers: set[str] | None = None) -> str:
    cleaned = text
    comparative_tokens = [*COMPANY_TICKER_ALIASES.keys(), *(known_tickers or set())]
    for token in comparative_tokens:
        cleaned = re.sub(rf"\b(next|new|another|like|than|bigger than|better than)\s+{re.escape(token)}\b", " ", cleaned, flags=re.IGNORECASE)
    return cleaned


def _extract_explicit_tickers(text: str, known_tickers: set[str]) -> list[str]:
    exchange_tickers = re.findall(r"\b(?:NASDAQ|NYSE|AMEX|CBOE|OTC|NYSEARCA)\s*:\s*([A-Z]{1,5})\b", text.upper())
    cashtags = re.findall(r"(?<![A-Z])\$([A-Z]{1,5})(?![A-Z])", text)
    raw_words = re.findall(r"(?<![A-Za-z])([A-Z]{2,5})(?![A-Za-z])", text)
    raw = [*exchange_tickers, *cashtags, *raw_words]
    tickers = []
    for item in raw:
        if item in COMMON_WORDS:
            continue
        if item in exchange_tickers and item not in tickers:
            tickers.append(item)
            continue
        if item in known_tickers and item not in tickers:
            tickers.append(item)
    return tickers


def _extract_company_alias_tickers(text: str, known_tickers: set[str]) -> list[str]:
    lower = _strip_comparative_aliases(text, known_tickers).lower()
    tickers = []
    for company, ticker in COMPANY_TICKER_ALIASES.items():
        if company in lower and ticker in known_tickers and ticker not in tickers:
            tickers.append(ticker)
    return tickers


def _append_unique(target: list[str], items: list[str]) -> None:
    for item in items:
        if item not in target:
            target.append(item)


def _extract_ticker_evidence(title: str, description: str, transcript: str, known_tickers: set[str]) -> tuple[list[str], list[str]]:
    tickers: list[str] = []
    sources: list[str] = []
    # Titles are often teasers ("the next Nvidia"), so only explicit tickers/cashtags count there.
    title_without_comparisons = _strip_comparative_aliases(title, known_tickers)
    title_tickers = _extract_explicit_tickers(title_without_comparisons, known_tickers)
    if title_tickers:
        _append_unique(tickers, title_tickers)
        sources.append("title ticker")

    description_tickers = [*_extract_explicit_tickers(description, known_tickers), *_extract_company_alias_tickers(description, known_tickers)]
    if description_tickers:
        _append_unique(tickers, description_tickers)
        sources.append("description")

    transcript_tickers = [*_extract_explicit_tickers(transcript, known_tickers), *_extract_company_alias_tickers(transcript, known_tickers)]
    if transcript_tickers:
        _append_unique(tickers, transcript_tickers)
        sources.append("captions")
    return tickers[:10], sources


def _extract_tickers(title: str, description: str, known_tickers: set[str]) -> list[str]:
    tickers, _sources = _extract_ticker_evidence(title, description, "", known_tickers)
    return tickers


def _sentiment(text: str) -> str:
    lower = text.lower()
    pos = sum(1 for term in POSITIVE_TERMS if term in lower)
    neg = sum(1 for term in NEGATIVE_TERMS if term in lower)
    if pos > neg:
        return "Bullish"
    if neg > pos:
        return "Bearish"
    return "Neutral"


def _theme(text: str) -> str:
    lower = text.lower()
    for needle, label in THEME_MAP.items():
        if needle in lower:
            return label
    return "General Market"


def _days_old(published_at: str | None) -> float:
    if not published_at:
        return 14
    try:
        published = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
        return max(0.0, (datetime.now(timezone.utc) - published).total_seconds() / 86400)
    except ValueError:
        return 14


async def _youtube_get(client: httpx.AsyncClient, path: str, params: dict[str, Any]) -> dict[str, Any]:
    settings = get_settings()
    response = await client.get(
        f"https://www.googleapis.com/youtube/v3/{path}",
        params={**params, "key": settings.youtube_api_key},
    )
    response.raise_for_status()
    return response.json()


def _video_summary(tickers: list[str], sources: list[str], transcript_checked: bool) -> tuple[str, int]:
    if "captions" in sources:
        return "Confirmed from available captions/transcript. No long transcript is stored or shown.", 82
    if "description" in sources:
        return "Confirmed from the official video description. Captions were checked where available.", 68
    if "title ticker" in sources:
        return "Confirmed from an explicit ticker in the title. Teaser comparisons are ignored.", 58
    if transcript_checked:
        return "Scanned official video metadata and available captions; no stock ticker was confirmed.", 38
    return "Scanned official video metadata; captions were not available for this video.", 32


async def _fetch_caption_text(client: httpx.AsyncClient, video_id: str | None) -> tuple[str, bool]:
    if not video_id:
        return "", False
    try:
        list_response = await client.get(
            "https://www.youtube.com/api/timedtext",
            params={"type": "list", "v": video_id},
        )
        list_response.raise_for_status()
        if not list_response.text.strip():
            return "", True
        root = ET.fromstring(list_response.text)
        tracks = root.findall("track")
        if not tracks:
            return "", True
        track = next((item for item in tracks if (item.get("lang_code") or "").startswith("en")), tracks[0])
        params = {
            "v": video_id,
            "lang": track.get("lang_code") or "en",
            "fmt": "json3",
        }
        if track.get("name"):
            params["name"] = track.get("name")
        transcript_response = await client.get("https://www.youtube.com/api/timedtext", params=params)
        transcript_response.raise_for_status()
        data = transcript_response.json()
        chunks = []
        for event in data.get("events", []):
            text = "".join(segment.get("utf8", "") for segment in event.get("segs", [])).strip()
            if text:
                chunks.append(text)
        return " ".join(chunks), True
    except Exception:
        return "", False


async def _fetch_youtube_mentions(channels: list[dict[str, Any]], known_tickers: set[str]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    settings = get_settings()
    if not settings.youtube_api_key:
        return channels, []

    verified_channels: list[dict[str, Any]] = []
    videos: list[dict[str, Any]] = []
    async with httpx.AsyncClient(timeout=18.0) as client:
        for channel in channels:
            search = await _youtube_get(
                client,
                "search",
                {"part": "snippet", "type": "channel", "maxResults": 1, "q": channel["name"]},
            )
            item = (search.get("items") or [None])[0]
            channel_id = ((item or {}).get("snippet") or {}).get("channelId")
            verified = bool(channel_id)
            verified_channel = {**channel, "channel_id": channel_id, "verified": verified}
            verified_channels.append(verified_channel)
            if not channel_id:
                continue
            recent = await _youtube_get(
                client,
                "search",
                {"part": "snippet", "channelId": channel_id, "type": "video", "order": "date", "maxResults": 4},
            )
            video_ids = [entry.get("id", {}).get("videoId") for entry in recent.get("items", []) if entry.get("id", {}).get("videoId")]
            stats_by_id: dict[str, dict[str, Any]] = {}
            if video_ids:
                stats = await _youtube_get(
                    client,
                    "videos",
                    {"part": "statistics,snippet", "id": ",".join(video_ids), "maxResults": 4},
                )
                stats_by_id = {entry.get("id"): entry for entry in stats.get("items", [])}
            for entry in recent.get("items", []):
                snippet = entry.get("snippet", {})
                video_id = entry.get("id", {}).get("videoId")
                stat_entry = stats_by_id.get(video_id or "", {})
                title = snippet.get("title", "")
                description = snippet.get("description", "")
                transcript, transcript_checked = await _fetch_caption_text(client, video_id)
                text = f"{title} {description} {transcript}"
                tickers, evidence_sources = _extract_ticker_evidence(title, description, transcript, known_tickers)
                summary, confidence = _video_summary(tickers, evidence_sources, transcript_checked)
                videos.append(
                    {
                        "id": video_id,
                        "title": title,
                        "channel": channel["name"],
                        "channel_id": channel_id,
                        "upload_date": snippet.get("publishedAt"),
                        "view_count": int((stat_entry.get("statistics") or {}).get("viewCount") or 0),
                        "tickers": tickers,
                        "company_names": [],
                        "theme": _theme(text),
                        "sentiment": {ticker: _sentiment(text) for ticker in tickers},
                        "summary": summary,
                        "confidence": confidence,
                        "evidence_sources": evidence_sources,
                        "transcript_checked": transcript_checked,
                    }
                )
    return verified_channels, videos


def _entry_text(entry: ET.Element, namespaces: dict[str, str], tag: str) -> str:
    node = entry.find(tag, namespaces)
    return (node.text or "").strip() if node is not None else ""


async def _fetch_rss_mentions(channels: list[dict[str, Any]], known_tickers: set[str]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    verified_channels: list[dict[str, Any]] = []
    videos: list[dict[str, Any]] = []
    namespaces = {
        "atom": "http://www.w3.org/2005/Atom",
        "yt": "http://www.youtube.com/xml/schemas/2015",
        "media": "http://search.yahoo.com/mrss/",
    }

    async with httpx.AsyncClient(timeout=12.0, follow_redirects=True) as client:
        for channel in channels:
            channel_id = channel.get("channel_id")
            if not channel_id:
                verified_channels.append({**channel, "verified": False})
                continue
            try:
                response = await client.get(f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}")
                response.raise_for_status()
                root = ET.fromstring(response.text)
            except Exception:
                verified_channels.append({**channel, "verified": False})
                continue

            author = _entry_text(root, namespaces, "atom:author/atom:name") or channel["name"]
            verified_channels.append({**channel, "name": author, "verified": True})
            for entry in root.findall("atom:entry", namespaces)[:8]:
                title = _entry_text(entry, namespaces, "atom:title")
                published = _entry_text(entry, namespaces, "atom:published")
                if _days_old(published) > 7:
                    continue
                description = _entry_text(entry, namespaces, "media:group/media:description")
                video_id = _entry_text(entry, namespaces, "yt:videoId") or None
                transcript, transcript_checked = await _fetch_caption_text(client, video_id)
                text = f"{title} {description} {transcript}"
                tickers, evidence_sources = _extract_ticker_evidence(title, description, transcript, known_tickers)
                summary, confidence = _video_summary(tickers, evidence_sources, transcript_checked)
                videos.append(
                    {
                        "id": video_id,
                        "title": title,
                        "channel": author,
                        "channel_id": channel_id,
                        "upload_date": published,
                        "view_count": None,
                        "tickers": tickers,
                        "company_names": [],
                        "theme": _theme(text),
                        "sentiment": {ticker: _sentiment(text) for ticker in tickers},
                        "summary": summary,
                        "confidence": confidence,
                        "evidence_sources": evidence_sources,
                        "transcript_checked": transcript_checked,
                    }
                )
    return verified_channels, videos


def _build_trending(videos: list[dict[str, Any]], channels: list[dict[str, Any]], repository: ScreeningRepository) -> list[dict[str, Any]]:
    rows = {row.ticker: row for row in repository.latest_scan_rows(threshold=0, limit=800)}
    trust_by_channel = {channel["name"]: channel["trust_score"] for channel in channels}
    mentions: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for video in videos:
        for ticker in video["tickers"]:
            mentions[ticker].append(video)

    trending = []
    for ticker, items in mentions.items():
        unique_channels = sorted({item["channel"] for item in items})
        sentiment_counts = Counter((item.get("sentiment") or {}).get(ticker, "Neutral") for item in items)
        sentiment = "Mixed" if len([count for count in sentiment_counts.values() if count]) > 1 else (sentiment_counts.most_common(1)[0][0] if sentiment_counts else "Neutral")
        latest = min(_days_old(item.get("upload_date")) for item in items)
        avg_trust = sum(trust_by_channel.get(item["channel"], 60) for item in items) / max(1, len(items))
        stock = rows.get(ticker)
        growth_confirmation = min(100, stock.score if stock else 0)
        freshness = max(0, 100 - latest * 9)
        sentiment_strength = {"Bullish": 82, "Bearish": 68, "Neutral": 48, "Mixed": 58}.get(sentiment, 50)
        consensus = round(
            min(
                100,
                len(unique_channels) * 10
                + math.log1p(len(items)) * 10
                + freshness * 0.16
                + avg_trust * 0.18
                + sentiment_strength * 0.12
                + growth_confirmation * 0.16,
            )
        )
        trending.append(
            {
                "ticker": ticker,
                "company_name": stock.company_name if stock else ticker,
                "mention_count": len(items),
                "unique_channels": len(unique_channels),
                "sentiment": sentiment,
                "top_channels": unique_channels[:4],
                "most_recent_mention": min((item.get("upload_date") for item in items if item.get("upload_date")), default=None),
                "creator_consensus": consensus,
                "creator_interest": "High" if consensus >= 75 else "Medium" if consensus >= 45 else "Low",
                "data_confirmation": "Strong" if growth_confirmation >= 75 else "Mixed" if growth_confirmation >= 45 else "Weak",
                "growthintel": {
                    "canslim_score": round(stock.score, 1) if stock else None,
                    "engine_rating": "Add" if stock and stock.score >= 80 else "Hold" if stock and stock.score >= 55 else "Trim",
                    "market_regime_fit": "Strong" if stock and stock.score >= 75 else "Mixed" if stock else "Unknown",
                },
            }
        )
    return sorted(trending, key=lambda item: item["creator_consensus"], reverse=True)


async def build_creator_intel_payload(repository: ScreeningRepository) -> dict[str, Any]:
    channels = [_channel_payload(name, trust_score, channel_id) for name, trust_score, channel_id in STARTER_CHANNELS]
    known_tickers = {row.ticker for row in repository.latest_scan_rows(threshold=0, limit=1200)}
    settings = get_settings()
    try:
        if settings.youtube_api_key:
            channels, videos = await _fetch_youtube_mentions(channels, known_tickers)
        else:
            channels, videos = await _fetch_rss_mentions(channels, known_tickers)
        api_error = None
    except Exception as exc:
        channels, videos = await _fetch_rss_mentions(channels, known_tickers)
        api_error = None if videos else "YouTube creator data is temporarily unavailable. Try again later."
    trending = _build_trending(videos, channels, repository)
    source_label = "YouTube Data API" if settings.youtube_api_key else "official YouTube channel RSS feeds"
    has_verified_source = any(channel.get("verified") for channel in channels)
    return {
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "configured": bool(settings.youtube_api_key or has_verified_source),
        "api_error": api_error,
        "channels_tracked": len(channels),
        "channels": channels,
        "videos_scanned_this_week": len(videos),
        "videos": videos,
        "trending": trending,
        "highest_consensus_stock": trending[0]["ticker"] if trending else None,
        "summary": {
            "market_pulse": "No recent creator mention data is available yet." if not videos else f"{len(trending)} stocks were mentioned using {source_label}. Cross-check consensus against GrowthIntel data before acting.",
            "hype_warnings": [],
            "disagreements": [item for item in trending if item["creator_interest"] == "High" and item["data_confirmation"] != "Strong"][:5],
        },
    }
