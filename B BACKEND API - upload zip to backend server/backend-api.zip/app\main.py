import asyncio
import logging
import sys
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import router
from app.core.config import get_settings
from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.pipeline.run_daily_scan import run_daily_scan
from app.repositories.screening_repository import ScreeningRepository
from app.tasks.scheduler import build_scheduler


settings = get_settings()
scheduler = None
START_TIME = time.time()
RATE_LIMIT_BUCKETS: dict[str, deque[float]] = defaultdict(deque)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("growthintel")


def _log_unhandled_exception(exc_type, exc_value, exc_traceback):
    logger.critical("Unhandled process exception", exc_info=(exc_type, exc_value, exc_traceback))


sys.excepthook = _log_unhandled_exception


async def run_daily_refresh():
    db = SessionLocal()
    try:
        repository = ScreeningRepository(db)
        await run_daily_scan(repository, triggered_by="scheduler")
    except Exception:
        logger.exception("Scheduled daily refresh failed; future jobs will continue")
    finally:
        db.close()


@asynccontextmanager
async def lifespan(_: FastAPI):
    global scheduler
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database metadata ready")
    except Exception:
        logger.exception("Database startup check failed")
    try:
        loop = asyncio.get_running_loop()
        loop.set_exception_handler(lambda _, context: logger.error("Async background error: %s", context.get("message"), exc_info=context.get("exception")))
    except RuntimeError:
        pass
    if settings.schedule_enabled:
        try:
            scheduler = build_scheduler(run_daily_refresh)
            scheduler.start()
            logger.info("Scheduler started")
        except Exception:
            logger.exception("Scheduler failed to start")
    yield
    if scheduler:
        scheduler.shutdown(wait=False)


app = FastAPI(title=settings.app_name, lifespan=lifespan)

allowed_origins = [
    "http://127.0.0.1:3040",
    "http://localhost:3040",
    "http://127.0.0.1:3000",
    "http://localhost:3000",
    "http://127.0.0.1:5173",
    "http://localhost:5173",
    "https://your-frontend-domain.com",
    "https://www.your-frontend-domain.com",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def reliability_middleware(request: Request, call_next):
    started = time.perf_counter()
    client = request.client.host if request.client else "unknown"
    now = time.time()
    bucket = RATE_LIMIT_BUCKETS[client]
    while bucket and now - bucket[0] > 60:
        bucket.popleft()
    if request.url.path != f"{settings.api_v1_prefix}/health":
        bucket.append(now)
    if len(bucket) > settings.rate_limit_per_minute:
        logger.warning("Rate limit exceeded client=%s path=%s", client, request.url.path)
        return JSONResponse(
            status_code=429,
            content={"detail": "Too many requests. Please wait a moment and retry."},
        )

    long_running_paths = {
        f"{settings.api_v1_prefix}/ai/assistant",
        f"{settings.api_v1_prefix}/creator-intel",
        f"{settings.api_v1_prefix}/early-view",
    }
    request_timeout = 180 if request.url.path in long_running_paths else settings.request_timeout_seconds
    try:
        response = await asyncio.wait_for(call_next(request), timeout=request_timeout)
    except asyncio.TimeoutError:
        logger.exception("Request timed out path=%s", request.url.path)
        return JSONResponse(
            status_code=504,
            content={"detail": "Live data is temporarily slow. Please retry."},
        )
    except Exception:
        logger.exception("Unhandled request error path=%s", request.url.path)
        return JSONResponse(
            status_code=500,
            content={"detail": "Live data is temporarily unavailable. Try refreshing."},
        )

    elapsed_ms = round((time.perf_counter() - started) * 1000, 1)
    response.headers["X-Response-Time-Ms"] = str(elapsed_ms)
    if elapsed_ms >= settings.slow_request_ms:
        logger.warning("Slow request %.1fms %s", elapsed_ms, request.url.path)
    return response


@app.get("/_internal/uptime")
async def internal_uptime():
    return {
        "status": "ok",
        "uptime_seconds": round(time.time() - START_TIME, 1),
        "scheduler_enabled": settings.schedule_enabled,
        "scheduler_running": bool(scheduler and scheduler.running),
    }


app.include_router(router, prefix=settings.api_v1_prefix)
