from __future__ import annotations

from datetime import datetime, timezone

import yfinance as yf

from app.services.market_trend import MarketTrendAnalyzer


def fetch_live_quotes(tickers: list[str]) -> dict:
    symbols = list(dict.fromkeys(symbol.strip().upper() for symbol in tickers if symbol.strip()))
    if not symbols:
        return {"last_updated": datetime.now(timezone.utc).isoformat(), "quotes": []}

    try:
        data = yf.download(
            tickers=symbols,
            period="5d",
            interval="1d",
            auto_adjust=True,
            progress=False,
            threads=True,
            group_by="ticker",
        )
    except Exception:
        return {"last_updated": datetime.now(timezone.utc).isoformat(), "quotes": []}

    quotes: list[dict] = []
    multi = getattr(data.columns, "nlevels", 1) > 1
    for symbol in symbols:
        try:
            frame = data[symbol] if multi else data
            close_series = frame["Close"].dropna()
            if close_series.empty:
                continue
            close = float(close_series.iloc[-1])
            prev_close = float(close_series.iloc[-2]) if len(close_series) > 1 else close
            day_change_pct = ((close - prev_close) / prev_close) * 100 if prev_close else 0.0
            quotes.append(
                {
                    "ticker": symbol,
                    "current_price": round(close, 4),
                    "previous_close": round(prev_close, 4),
                    "day_change_pct": round(day_change_pct, 3),
                }
            )
        except Exception:
            continue
    return {"last_updated": datetime.now(timezone.utc).isoformat(), "quotes": quotes}


def fetch_market_overview() -> dict:
    symbols = ["SPY", "QQQ", "IWM", "^FTSE"]
    snapshots: list[dict] = []
    for symbol in symbols:
        try:
            history = yf.Ticker(symbol).history(period="1y", auto_adjust=True)
            if history is None or history.empty:
                continue
            closes = history["Close"].dropna().tolist()
            volumes = history["Volume"].fillna(0).tolist()
            if not closes:
                continue
            close = float(closes[-1])
            previous_close = float(closes[-2]) if len(closes) > 1 else close
            day_change_pct = ((close - previous_close) / previous_close) * 100 if previous_close else 0.0
            ma_50 = sum(closes[-50:]) / min(50, len(closes))
            ma_200 = sum(closes[-200:]) / min(200, len(closes))
            distribution_days = 0
            for idx in range(1, min(len(closes), 20)):
                if closes[-idx] < closes[-idx - 1] * 0.998 and volumes[-idx] > volumes[-idx - 1]:
                    distribution_days += 1
            snapshots.append(
                {
                    "symbol": symbol,
                    "close": round(close, 3),
                    "previous_close": round(previous_close, 3),
                    "day_change_pct": round(day_change_pct, 3),
                    "ma_50": round(ma_50, 3),
                    "ma_200": round(ma_200, 3),
                    "distribution_days": distribution_days,
                    "follow_through_day": close > ma_50 and closes[-1] > closes[-5] if len(closes) >= 5 else False,
                    "sparkline": [round(float(value), 3) for value in closes[-64:]],
                }
            )
        except Exception:
            continue

    market = MarketTrendAnalyzer().evaluate(snapshots) if snapshots else {
        "trend": "market_in_correction",
        "follow_through_day": False,
        "indices_above_50dma_ratio": 0.0,
        "indices_above_200dma_ratio": 0.0,
        "distribution_day_pressure": 0.0,
        "health_score": 0.0,
        "warning_banner": "Market data unavailable",
        "indices": [],
    }
    return {
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "market": market,
    }
