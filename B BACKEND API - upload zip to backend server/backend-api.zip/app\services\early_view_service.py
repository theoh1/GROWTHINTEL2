from __future__ import annotations

import asyncio
import math
from collections import defaultdict
from datetime import datetime, time, timezone
from typing import Any
from zoneinfo import ZoneInfo

import yfinance as yf

from app.repositories.screening_repository import ScreeningRepository


ET = ZoneInfo("America/New_York")
MARKET_OPEN = time(9, 30)
OPEN_SCAN_END = time(9, 33)


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        numeric = float(value)
        return numeric if math.isfinite(numeric) else default
    except (TypeError, ValueError):
        return default


def _pct(current: float, base: float) -> float:
    return ((current - base) / base) * 100 if base else 0.0


def _market_status(now: datetime) -> tuple[str, str, int | None]:
    local = now.astimezone(ET)
    open_dt = local.replace(hour=9, minute=30, second=0, microsecond=0)
    scan_end = local.replace(hour=9, minute=33, second=0, microsecond=0)
    close_dt = local.replace(hour=16, minute=0, second=0, microsecond=0)
    if local.weekday() >= 5:
        return "closed", "Early View activates at market open.", None
    if local < open_dt:
        return "pre_open", "Early View activates at market open.", int((open_dt - local).total_seconds())
    if open_dt <= local <= scan_end:
        return "scanning", "Scanning first 3 minutes of market open...", int((scan_end - local).total_seconds())
    if local < close_dt:
        return "scan_complete", "First 3-minute scan complete. Monitoring opening range breaks.", None
    return "closed", "Early View activates at market open.", None


def _status_from_score(score: float, above_vwap: bool, rel_volume: float, gap_pct: float, spread_quality: float) -> str:
    if score >= 70 and above_vwap and rel_volume >= 1.5 and spread_quality >= 55:
        return "Watch"
    if score >= 50 or abs(gap_pct) >= 2:
        return "Wait"
    return "Avoid"


def _risk_level(rel_volume: float, spread_proxy: float, above_vwap: bool) -> str:
    if spread_proxy < 45 or not above_vwap:
        return "High"
    if rel_volume < 1.4:
        return "Medium"
    return "Low"


def _score_label(score: float) -> str:
    if score >= 85:
        return "Strong Early Leader"
    if score >= 70:
        return "Watch Closely"
    if score >= 50:
        return "Wait for Confirmation"
    return "Avoid / Weak Signal"


def _vwap(rows) -> float:
    total_volume = _safe_float(rows["Volume"].sum())
    if total_volume <= 0:
        return _safe_float(rows["Close"].iloc[-1])
    typical = (rows["High"] + rows["Low"] + rows["Close"]) / 3
    return _safe_float((typical * rows["Volume"]).sum() / total_volume)


def _download_intraday(symbols: list[str]):
    return yf.download(
        tickers=symbols,
        period="1d",
        interval="1m",
        auto_adjust=True,
        progress=False,
        threads=True,
        group_by="ticker",
        prepost=True,
    )


def _frame_for_symbol(data, symbol: str, multi: bool):
    if multi:
        return data[symbol].dropna(how="all") if symbol in data.columns.get_level_values(0) else None
    return data.dropna(how="all")


def _build_early_view(repository: ScreeningRepository, window_minutes: int) -> dict[str, Any]:
    now = datetime.now(timezone.utc)
    status, status_text, countdown = _market_status(now)
    rows = repository.latest_scan_rows(threshold=0, limit=80)
    if not rows:
        return {
            "last_updated": now.isoformat(),
            "market_status": status,
            "status_text": "Early View requires live intraday data.",
            "countdown_seconds": countdown,
            "scan_window_minutes": window_minutes,
            "stocks_scanned": 0,
            "leaders": [],
            "gap_leaders": [],
            "volume_surge": [],
            "opening_range_breakouts": [],
            "watch_wait_avoid": {"watch": 0, "wait": 0, "avoid": 0},
            "market_direction": "Unavailable",
            "avg_volume_surge": 0,
            "brief": "Early View requires live intraday data.",
            "data_available": False,
        }

    row_by_ticker = {row.ticker: row for row in rows}
    symbols = list(row_by_ticker)
    try:
        data = _download_intraday(symbols)
    except Exception:
        data = None
    if data is None or getattr(data, "empty", True):
        return {
            "last_updated": now.isoformat(),
            "market_status": status,
            "status_text": "Early View requires live intraday data.",
            "countdown_seconds": countdown,
            "scan_window_minutes": window_minutes,
            "stocks_scanned": 0,
            "leaders": [],
            "gap_leaders": [],
            "volume_surge": [],
            "opening_range_breakouts": [],
            "watch_wait_avoid": {"watch": 0, "wait": 0, "avoid": 0},
            "market_direction": "Unavailable",
            "avg_volume_surge": 0,
            "brief": "Early View requires live intraday data.",
            "data_available": False,
        }

    local_now = now.astimezone(ET)
    open_dt = local_now.replace(hour=9, minute=30, second=0, microsecond=0)
    scan_end = open_dt.replace(minute=30 + window_minutes)
    multi = getattr(data.columns, "nlevels", 1) > 1
    leaders: list[dict[str, Any]] = []
    sector_scores: dict[str, list[float]] = defaultdict(list)

    for symbol, stock in row_by_ticker.items():
        frame = _frame_for_symbol(data, symbol, multi)
        if frame is None or frame.empty or "Close" not in frame:
            continue
        try:
            index = frame.index
            if getattr(index, "tz", None) is None:
                frame = frame.tz_localize("UTC")
            frame = frame.tz_convert(ET)
        except Exception:
            pass
        day_rows = frame[frame.index.date == local_now.date()]
        if day_rows.empty:
            continue
        opening_rows = day_rows[(day_rows.index >= open_dt) & (day_rows.index < scan_end)]
        live_rows = day_rows[day_rows.index >= open_dt]
        if opening_rows.empty or live_rows.empty:
            continue

        open_price = _safe_float(opening_rows["Open"].iloc[0])
        current_price = _safe_float(live_rows["Close"].iloc[-1])
        opening_high = _safe_float(opening_rows["High"].max())
        opening_low = _safe_float(opening_rows["Low"].min())
        current_volume = _safe_float(live_rows["Volume"].sum())
        opening_volume = _safe_float(opening_rows["Volume"].sum())
        avg_volume = _safe_float(stock.average_volume_50d or 0)
        expected_open_volume = max(avg_volume * (window_minutes / 390), 1)
        rel_volume = current_volume / expected_open_volume if expected_open_volume else 0
        prev_close = _safe_float(stock.current_price or open_price)
        move_from_open = _pct(current_price, open_price)
        gap_pct = _pct(open_price, prev_close)
        vwap = _vwap(live_rows)
        above_vwap = current_price >= vwap
        range_size = opening_high - opening_low
        opening_strength = 100 if range_size <= 0 else max(0, min(100, ((current_price - opening_low) / range_size) * 100))
        opening_range_break = current_price > opening_high and current_volume > opening_volume
        spread_proxy = max(0, min(100, 100 - (abs(_pct(opening_high, opening_low)) * 14)))
        sector_confirmation = 60
        growth_confirmation = max(0, min(100, _safe_float(stock.score)))
        price_score = max(0, min(100, move_from_open * 16 + 50))
        volume_score = max(0, min(100, rel_volume * 25))
        vwap_score = 100 if above_vwap else 25
        score = (
            price_score * 0.25
            + volume_score * 0.25
            + opening_strength * 0.15
            + vwap_score * 0.10
            + sector_confirmation * 0.10
            + spread_proxy * 0.10
            + growth_confirmation * 0.05
        )
        status_label = _status_from_score(score, above_vwap, rel_volume, gap_pct, spread_proxy)
        risk = _risk_level(rel_volume, spread_proxy, above_vwap)
        catalyst = "News check needed"
        if stock.recent_headlines:
            catalyst = "News catalyst"
        elif abs(gap_pct) >= 3:
            catalyst = "Gap move"

        spark = [_safe_float(value) for value in live_rows["Close"].tail(12).tolist()]
        item = {
            "ticker": symbol,
            "company": stock.company_name,
            "sector": stock.sector or "Unknown",
            "current_price": round(current_price, 2),
            "move_from_open_pct": round(move_from_open, 2),
            "gap_pct": round(gap_pct, 2),
            "volume": round(current_volume),
            "volume_vs_average": round((current_volume / avg_volume) * 100, 2) if avg_volume else None,
            "relative_volume": round(rel_volume, 2),
            "opening_range_high": round(opening_high, 2),
            "opening_range_low": round(opening_low, 2),
            "vwap": round(vwap, 2),
            "vwap_status": "Above VWAP" if above_vwap else "Below VWAP",
            "opening_range_break": opening_range_break,
            "momentum_score": round(score),
            "score_label": _score_label(score),
            "risk_level": risk,
            "status": status_label,
            "catalyst_tag": catalyst,
            "liquidity_quality": round(spread_proxy),
            "sector_confirmation": "Confirmed" if sector_confirmation >= 70 else "Mixed",
            "growthintel_confirmation": round(growth_confirmation),
            "mini_chart": [round(value, 2) for value in spark],
        }
        leaders.append(item)
        sector_scores[item["sector"]].append(score)

    leaders.sort(key=lambda item: item["momentum_score"], reverse=True)
    leaders = leaders[:24]
    if not leaders:
        status_text = "No strong early momentum detected yet." if status in {"scanning", "scan_complete"} else status_text
    sector_strength = sorted(
        ((sector, sum(scores) / len(scores)) for sector, scores in sector_scores.items() if scores),
        key=lambda item: item[1],
        reverse=True,
    )
    watch_wait_avoid = {
        "watch": sum(1 for item in leaders if item["status"] == "Watch"),
        "wait": sum(1 for item in leaders if item["status"] == "Wait"),
        "avoid": sum(1 for item in leaders if item["status"] == "Avoid"),
    }
    avg_volume_surge = sum(item["relative_volume"] for item in leaders) / len(leaders) if leaders else 0
    top_sectors = ", ".join(sector for sector, _score in sector_strength[:2]) or "no clear sector"
    top_names = ", ".join(item["ticker"] for item in leaders[:3]) or "no confirmed leaders"
    brief = (
        f"Early strength is led by {top_names}. Sector strength is concentrated in {top_sectors}. "
        f"Momentum is {'broad' if watch_wait_avoid['watch'] >= 5 else 'narrow'}, so focus on clean opening-range breaks with volume confirmation."
        if leaders
        else status_text
    )

    return {
        "last_updated": now.isoformat(),
        "market_status": status,
        "status_text": status_text,
        "countdown_seconds": countdown,
        "scan_window_minutes": window_minutes,
        "stocks_scanned": len(symbols),
        "strong_momentum_detected": watch_wait_avoid["watch"],
        "avg_volume_surge": round(avg_volume_surge, 2),
        "market_direction": "Constructive" if watch_wait_avoid["watch"] >= 4 else "Mixed" if leaders else "Unavailable",
        "leaders": leaders,
        "gap_leaders": sorted(leaders, key=lambda item: item["gap_pct"], reverse=True)[:8],
        "volume_surge": sorted(leaders, key=lambda item: item["relative_volume"], reverse=True)[:8],
        "opening_range_breakouts": [item for item in leaders if item["opening_range_break"]][:8],
        "watch_wait_avoid": watch_wait_avoid,
        "brief": brief,
        "data_available": bool(leaders),
    }


async def build_early_view_payload(repository: ScreeningRepository, window_minutes: int = 3) -> dict[str, Any]:
    safe_window = window_minutes if window_minutes in {3, 5, 15} else 3
    return await asyncio.to_thread(_build_early_view, repository, safe_window)
