from __future__ import annotations


def analyze_volume(closes: list[float], volumes: list[float], volume_spike_threshold: float = 1.5) -> list[dict]:
    alerts: list[dict] = []
    if len(closes) < 22 or len(volumes) < 22:
        return alerts

    current_close = closes[-1]
    previous_close = closes[-2]
    current_volume = volumes[-1]
    avg_volume_20 = sum(volumes[-21:-1]) / 20
    distribution_day = current_close < previous_close and current_volume > volumes[-2] and current_volume > avg_volume_20 * volume_spike_threshold

    if distribution_day:
        alerts.append(
            {
                "alert_type": "Distribution Detected",
                "message": "High-volume sell-off detected (distribution day).",
                "severity": "red",
                "code": "distribution_day",
            }
        )
    elif current_close < previous_close and current_volume > avg_volume_20 * volume_spike_threshold:
        alerts.append(
            {
                "alert_type": "Distribution Detected",
                "message": "Volume spike on a down day signals selling pressure.",
                "severity": "yellow",
                "code": "volume_spike_down",
            }
        )

    return alerts
