from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import yfinance as yf

from app.services.ai_news_analysis import ai_summary, canslim_tags, classify_impact, time_ago_iso


def _parse_published(item: dict) -> datetime | None:
    content = item.get("content", {}) if isinstance(item, dict) else {}
    stamp = content.get("pubDate")
    if stamp is None:
        return None
    try:
        if isinstance(stamp, (int, float)):
            return datetime.fromtimestamp(float(stamp), tz=timezone.utc)
        if isinstance(stamp, str):
            normalized = stamp.replace("Z", "+00:00")
            parsed = datetime.fromisoformat(normalized)
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except Exception:
        return None
    return None


def _extract_item(item: dict, fallback_symbol: str, category: str, sector: str | None = None) -> dict | None:
    content = item.get("content", {}) if isinstance(item, dict) else {}
    headline = (content.get("title") or "").strip()
    if not headline:
        return None
    source = content.get("provider", {}).get("displayName") or content.get("publisher") or "Yahoo Finance"
    summary = (content.get("summary") or "").strip()
    published = _parse_published(item)
    related = content.get("relatedTickers") or [fallback_symbol]
    related_ticker = next((ticker for ticker in related if isinstance(ticker, str) and ticker), fallback_symbol)
    impact = classify_impact(headline, summary)
    tags = canslim_tags(headline, summary)
    return {
        "id": f"{fallback_symbol}:{abs(hash(headline))}",
        "headline": headline,
        "source": source,
        "published_at": published.isoformat() if published else None,
        "time_ago": time_ago_iso(published),
        "summary": summary,
        "ai_summary": ai_summary(headline, summary, impact),
        "impact": impact,
        "tags": tags,
        "related_ticker": related_ticker,
        "category": category,
        "sector": sector,
    }


def _score_item(item: dict) -> float:
    score = 0.0
    if item["impact"] != "neutral":
        score += 3.0
    score += len(item.get("tags", []))
    if item.get("category") == "earnings":
        score += 2.5
    if item.get("related_ticker"):
        score += 1.0
    return score


def _fetch_symbol_news(symbol: str, category: str, limit: int = 6, sector: str | None = None) -> list[dict]:
    try:
        items = yf.Ticker(symbol).news or []
    except Exception:
        return []

    extracted: list[dict] = []
    for raw in items:
        parsed = _extract_item(raw, fallback_symbol=symbol, category=category, sector=sector)
        if parsed:
            extracted.append(parsed)
        if len(extracted) >= limit:
            break
    return extracted


def _market_sentiment(headlines: list[dict]) -> dict:
    if not headlines:
        return {"label": "Neutral", "score": 50}
    bullish = sum(1 for item in headlines if item.get("impact") == "bullish")
    bearish = sum(1 for item in headlines if item.get("impact") == "bearish")
    score = max(0, min(100, 50 + ((bullish - bearish) * 8)))
    if score >= 60:
        label = "Bullish"
    elif score <= 40:
        label = "Bearish"
    else:
        label = "Neutral"
    return {"label": label, "score": score}


async def build_news_payload(top_stocks: list[dict], watchlist_symbols: list[str]) -> dict:
    market_symbols = ["SPY", "QQQ", "IWM"]
    sector_symbols = ["XLK", "XLF", "XLE", "XLV", "XLI", "XLY"]
    stock_symbols = [stock["ticker"] for stock in top_stocks[:10]]

    market_tasks = [asyncio.to_thread(_fetch_symbol_news, symbol, "market", 4) for symbol in market_symbols]
    sector_tasks = [asyncio.to_thread(_fetch_symbol_news, symbol, "sector", 3) for symbol in sector_symbols]
    stock_tasks = [
        asyncio.to_thread(_fetch_symbol_news, symbol, "stock", 3, top_stocks[index].get("sector"))
        for index, symbol in enumerate(stock_symbols)
    ]
    watch_tasks = [asyncio.to_thread(_fetch_symbol_news, symbol, "watchlist", 2) for symbol in watchlist_symbols[:8]]

    market_raw, sector_raw, stock_raw, watch_raw = await asyncio.gather(
        asyncio.gather(*market_tasks, return_exceptions=True),
        asyncio.gather(*sector_tasks, return_exceptions=True),
        asyncio.gather(*stock_tasks, return_exceptions=True),
        asyncio.gather(*watch_tasks, return_exceptions=True),
    )

    def flatten(results):
        rows: list[dict] = []
        for item in results:
            if isinstance(item, list):
                rows.extend(item)
        return rows

    market_headlines = sorted(flatten(market_raw), key=_score_item, reverse=True)[:14]
    sector_headlines = sorted(flatten(sector_raw), key=_score_item, reverse=True)[:20]
    stock_headlines = sorted(flatten(stock_raw), key=_score_item, reverse=True)[:26]
    watchlist_headlines = sorted(flatten(watch_raw), key=_score_item, reverse=True)[:14]

    high_impact = [
        *[item for item in market_headlines if _score_item(item) >= 4.0],
        *[item for item in sector_headlines if _score_item(item) >= 4.0],
        *[item for item in stock_headlines if _score_item(item) >= 4.0],
    ]

    return {
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "sentiment": _market_sentiment(market_headlines + sector_headlines),
        "market_headlines": market_headlines,
        "sector_headlines": sector_headlines,
        "stock_headlines": stock_headlines,
        "watchlist_headlines": watchlist_headlines,
        "high_impact": sorted(high_impact, key=_score_item, reverse=True)[:25],
        "top_canslim_tickers": stock_symbols,
    }


async def build_stock_news_payload(ticker: str) -> dict:
    symbol = ticker.strip().upper()
    stock_news = await asyncio.to_thread(_fetch_symbol_news, symbol, "stock", 16)
    return {
        "ticker": symbol,
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "items": sorted(stock_news, key=_score_item, reverse=True),
    }


SECTOR_ETF_MAP = {
    "technology": "XLK",
    "tech": "XLK",
    "financials": "XLF",
    "finance": "XLF",
    "energy": "XLE",
    "healthcare": "XLV",
    "industrials": "XLI",
    "consumer": "XLY",
    "consumer discretionary": "XLY",
    "materials": "XLB",
    "utilities": "XLU",
    "real estate": "XLRE",
    "communication": "XLC",
    "communications": "XLC",
}


async def build_sector_news_payload(sector: str) -> dict:
    query = sector.strip().lower()
    symbol = SECTOR_ETF_MAP.get(query)
    if symbol is None:
        for key, mapped in SECTOR_ETF_MAP.items():
            if query in key or key in query:
                symbol = mapped
                break
    if symbol is None:
        symbol = "SPY"
    sector_news = await asyncio.to_thread(_fetch_symbol_news, symbol, "sector", 16, sector=sector.strip().title())
    return {
        "sector": sector.strip().title() or "Market",
        "symbol": symbol,
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "items": sorted(sector_news, key=_score_item, reverse=True),
    }
