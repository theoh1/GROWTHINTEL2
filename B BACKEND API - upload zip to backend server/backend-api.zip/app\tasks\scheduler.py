from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from app.core.config import get_settings


def build_scheduler(refresh_callable):
    settings = get_settings()
    scheduler = AsyncIOScheduler(timezone=settings.scheduler_timezone)
    scheduler.add_job(
        refresh_callable,
        CronTrigger(hour=settings.daily_refresh_hour, minute=settings.daily_refresh_minute, timezone=settings.scheduler_timezone),
        id="daily_refresh",
        coalesce=True,
        max_instances=1,
        misfire_grace_time=60 * 30,
        replace_existing=True,
    )
    return scheduler
