from pathlib import Path

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from app.core.config import get_settings


settings = get_settings()


def _normalize_database_url(url: str) -> str:
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+psycopg://", 1)
    return url


def _sqlite_fallback_url() -> str:
    project_db = Path(__file__).resolve().parents[3] / "canslim.db"
    if project_db.exists():
        return f"sqlite:///{project_db.as_posix()}"
    return "sqlite:///./canslim.db"


def _engine_kwargs(url: str) -> dict:
    kwargs = {"future": True, "pool_pre_ping": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
    return kwargs


def _create_resilient_engine():
    primary_url = _normalize_database_url(settings.database_url)
    primary_engine = create_engine(primary_url, **_engine_kwargs(primary_url))
    try:
        with primary_engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return primary_engine, primary_url, False
    except Exception:
        primary_engine.dispose()
        fallback_url = _sqlite_fallback_url()
        return create_engine(fallback_url, **_engine_kwargs(fallback_url)), fallback_url, True


engine, active_database_url, using_database_fallback = _create_resilient_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
