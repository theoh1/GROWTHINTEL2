from __future__ import annotations

from datetime import datetime, timedelta

from app.core.config import get_settings
from app.repositories.screening_repository import ScreeningRepository
from app.services.providers import MarketDataProvider


class DataService:
    def __init__(self, repository: ScreeningRepository, provider: MarketDataProvider):
        self.repository = repository
        self.provider = provider
        self.settings = get_settings()

    async def get_market_overview(self, force_refresh: bool = False) -> list[dict]:
        cache_key = "market_overview"
        cached = self.repository.get_cache(cache_key)
        if not force_refresh and cached:
            return cached["indices"]

        try:
            indices = await self.provider.fetch_market_overview()
        except Exception:
            if cached:
                return cached["indices"]
            raise
        self.repository.set_cache(
            cache_key,
            {"indices": indices},
            datetime.utcnow() + timedelta(hours=self.settings.price_cache_hours),
        )
        return indices

    async def get_stock_data(self, tickers: list[str], force_refresh: bool = False) -> list[dict]:
        stocks: list[dict] = []
        uncached: list[str] = []
        cached_by_ticker: dict[str, dict] = {}

        for ticker in tickers:
            cache_key = f"stock:{ticker}"
            cached = self.repository.get_cache(cache_key)
            if cached:
                cached_by_ticker[ticker] = cached
            if not force_refresh and cached:
                    stocks.append(self._deserialize_stock(cached))
                    continue
            uncached.append(ticker)

        if uncached:
            fresh = await self.provider.fetch_stock_universe(uncached)
            fresh_tickers = {stock["ticker"] for stock in fresh}
            for stock in fresh:
                self.repository.set_cache(
                    f"stock:{stock['ticker']}",
                    self._serialize_stock(stock),
                    datetime.utcnow() + timedelta(hours=self.settings.price_cache_hours),
                )
            stocks.extend(fresh)
            for ticker in uncached:
                if not force_refresh and ticker not in fresh_tickers and ticker in cached_by_ticker:
                    stocks.append(self._deserialize_stock(cached_by_ticker[ticker]))

        return sorted(stocks, key=lambda item: item["ticker"])

    def _serialize_stock(self, stock: dict) -> dict:
        payload = dict(stock)
        payload["as_of_date"] = stock["as_of_date"].isoformat() if hasattr(stock["as_of_date"], "isoformat") else stock["as_of_date"]
        payload["price_history"] = [
            {**point, "date": point["date"].isoformat() if hasattr(point["date"], "isoformat") else point["date"]}
            for point in stock.get("price_history", [])
        ]
        return payload

    def _deserialize_stock(self, payload: dict) -> dict:
        stock = dict(payload)
        if isinstance(stock.get("as_of_date"), str):
            stock["as_of_date"] = datetime.fromisoformat(stock["as_of_date"])
        stock["price_history"] = [
            {**point, "date": datetime.fromisoformat(point["date"]) if isinstance(point.get("date"), str) else point.get("date")}
            for point in stock.get("price_history", [])
        ]
        return stock
