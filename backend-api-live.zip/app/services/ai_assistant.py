from __future__ import annotations

import json
import re
import threading
from urllib.parse import quote
from pathlib import Path
from typing import Any

import httpx
from fastapi import HTTPException

from app.core.config import get_settings


SYSTEM_PROMPT = """
You are GrowthIntel's ChatGPT-powered investing assistant. Give direct, plain-English answers for growth investors.
Think like a real investing coach: explain, compare, answer follow-ups, ask for missing details when needed,
and admit uncertainty. Do not rely on local website scores unless they are explicitly provided in the user message.
Do not give personalized financial advice or guaranteed predictions.

Return only valid JSON with this shape:
{
  "title": "short title",
  "summary": "direct answer in 1-3 sentences",
  "keyPoints": ["3 concise evidence-backed points"],
  "action": "Buy|Wait|Avoid|Reduce",
  "risks": ["1-3 concrete risks"],
  "confidence": 0-100,
  "evidence": [{"label":"string","value":"string","context":"string"}]
}
""".strip()

LOCAL_MODEL: Any | None = None
LOCAL_MODEL_LOCK = threading.Lock()
LOCAL_MODEL_NAME: str | None = None


def _compact_context(payload: dict[str, Any]) -> dict[str, Any]:
    stock = payload.get("stock")
    market = payload.get("market")
    top_stocks = payload.get("top_stocks")
    portfolio = payload.get("portfolio")

    if isinstance(stock, dict):
        stock = {
            "ticker": stock.get("ticker"),
            "company_name": stock.get("company_name"),
            "score": stock.get("score"),
            "grade": stock.get("grade"),
            "risk_level": stock.get("risk_level"),
            "current_price": stock.get("current_price"),
            "fundamentals": stock.get("fundamentals"),
            "institutional": stock.get("institutional"),
            "strengths": stock.get("strengths"),
            "weaknesses": stock.get("weaknesses"),
            "flags": stock.get("flags"),
            "reason_summary": stock.get("reason_summary"),
            "recent_headlines": stock.get("recent_headlines"),
        }

    if isinstance(market, dict):
        market = {
            "trend": market.get("trend"),
            "health_score": market.get("health_score"),
            "follow_through_day": market.get("follow_through_day"),
            "indices_above_50dma_ratio": market.get("indices_above_50dma_ratio"),
            "indices_above_200dma_ratio": market.get("indices_above_200dma_ratio"),
            "distribution_day_pressure": market.get("distribution_day_pressure"),
            "warning_banner": market.get("warning_banner"),
        }

    if isinstance(top_stocks, list):
        top_stocks = [
            {
                "ticker": item.get("ticker"),
                "company_name": item.get("company_name"),
                "score": item.get("score"),
                "risk_level": item.get("risk_level"),
                "reason_summary": item.get("reason_summary"),
            }
            for item in top_stocks[:8]
            if isinstance(item, dict)
        ]

    return {
        "question": payload.get("question"),
        "intent": payload.get("intent"),
        "memory": payload.get("memory"),
        "market": market,
        "stock": stock,
        "top_stocks": top_stocks,
        "portfolio": portfolio,
    }


def _extract_text(response_payload: dict[str, Any]) -> str:
    output_text = response_payload.get("output_text")
    if isinstance(output_text, str) and output_text.strip():
        return output_text

    chunks: list[str] = []
    for item in response_payload.get("output", []):
        if not isinstance(item, dict):
            continue
        for content in item.get("content", []):
            if not isinstance(content, dict):
                continue
            text = content.get("text")
            if isinstance(text, str):
                chunks.append(text)
    return "\n".join(chunks).strip()


def _clean_json_text(text: str) -> str:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = stripped.strip("`")
        if stripped.lower().startswith("json"):
            stripped = stripped[4:]
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start >= 0 and end > start:
        return stripped[start : end + 1]
    return stripped


def _coerce_response(raw: dict[str, Any]) -> dict[str, Any]:
    action = raw.get("action") if raw.get("action") in {"Buy", "Wait", "Avoid", "Reduce"} else "Wait"
    confidence = raw.get("confidence")
    try:
        confidence_value = int(max(0, min(100, float(confidence))))
    except (TypeError, ValueError):
        confidence_value = 50

    def string_list(value: Any, fallback: list[str]) -> list[str]:
        if not isinstance(value, list):
            return fallback
        cleaned = [str(item).strip() for item in value if str(item).strip()]
        return cleaned[:5] or fallback

    evidence = raw.get("evidence")
    if not isinstance(evidence, list):
        evidence = []
    evidence_items = []
    for item in evidence[:6]:
        if not isinstance(item, dict):
            continue
        evidence_items.append(
            {
                "label": str(item.get("label") or "Evidence"),
                "value": str(item.get("value") or "-"),
                "context": str(item.get("context") or "Model-selected evidence"),
            }
        )

    return {
        "title": str(raw.get("title") or "AI Assistant"),
        "summary": str(raw.get("summary") or "I need more context before making a call."),
        "keyPoints": string_list(raw.get("keyPoints"), ["Review the current setup, market trend, and risk before acting."]),
        "action": action,
        "risks": string_list(raw.get("risks"), ["Market conditions can change quickly."]),
        "confidence": confidence_value,
        "followUps": ["Explain that more", "Compare alternatives", "Show entry levels", "What would change your mind?"],
        "evidence": evidence_items,
        "source": "openai",
    }


def _plain_text_response(text: str, model: str) -> dict[str, Any]:
    text = re.sub(r"<\|/?(?:assistant|user|system)\|>", " ", text)
    text = text.replace("\u2011", "-").replace("\u2013", "-").replace("\u2014", "-")
    cleaned = re.sub(r"\s+", " ", text).strip()
    if not cleaned:
        cleaned = "I need a little more detail to answer that well."
    sentences = re.split(r"(?<=[.!?])\s+", cleaned)
    summary = " ".join(sentences[:2]).strip() or cleaned
    points = [re.sub(r"^(?:support|solution|answer)\s*=\s*", "", item.strip(" -"), flags=re.IGNORECASE) for item in re.split(r"(?:\n|;)", text) if item.strip(" -")]
    if len(points) < 3:
        points = sentences[:3]
    return {
        "title": "AI Assistant",
        "summary": summary[:900],
        "keyPoints": [point[:260] for point in points[:3] if point],
        "action": "Wait",
        "risks": ["This is AI guidance for research, not personalized financial advice."],
        "confidence": 72,
        "followUps": ["Explain that more", "Give an example", "What are the risks?"],
        "evidence": [
            {"label": "AI Provider", "value": "Local model", "context": "No API key required"},
            {"label": "Model", "value": model, "context": "GPT4All local inference"},
        ],
        "source": "local-gpt4all",
        "model": model,
    }


def _free_ai_prompt(payload: dict[str, Any]) -> str:
    context = _compact_context(payload)
    return (
        "You are GrowthIntel's investing assistant. Answer directly in plain English. "
        "Be useful for growth investors, avoid hype, and do not give guaranteed financial advice. "
        "Use the website context only as supporting evidence, not as your whole answer.\n\n"
        f"Question and context JSON:\n{json.dumps(context, default=str)}\n\n"
        "Return a concise answer with: short answer, key reasons, risks, and what to watch next."
    )


async def _ask_free_ai_assistant(payload: dict[str, Any]) -> dict[str, Any]:
    settings = get_settings()
    prompt = _free_ai_prompt(payload)
    encoded = quote(prompt[:3500], safe="")
    url = f"https://text.pollinations.ai/{encoded}?model={quote(settings.free_ai_model)}"
    async with httpx.AsyncClient(timeout=45.0, follow_redirects=True) as client:
        response = await client.get(url)
    response.raise_for_status()
    text = response.text.strip()
    result = _plain_text_response(text, f"pollinations:{settings.free_ai_model}")
    result["source"] = "pollinations-free-ai"
    result["evidence"] = [
        {"label": "AI Provider", "value": "Pollinations free text AI", "context": "No API key required"},
        {"label": "Model", "value": settings.free_ai_model, "context": "Free hosted text model route"},
    ]
    return result


def _fallback_assistant_response(payload: dict[str, Any]) -> dict[str, Any]:
    question = str(payload.get("question") or "").strip()
    context = _compact_context(payload)
    top_stocks = context.get("top_stocks") if isinstance(context.get("top_stocks"), list) else []
    market = context.get("market") if isinstance(context.get("market"), dict) else {}
    stock = context.get("stock") if isinstance(context.get("stock"), dict) else {}
    q = question.lower()

    if stock and stock.get("ticker"):
        ticker = stock.get("ticker")
        score = stock.get("score")
        risk = stock.get("risk_level") or "unknown"
        summary = f"Short answer: {ticker} is worth researching, but I would not treat it as an automatic buy. Its GrowthIntel score is {score}, with {risk} risk, so the next decision should depend on entry quality, volume, and market direction."
        points = [
            f"{ticker} needs a clean setup and risk-controlled entry before it deserves action.",
            "Use CANSLIM quality, Engine view, recent news, and relative strength together instead of one score.",
            "If the stock is extended or below key moving averages, waiting is usually better than chasing.",
        ]
    elif top_stocks and any(term in q for term in ["best", "top", "strongest", "buy", "stock", "watch"]):
        leaders = [f"{item.get('ticker')} ({round(float(item.get('score') or 0))})" for item in top_stocks[:5] if item.get("ticker")]
        summary = f"Short answer: the strongest current GrowthIntel names are {', '.join(leaders) or 'not available yet'}. I would use them as a watchlist, not buy signals."
        points = [
            "Prioritize names with strong scores, clear catalysts, and volume-backed price action.",
            "Avoid buying just because a name appears high on the list; wait for a valid entry.",
            "If market health weakens, reduce position size or wait for confirmation.",
        ]
    else:
        trend = str(market.get("trend") or "unknown").replace("_", " ")
        summary = "Short answer: I would be selective and data-led here. Use GrowthIntel as confirmation, then check the chart, volume, catalyst, and risk before taking any action."
        points = [
            f"Current market regime: {trend}. That changes how aggressive you should be.",
            "A good setup needs both a strong business/score and a clean technical entry.",
            "The biggest mistake is chasing a move without knowing the stop, risk, and invalidation level.",
        ]

    return {
        "title": "AI Assistant",
        "summary": summary,
        "keyPoints": points,
        "action": "Wait",
        "risks": [
            "This is research support, not personalized financial advice.",
            "Live market data can change quickly.",
        ],
        "confidence": 68,
        "followUps": ["Explain that more", "Compare alternatives", "What are the risks?"],
        "evidence": [
            {"label": "AI Provider", "value": "GrowthIntel fallback", "context": "Used because no external AI key is configured on the server."},
            {"label": "Market", "value": str(market.get("trend") or "Unknown"), "context": "Latest available GrowthIntel context."},
        ],
        "source": "growthintel-fallback",
        "model": "GrowthIntel fallback assistant",
    }


def _load_local_model(model_name: str) -> Any:
    global LOCAL_MODEL, LOCAL_MODEL_NAME
    with LOCAL_MODEL_LOCK:
        if LOCAL_MODEL is not None and LOCAL_MODEL_NAME == model_name:
            return LOCAL_MODEL
        from gpt4all import GPT4All

        LOCAL_MODEL = GPT4All(model_name, allow_download=False)
        LOCAL_MODEL_NAME = model_name
        return LOCAL_MODEL


def _ask_local_assistant_sync(payload: dict[str, Any]) -> dict[str, Any]:
    settings = get_settings()
    question = str(payload.get("question") or "").strip()
    if not question:
        question = "Help me think through an investing question."
    context = _compact_context(payload)
    top_stocks = context.get("top_stocks") if isinstance(context.get("top_stocks"), list) else []
    market = context.get("market") if isinstance(context.get("market"), dict) else {}
    q = question.lower()

    if top_stocks and any(term in q for term in ["best", "strongest", "top", "right now", "ideas", "opportunities"]):
        leaders = [
            f"{item.get('ticker')} ({round(float(item.get('score') or 0))}, {item.get('risk_level') or 'risk unknown'})"
            for item in top_stocks[:5]
            if item.get("ticker")
        ]
        market_trend = str(market.get("trend") or "unknown").replace("_", " ")
        summary = (
            f"Right now the strongest GrowthIntel candidates are {', '.join(leaders)}. "
            f"The market regime is {market_trend}, so treat these as a watchlist for confirmation, not automatic buys."
        )
        return {
            "title": "Strongest Stocks Right Now",
            "summary": summary,
            "keyPoints": [
                f"{item.get('ticker')} leads with a CANSLIM score near {round(float(item.get('score') or 0))}."
                for item in top_stocks[:3]
                if item.get("ticker")
            ],
            "action": "Wait",
            "risks": [
                "Confirm entries with volume, breakout quality, and market direction before acting.",
                "High scores can still fail if the stock is extended or the market weakens.",
            ],
            "confidence": 82,
            "followUps": ["Compare the top 3", "Which one is safest?", "Show risks", "What would make this a buy?"],
            "evidence": [
                {"label": "Market", "value": market_trend, "context": "Live GrowthIntel market regime"},
                {"label": "Top candidates", "value": ", ".join(leaders), "context": "Latest CANSLIM backend scan"},
            ],
            "source": "growthintel-live-context",
            "model": "GrowthIntel live backend",
        }
    local_model_path = Path.home() / ".cache" / "gpt4all" / settings.local_ai_model
    if not local_model_path.exists():
        return _fallback_assistant_response(payload)
    model = _load_local_model(settings.local_ai_model)
    prompt = (
        "You are an investing-focused AI assistant inside an investing platform. "
        "Answer the user's question directly in plain English. Do not mention website scores unless the user asks. "
        "Be practical, concise, and include risk context. Do not promise returns.\n\n"
        f"User question: {question}\n\nAnswer:"
    )
    with LOCAL_MODEL_LOCK:
        text = model.generate(prompt, max_tokens=120, temp=0.25)
    return _plain_text_response(text, settings.local_ai_model)


async def ask_openai_assistant(payload: dict[str, Any]) -> dict[str, Any]:
    settings = get_settings()
    if not settings.openai_api_key:
        if settings.free_ai_enabled:
            try:
                return await _ask_free_ai_assistant(payload)
            except Exception:
                pass
        import asyncio

        return await asyncio.to_thread(_ask_local_assistant_sync, payload)

    context = _compact_context(payload)
    request_payload = {
        "model": settings.openai_model,
        "instructions": SYSTEM_PROMPT,
        "input": json.dumps(context, default=str),
        "max_output_tokens": 900,
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            "https://api.openai.com/v1/responses",
            headers={
                "Authorization": f"Bearer {settings.openai_api_key}",
                "Content-Type": "application/json",
            },
            json=request_payload,
        )

    if response.status_code >= 400:
        detail = response.text[:800] or "OpenAI request failed."
        raise HTTPException(status_code=502, detail=detail)

    text = _extract_text(response.json())
    try:
        raw = json.loads(_clean_json_text(text))
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=502, detail=f"OpenAI returned an unreadable assistant response: {exc}") from exc

    result = _coerce_response(raw)
    result["model"] = settings.openai_model
    return result
