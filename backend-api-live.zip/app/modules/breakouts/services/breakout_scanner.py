from __future__ import annotations

import asyncio
import re
from datetime import datetime, timedelta, timezone

import pandas as pd
import yfinance as yf

from app.core.config import get_settings
from app.data.universe import LIQUID_US_UNIVERSE
from app.modules.breakouts.services.buy_point_calculator import breakout_status
from app.modules.breakouts.services.pattern_detection import detect_best_pattern
from app.repositories.screening_repository import ScreeningRepository


class BreakoutScanner:
    def __init__(self, repository: ScreeningRepository):
        self.repository = repository
        self.settings = get_settings()

    def _select_universe(self, tickers: list[str] | None) -> list[str]:
        base = tickers or self.settings.default_screen_universe_list
        deduped = list(dict.fromkeys(symbol.strip().upper() for symbol in base if symbol and self._tradable_symbol(symbol.strip().upper())))
        if not deduped:
            deduped = LIQUID_US_UNIVERSE
        # Scan a broad market sample. Downloading is chunked later so the public
        # Breakouts page is not limited to a tiny rotating list of mega caps.
        budget = max(100, min(self.settings.breakout_scan_budget, 2000))
        if len(deduped) <= budget:
            return deduped
        anchors = [ticker for ticker in LIQUID_US_UNIVERSE if ticker in deduped]
        if tickers is None and self.settings.default_screen_universe.strip().upper() == "FULL_US_FREE":
            return list(dict.fromkeys(anchors + deduped))[:budget]
        day_seed = datetime.now(timezone.utc).timetuple().tm_yday
        offset = day_seed % len(deduped)
        rotated = deduped[offset:] + deduped[:offset]
        stride = max(1, len(rotated) // budget)
        sampled = rotated[::stride][:budget]
        merged = list(dict.fromkeys(anchors + sampled))
        return merged[:budget]

    @staticmethod
    def _tradable_symbol(symbol: str) -> bool:
        if not re.fullmatch(r"[A-Z]{1,5}", symbol):
            return False
        if len(symbol) >= 5 and symbol.endswith(("F", "Y")):
            return False
        if symbol.endswith(("W", "U", "R")):
            return False
        return True

    def _download_history(self, universe: list[str]) -> pd.DataFrame:
        frames: list[pd.DataFrame] = []
        chunk_size = 150
        for start in range(0, len(universe), chunk_size):
            chunk = universe[start : start + chunk_size]
            try:
                frame = yf.download(
                    tickers=chunk,
                    period="1y",
                    interval="1d",
                    auto_adjust=True,
                    progress=False,
                    threads=True,
                    group_by="ticker",
                    timeout=18,
                )
            except Exception:
                continue
            if frame is not None and not frame.empty:
                frames.append(frame)
        if not frames:
            return pd.DataFrame()
        if len(frames) == 1:
            return frames[0]
        return pd.concat(frames, axis=1)

    async def scan(self, tickers: list[str] | None = None, force_refresh: bool = False) -> dict:
        cache_key = "breakouts:latest"
        cached = self.repository.get_cache(cache_key)
        if cached and not force_refresh:
            return cached

        universe = self._select_universe(tickers)
        if not force_refresh and tickers is None:
            # Keep first public page loads responsive; the explicit Scan action still runs the broader universe.
            universe = universe[: min(len(universe), 350)]
        payload = await asyncio.to_thread(self._scan_sync, universe)
        self.repository.set_cache(
            cache_key,
            payload,
            datetime.utcnow() + timedelta(minutes=15),
        )
        return payload

    def _scan_sync(self, universe: list[str]) -> dict:
        try:
            data = self._download_history(universe)
            if data.empty:
                raise RuntimeError("No market history returned.")
        except Exception as exc:
            return {
                "last_updated": datetime.now(timezone.utc).isoformat(),
                "scanned_count": len(universe),
                "opportunities": [],
                "warning": f"Breakout scan failed: {exc}",
                "data_source": "LIVE",
            }

        opportunities: list[dict] = []
        multi = getattr(data.columns, "nlevels", 1) > 1

        for symbol in universe:
            try:
                frame = data[symbol] if multi else data
                close_series = frame["Close"].dropna()
                high_series = frame["High"].dropna()
                low_series = frame["Low"].dropna()
                vol_series = frame["Volume"].fillna(0)
                if len(close_series) < 35:
                    continue

                closes = close_series.tolist()
                highs = high_series.reindex(close_series.index).ffill().fillna(0).tolist()
                lows = low_series.reindex(close_series.index).ffill().fillna(0).tolist()
                volumes = vol_series.reindex(close_series.index).fillna(0).tolist()

                pattern = detect_best_pattern(closes, highs, lows, volumes)
                if pattern is None:
                    continue

                current_price = closes[-1]
                previous_close = closes[-2] if len(closes) > 1 else closes[-1]
                current_volume = volumes[-1]
                avg_volume = sum(volumes[-50:]) / min(50, len(volumes))
                if current_price < 10 or avg_volume < 250_000:
                    continue
                status = breakout_status(
                    buy_point=pattern.buy_point,
                    current_price=current_price,
                    previous_close=previous_close,
                    current_volume=current_volume,
                    average_volume=avg_volume,
                    day_high=highs[-1],
                    day_low=lows[-1],
                    pattern_confidence=pattern.confidence,
                )

                moving_21 = sum(closes[-21:]) / min(21, len(closes))
                moving_50 = sum(closes[-50:]) / min(50, len(closes))
                moving_200 = sum(closes[-200:]) / min(200, len(closes))

                confidence = pattern.confidence
                if status["is_valid_breakout"]:
                    confidence += 8
                if status["volume_vs_average_pct"] >= 50:
                    confidence += 4
                if current_price < moving_50:
                    confidence -= 8
                if current_price < moving_200:
                    confidence -= 10
                confidence = max(0.0, min(100.0, confidence))

                row = {
                    "ticker": symbol,
                    "pattern_type": pattern.pattern_type,
                    "setup_quality": "Confirmed O'Neil-style base",
                    "buy_point": round(pattern.buy_point, 2),
                    "current_price": round(current_price, 2),
                    "distance_from_buy_point_pct": status["distance_from_buy_point_pct"],
                    "volume_vs_average_pct": status["volume_vs_average_pct"],
                    "status": status["status"],
                    "confidence_score": round(confidence, 1),
                    "safety_checks": status.get("safety_checks", {}),
                    "moving_averages": {
                        "ma21": round(moving_21, 2),
                        "ma50": round(moving_50, 2),
                        "ma200": round(moving_200, 2),
                    },
                    "notes": pattern.notes,
                    "sparkline": [round(value, 2) for value in closes[-40:]],
                    "chart": {
                        "closes": [round(value, 2) for value in closes[-120:]],
                        "volumes": [int(value) for value in volumes[-120:]],
                        "buy_point": round(pattern.buy_point, 2),
                        "base_start_index": max(0, pattern.base_start_index - (len(closes) - 120)),
                        "base_end_index": max(0, pattern.base_end_index - (len(closes) - 120)),
                    },
                    "as_of": close_series.index[-1].to_pydatetime().replace(tzinfo=timezone.utc).isoformat(),
                }
                opportunities.append(row)
            except Exception:
                continue

        clean = [
            row
            for row in opportunities
            if row["confidence_score"] >= 72
            and row["status"] in {"Breaking Out", "In Buy Zone", "Needs Volume", "Below Buy Point"}
            and row["distance_from_buy_point_pct"] <= 5
        ]
        clean.sort(
            key=lambda row: (
                0 if row["status"] in {"Breaking Out", "In Buy Zone"} else 1,
                -row["confidence_score"],
                abs(row["distance_from_buy_point_pct"]),
            )
        )

        limited = clean[: max(10, min(self.settings.breakout_results_limit, 20))]
        return {
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "scanned_count": len(universe),
            "opportunities": limited,
            "warning": None if limited else "No clean breakout setups found under strict O'Neil rules in this scan.",
            "data_source": "LIVE",
        }
