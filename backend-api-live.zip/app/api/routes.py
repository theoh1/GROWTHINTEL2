from __future__ import annotations

import time
import asyncio
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.session import SessionLocal
from app.core.config import get_settings
from app.models.entities import TesterFeedback
from app.modules.breakouts.services.breakout_scanner import BreakoutScanner
from app.modules.portfolio.services.alert_engine import evaluate_alerts
from app.modules.portfolio.services.portfolio_market_data import fetch_live_quotes, fetch_market_overview
from app.pipeline.run_daily_scan import run_daily_scan
from app.repositories.screening_repository import ScreeningRepository
from app.schemas.canslim import (
    AlertCreate,
    HistoryResponse,
    RefreshResponse,
    ScreeningResponse,
    WatchlistCreate,
)
from app.services.data_service import DataService
from app.services.early_view_service import build_early_view_payload
from app.services.earnings_service import build_earnings_payload
from app.services.ai_assistant import ask_openai_assistant
from app.services.creator_intel_service import build_creator_intel_payload
from app.services.news_service import build_news_payload, build_sector_news_payload, build_stock_news_payload
from app.services.provider_factory import build_market_provider, build_news_provider
from app.services.screener_service import ScreenerService
from app.services.smart_money_service import get_smart_money_payload


router = APIRouter()
API_STARTED_AT = time.time()
REFRESH_TASK: asyncio.Task | None = None
REFRESH_STARTED_AT: datetime | None = None
REFRESH_LAST_ERROR: str | None = None


def _run_refresh_sync(triggered_by: str) -> dict:
    db = SessionLocal()
    try:
        repository = ScreeningRepository(db)
        return asyncio.run(run_daily_scan(repository, triggered_by=triggered_by))
    finally:
        db.close()


async def _run_refresh_job(triggered_by: str) -> None:
    global REFRESH_LAST_ERROR
    try:
        REFRESH_LAST_ERROR = None
        await asyncio.to_thread(_run_refresh_sync, triggered_by)
    except Exception as exc:
        REFRESH_LAST_ERROR = str(exc)


def _confidence_label(score: float) -> str:
    if score >= 75:
        return "High Data Confidence"
    if score >= 55:
        return "Moderate Data Confidence"
    return "Partial Data Confidence"


def serialize_row(row, previous_row=None) -> dict:
    score_delta = round(row.score - previous_row.score, 2) if previous_row else None
    rank_delta = previous_row.rank - row.rank if previous_row else None
    rs = (row.fundamentals or {}).get("relative_strength", 0)
    quarter_eps = (row.fundamentals or {}).get("quarterly_eps_growth_yoy")
    quarter_rev = (row.fundamentals or {}).get("quarterly_revenue_growth_yoy")
    reasons = []
    cautions = []
    if quarter_eps is not None and quarter_eps >= 25:
        reasons.append("strong EPS")
    if quarter_rev is not None and quarter_rev >= 20:
        reasons.append("strong sales")
    if rs is not None and rs >= 80:
        reasons.append("market leader")
    if (row.catalyst_signals or {}).get("positive_news_sentiment"):
        reasons.append("news support")
    if "Not in confirmed uptrend" in (row.flags or []):
        cautions.append("weak market")
    if "Lacks a convincing new-high technical setup" in (row.flags or []):
        cautions.append("off highs")
    if "Supply and demand setup is below preferred range" in (row.flags or []):
        cautions.append("weak volume")
    left = ", ".join(reasons[:2]) if reasons else "mixed setup"
    right = ", ".join(cautions[:2]) if cautions else "no major technical penalty"

    return {
        "ticker": row.ticker,
        "company_name": row.company_name,
        "sector": row.sector,
        "industry": row.industry,
        "as_of_date": row.created_at,
        "rank": row.rank,
        "score": row.score,
        "raw_score": row.raw_score,
        "confidence_score": row.confidence_score,
        "confidence_label": _confidence_label(row.confidence_score),
        "risk_level": row.risk_level,
        "grade": row.grade,
        "data_source": row.data_source,
        "market_cap_factor": row.market_cap_factor,
        "breakdown": row.breakdown,
        "strengths": row.strengths,
        "weaknesses": row.weaknesses,
        "flags": row.flags,
        "current_price": row.current_price,
        "current_volume": row.current_volume,
        "average_volume_50d": row.average_volume_50d,
        "fundamentals": row.fundamentals,
        "institutional": row.institutional,
        "catalyst_signals": row.catalyst_signals,
        "recent_headlines": row.recent_headlines,
        "sparkline": row.sparkline,
        "why_this_stock": row.why_this_stock,
        "reason_summary": f"{left}; {right}",
        "score_delta": score_delta,
        "rank_delta": rank_delta,
    }


def latest_payload(repository: ScreeningRepository, threshold: float, sector: str | None = None) -> dict | None:
    latest_rows = repository.latest_scan_rows(threshold=threshold, sector=sector)
    latest_run = repository.latest_scan_run()
    if not latest_run:
        return None
    latest_date = repository.latest_snapshot_date()
    previous_rows = repository.previous_rows_by_ticker(latest_date) if latest_date else {}
    coverage = (latest_run.market_snapshot or {}).get("coverage", {})
    return {
        "market": latest_run.market_snapshot,
        "results": [serialize_row(row, previous_rows.get(row.ticker)) for row in latest_rows],
        "threshold": threshold,
        "scanned_count": latest_run.scanned_count,
        "universe_count": coverage.get("universe_count", latest_run.scanned_count),
        "analyzed_count": coverage.get("analyzed_count", len(latest_rows)),
        "eligible_count": coverage.get("eligible_count"),
        "coverage_method": coverage.get("method"),
        "last_updated": latest_run.completed_at,
        "data_source": "LIVE",
    }


def get_service(db: Session = Depends(get_db)) -> ScreenerService:
    repository = ScreeningRepository(db)
    provider = build_market_provider()
    return ScreenerService(provider, build_news_provider(), repository, DataService(repository, provider))


@router.get("/health")
async def health(db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    latest_run = repository.latest_scan_run()
    return {
        "status": "ok",
        "last_run": latest_run.completed_at if latest_run else None,
        "data_source": "LIVE",
    }


@router.get("/status")
async def status(db: Session = Depends(get_db)) -> dict:
    settings = get_settings()
    local_model_path = Path.home() / ".cache" / "gpt4all" / settings.local_ai_model
    if settings.openai_api_key:
        ai_provider = "openai"
        ai_model = settings.openai_model
    elif settings.free_ai_enabled:
        ai_provider = "pollinations-free-ai"
        ai_model = settings.free_ai_model
    elif local_model_path.exists():
        ai_provider = "local-gpt4all"
        ai_model = settings.local_ai_model
    else:
        ai_provider = "growthintel-fallback"
        ai_model = "GrowthIntel fallback assistant"
    ai_configured = True
    repository = ScreeningRepository(db)
    latest_run = None
    database_status = "connected"
    try:
        latest_run = repository.latest_scan_run()
    except Exception:
        database_status = "degraded"
    return {
        "status": "ok" if database_status == "connected" else "degraded",
        "frontend": "online",
        "backend": "online",
        "database": database_status,
        "apis": "live-data-with-cache-fallback",
        "refresh": {
            "running": bool(REFRESH_TASK and not REFRESH_TASK.done()),
            "started_at": REFRESH_STARTED_AT,
            "last_error": REFRESH_LAST_ERROR,
        },
        "ai": {
            "provider": ai_provider,
            "model": ai_model,
            "configured": ai_configured,
        },
        "last_successful_refresh": latest_run.completed_at if latest_run else None,
        "uptime_seconds": round(time.time() - API_STARTED_AT, 1),
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }


@router.post("/ai/assistant")
async def ai_assistant(payload: dict = Body(default={}), db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    latest = latest_payload(repository, 0)
    if latest:
        payload = {
            **payload,
            "market": payload.get("market") or latest.get("market"),
            "top_stocks": payload.get("top_stocks") or latest.get("results", [])[:8],
        }
    return await ask_openai_assistant(payload)


@router.get("/top-stocks", response_model=ScreeningResponse)
async def top_stocks(
    threshold: float = Query(default=70, ge=0, le=100),
    sector: str | None = Query(default=None),
    tickers: list[str] | None = Query(default=None),
    refresh: bool = Query(default=False),
    service: ScreenerService = Depends(get_service),
    db: Session = Depends(get_db),
):
    effective_threshold = 0 if refresh else threshold
    if refresh:
        try:
            payload = await service.run_screen(tickers=tickers, threshold=effective_threshold, force_refresh=True, triggered_by="manual")
            if payload["results"]:
                payload["threshold"] = threshold
                return payload
            fallback = latest_payload(ScreeningRepository(db), effective_threshold, sector)
            if fallback:
                fallback["threshold"] = threshold
                fallback["scanned_count"] = payload.get("scanned_count", fallback["scanned_count"])
                latest_warning = (payload.get("market") or {}).get("warning_banner")
                if latest_warning:
                    existing_warning = (fallback.get("market") or {}).get("warning_banner")
                    if not existing_warning:
                        fallback["market"]["warning_banner"] = latest_warning
                    elif existing_warning in latest_warning:
                        fallback["market"]["warning_banner"] = latest_warning
                    elif latest_warning not in existing_warning:
                        fallback["market"]["warning_banner"] = f"{existing_warning} {latest_warning}".strip()
                return fallback
        except Exception:
            pass
        fallback = latest_payload(ScreeningRepository(db), effective_threshold, sector)
        if fallback:
            fallback["threshold"] = threshold
            return fallback
        return {
            "market": {"trend": "market_in_correction", "follow_through_day": False, "indices_above_50dma_ratio": 0.0, "indices_above_200dma_ratio": 0.0, "distribution_day_pressure": 0.0, "health_score": 0.0, "warning_banner": "Live refresh is temporarily degraded. No successful stock snapshot is available yet.", "indices": []},
            "results": [],
            "threshold": threshold,
            "scanned_count": 0,
            "universe_count": 0,
            "analyzed_count": 0,
            "eligible_count": 0,
            "coverage_method": "unavailable",
            "last_updated": None,
            "data_source": "LIVE",
        }

    repository = ScreeningRepository(db)
    cached_payload = latest_payload(repository, effective_threshold, sector)
    if cached_payload:
        cached_payload["threshold"] = threshold
        return cached_payload

    payload = await service.run_screen(tickers=tickers, threshold=effective_threshold, force_refresh=False, triggered_by="manual")
    payload["threshold"] = threshold
    return payload


@router.post("/refresh", response_model=RefreshResponse)
async def refresh() -> dict:
    global REFRESH_TASK, REFRESH_STARTED_AT
    if not REFRESH_TASK or REFRESH_TASK.done():
        REFRESH_STARTED_AT = datetime.now(timezone.utc)
        REFRESH_TASK = asyncio.create_task(_run_refresh_job("manual"))

    db = SessionLocal()
    try:
        latest_run = ScreeningRepository(db).latest_scan_run()
        last_updated = latest_run.completed_at if latest_run else REFRESH_STARTED_AT
        scanned_count = latest_run.scanned_count if latest_run else 0
    finally:
        db.close()
    return {
        "status": "running" if REFRESH_TASK and not REFRESH_TASK.done() else "ok",
        "triggered_by": "manual",
        "scanned_count": scanned_count,
        "last_updated": last_updated,
        "data_source": "LIVE",
    }


@router.get("/watchlist")
def get_watchlist(db: Session = Depends(get_db)) -> list[dict]:
    repository = ScreeningRepository(db)
    latest_date = repository.latest_snapshot_date()
    rows = {row.ticker: row for row in repository.latest_scan_rows(limit=500)}
    result = []
    for entry in repository.list_watchlist():
        current = rows.get(entry.ticker)
        result.append(
            {
                "ticker": entry.ticker,
                "note": entry.note,
                "created_at": entry.created_at,
                "latest_score": current.score if current else None,
                "latest_rank": current.rank if current else None,
                "date": latest_date,
            }
        )
    return result


@router.post("/watchlist")
def add_watchlist(payload: WatchlistCreate, db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    entry = repository.upsert_watchlist(payload.ticker, payload.note)
    return {"ticker": entry.ticker, "note": entry.note, "created_at": entry.created_at}


@router.get("/history/{ticker}", response_model=HistoryResponse)
def score_history(ticker: str, db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    history = repository.history_for_ticker(ticker)
    return {
        "ticker": ticker.upper(),
        "history": [
            {"date": item.date, "score": item.score, "rank": item.rank, "confidence_score": item.confidence_score}
            for item in history
        ],
    }


@router.get("/alerts")
def get_alerts(db: Session = Depends(get_db)) -> list[dict]:
    repository = ScreeningRepository(db)
    return [
        {"id": item.id, "ticker": item.ticker, "min_score": item.min_score, "top_n_rank": item.top_n_rank, "is_active": item.is_active}
        for item in repository.active_alerts()
    ]


@router.post("/alerts")
def create_alert(payload: AlertCreate, db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    alert = repository.create_alert(payload.ticker, payload.min_score, payload.top_n_rank)
    return {"id": alert.id, "ticker": alert.ticker, "min_score": alert.min_score, "top_n_rank": alert.top_n_rank, "is_active": alert.is_active}


@router.get("/news")
async def news_dashboard(db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    top_rows = repository.latest_scan_rows(limit=10)
    top_stocks = [{"ticker": row.ticker, "sector": row.sector, "score": row.score} for row in top_rows]
    watchlist = [entry.ticker for entry in repository.list_watchlist()]
    payload = await build_news_payload(top_stocks, watchlist)
    payload["data_source"] = "LIVE"
    return payload


@router.get("/earnings")
async def earnings_news(db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    top_rows = repository.latest_scan_rows(limit=12)
    symbols = [row.ticker for row in top_rows]
    payload = await build_earnings_payload(symbols)
    payload["data_source"] = "LIVE"
    return payload


@router.get("/stock-news")
async def stock_news(ticker: str = Query(..., min_length=1, max_length=10)) -> dict:
    payload = await build_stock_news_payload(ticker)
    payload["data_source"] = "LIVE"
    return payload


@router.get("/sector-news")
async def sector_news(sector: str = Query(..., min_length=2, max_length=40)) -> dict:
    payload = await build_sector_news_payload(sector)
    payload["data_source"] = "LIVE"
    return payload


@router.get("/breakouts")
async def breakouts(tickers: list[str] | None = Query(default=None), refresh: bool = Query(default=False), db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    scanner = BreakoutScanner(repository)
    return await scanner.scan(tickers=tickers, force_refresh=refresh)


@router.post("/scan-breakouts")
async def scan_breakouts(tickers: list[str] | None = Query(default=None), db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    scanner = BreakoutScanner(repository)
    return await scanner.scan(tickers=tickers, force_refresh=True)


@router.get("/portfolio/prices")
async def portfolio_prices(tickers: list[str] | None = Query(default=None)) -> dict:
    return fetch_live_quotes(tickers or [])


@router.get("/market-overview")
async def market_overview() -> dict:
    return fetch_market_overview()


@router.post("/portfolio/alerts")
async def portfolio_alerts(payload: dict = Body(default={})) -> dict:
    positions = payload.get("positions", []) if isinstance(payload.get("positions", []), list) else []
    settings = payload.get("settings", {}) if isinstance(payload.get("settings", {}), dict) else {}
    alert_settings = payload.get("alert_settings", {}) if isinstance(payload.get("alert_settings", {}), dict) else {}
    return evaluate_alerts(positions, settings=settings, alert_settings=alert_settings)


@router.post("/tester-feedback")
async def create_tester_feedback(payload: dict = Body(default={}), db: Session = Depends(get_db)) -> dict:
    feedback_type = str(payload.get("type") or "General Feedback")[:40]
    message = str(payload.get("message") or "").strip()
    if not message:
        return {"ok": False, "detail": "Message is required."}
    item = TesterFeedback(
        feedback_type=feedback_type,
        message=message[:5000],
        page=str(payload.get("page") or "")[:255] or None,
        tester_identifier=str(payload.get("tester_identifier") or "")[:255] or None,
        browser_info=payload.get("browser_info") if isinstance(payload.get("browser_info"), dict) else {},
        screenshot_url=str(payload.get("screenshot_url") or "")[:500] or None,
        status="new",
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return {"ok": True, "id": item.id, "status": item.status}


@router.get("/tester-feedback")
async def list_tester_feedback(
    db: Session = Depends(get_db),
    x_growthintel_admin_name: str | None = Header(default=None),
    x_growthintel_admin_token: str | None = Header(default=None),
) -> dict:
    settings = get_settings()
    token_ok = bool(settings.admin_token) and x_growthintel_admin_token == settings.admin_token
    name_ok = (x_growthintel_admin_name or "").strip().lower() == "buddydog"
    if not (token_ok or name_ok):
        raise HTTPException(status_code=403, detail="Feedback notes are admin-only.")
    rows = db.query(TesterFeedback).order_by(TesterFeedback.id.desc()).limit(100).all()
    return {
        "items": [
            {
                "id": row.id,
                "type": row.feedback_type,
                "message": row.message,
                "page": row.page,
                "timestamp": row.created_at.isoformat() if row.created_at else "",
                "tester_identifier": row.tester_identifier,
                "status": row.status,
                "screenshot_url": row.screenshot_url,
                "browser_info": row.browser_info or {},
            }
            for row in rows
        ]
    }


@router.get("/smart-money")
async def smart_money(group: str | None = Query(default=None), investor: str | None = Query(default=None)) -> dict:
    return get_smart_money_payload(group=group, investor=investor)


@router.get("/creator-intel")
async def creator_intel(db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    return await build_creator_intel_payload(repository)


@router.get("/early-view")
async def early_view(window: int = Query(default=3), db: Session = Depends(get_db)) -> dict:
    repository = ScreeningRepository(db)
    return await build_early_view_payload(repository, window_minutes=window)
