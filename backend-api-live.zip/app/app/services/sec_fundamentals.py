from __future__ import annotations

import math
import threading
import time

import requests


SEC_HEADERS = {
    "User-Agent": "GrowthIntel market research support@growthintel.app",
    "Accept-Encoding": "gzip, deflate",
}
_mapping_lock = threading.Lock()
_mapping: dict[str, tuple[int, str]] = {}
_mapping_loaded_at = 0.0
_facts_cache: dict[str, tuple[float, dict]] = {}


def _safe(value, default=0.0) -> float:
    try:
        numeric = float(value)
        return numeric if math.isfinite(numeric) else default
    except (TypeError, ValueError):
        return default


def _ticker_mapping() -> dict[str, tuple[int, str]]:
    global _mapping, _mapping_loaded_at
    with _mapping_lock:
        if _mapping and time.time() - _mapping_loaded_at < 24 * 60 * 60:
            return _mapping
        response = requests.get(
            "https://www.sec.gov/files/company_tickers_exchange.json",
            headers=SEC_HEADERS,
            timeout=25,
        )
        response.raise_for_status()
        payload = response.json()
        fields = payload.get("fields") or []
        rows = payload.get("data") or []
        indices = {name: index for index, name in enumerate(fields)}
        mapping: dict[str, tuple[int, str]] = {}
        for row in rows:
            ticker = str(row[indices.get("ticker", 2)] or "").upper().replace(".", "-")
            cik = int(row[indices.get("cik", 0)])
            name = str(row[indices.get("name", 1)] or ticker)
            if ticker:
                mapping[ticker] = (cik, name)
        _mapping = mapping
        _mapping_loaded_at = time.time()
        return _mapping


def _fact_entries(facts: dict, concepts: tuple[str, ...], units: tuple[str, ...]) -> list[dict]:
    us_gaap = ((facts.get("facts") or {}).get("us-gaap") or {})
    for concept in concepts:
        unit_map = ((us_gaap.get(concept) or {}).get("units") or {})
        for unit in units:
            entries = unit_map.get(unit)
            if entries:
                return [
                    item for item in entries
                    if item.get("form") in {"10-Q", "10-K"} and item.get("filed") and item.get("val") is not None
                ]
    return []


def _latest_quarters(entries: list[dict]) -> list[dict]:
    framed = [item for item in entries if str(item.get("frame") or "").startswith("CY") and "Q" in str(item.get("frame"))]
    by_frame: dict[str, dict] = {}
    for item in framed:
        frame = str(item.get("frame"))
        previous = by_frame.get(frame)
        if not previous or str(item.get("filed") or "") > str(previous.get("filed") or ""):
            by_frame[frame] = item
    return sorted(by_frame.values(), key=lambda item: (item.get("end") or "", item.get("filed") or ""))


def _latest_years(entries: list[dict]) -> list[dict]:
    framed = [item for item in entries if str(item.get("frame") or "").startswith("CY") and "Q" not in str(item.get("frame"))]
    by_frame: dict[str, dict] = {}
    for item in framed:
        frame = str(item.get("frame"))
        previous = by_frame.get(frame)
        if not previous or str(item.get("filed") or "") > str(previous.get("filed") or ""):
            by_frame[frame] = item
    return sorted(by_frame.values(), key=lambda item: (item.get("end") or "", item.get("filed") or ""))


def _growth(current: float, previous: float) -> float:
    if previous == 0:
        return 0.0
    return ((current - previous) / abs(previous)) * 100.0


def _prior_year_value(entries: list[dict]) -> float:
    if not entries:
        return 0.0
    latest_frame = str(entries[-1].get("frame") or "")
    if not latest_frame.startswith("CY") or "Q" not in latest_frame:
        return 0.0
    try:
        year = int(latest_frame[2:6])
        quarter = latest_frame.split("Q", 1)[1]
    except (ValueError, IndexError):
        return 0.0
    target = f"CY{year - 1}Q{quarter}"
    match = next((item for item in reversed(entries) if item.get("frame") == target), None)
    return _safe(match.get("val")) if match else 0.0


def fetch_sec_fundamentals(ticker: str) -> dict:
    ticker = ticker.upper()
    cached = _facts_cache.get(ticker)
    if cached and time.time() - cached[0] < 24 * 60 * 60:
        return cached[1]

    mapping = _ticker_mapping()
    identity = mapping.get(ticker)
    if not identity:
        return {}
    cik, company_name = identity
    response = requests.get(
        f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json",
        headers=SEC_HEADERS,
        timeout=25,
    )
    response.raise_for_status()
    facts = response.json()

    revenue = _latest_quarters(_fact_entries(
        facts,
        ("RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet"),
        ("USD",),
    ))
    net_income = _latest_quarters(_fact_entries(facts, ("NetIncomeLoss", "ProfitLoss"), ("USD",)))
    eps = _latest_quarters(_fact_entries(facts, ("EarningsPerShareDiluted", "EarningsPerShareBasic"), ("USD/shares",)))
    annual_eps = _latest_years(_fact_entries(facts, ("EarningsPerShareDiluted", "EarningsPerShareBasic"), ("USD/shares",)))
    annual_income = _latest_years(_fact_entries(facts, ("NetIncomeLoss", "ProfitLoss"), ("USD",)))
    equity = _latest_years(_fact_entries(facts, ("StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"), ("USD",)))

    latest_revenue = _safe(revenue[-1].get("val")) if revenue else 0.0
    prior_revenue = _prior_year_value(revenue)
    latest_income = _safe(net_income[-1].get("val")) if net_income else 0.0
    prior_income = _prior_year_value(net_income)
    latest_eps = _safe(eps[-1].get("val")) if eps else 0.0
    prior_eps = _prior_year_value(eps)
    current_margin = latest_income / latest_revenue if latest_revenue else 0.0
    prior_margin = prior_income / prior_revenue if prior_revenue else 0.0

    eps_cagr = 0.0
    if len(annual_eps) >= 4:
        first = _safe(annual_eps[-4].get("val"))
        last = _safe(annual_eps[-1].get("val"))
        if first > 0 and last > 0:
            eps_cagr = ((last / first) ** (1 / 3) - 1) * 100.0

    latest_annual_income = _safe(annual_income[-1].get("val")) if annual_income else 0.0
    latest_equity = _safe(equity[-1].get("val")) if equity else 0.0
    result = {
        "company_name": company_name,
        "current_quarter": {
            "eps_growth_yoy": _growth(latest_eps, prior_eps),
            "revenue_growth_yoy": _growth(latest_revenue, prior_revenue),
            "margin_change_bps": (current_margin - prior_margin) * 10_000.0,
            "recent_eps_growth": [],
        },
        "annual": {
            "eps_cagr_3y": eps_cagr,
            "roe": (latest_annual_income / latest_equity) * 100.0 if latest_equity else 0.0,
            "margin_stability": 0.7,
            "positive_eps_years": sum(1 for item in annual_eps[-3:] if _safe(item.get("val")) > 0),
        },
    }
    _facts_cache[ticker] = (time.time(), result)
    return result
