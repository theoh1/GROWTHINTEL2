from __future__ import annotations

from datetime import date, datetime, timedelta

from app.core.config import get_settings
from app.data.universe import LIQUID_US_UNIVERSE
from app.data.live_universe import current_us_equity_universe
from app.core.grading import numeric_to_grade
from app.repositories.screening_repository import ScreeningRepository
from app.services.canslim_scorer import CANSLIMScorer
from app.services.data_service import DataService
from app.services.market_trend import MarketTrendAnalyzer
from app.services.providers import MarketDataProvider, NewsSignalProvider


class ScreenerService:
    def __init__(
        self,
        market_provider: MarketDataProvider,
        news_provider: NewsSignalProvider,
        repository: ScreeningRepository | None = None,
        data_service: DataService | None = None,
    ):
        self.market_provider = market_provider
        self.news_provider = news_provider
        self.repository = repository
        self.data_service = data_service
        self.market_analyzer = MarketTrendAnalyzer()
        self.scorer = CANSLIMScorer()

    async def run_screen(
        self,
        tickers: list[str] | None = None,
        threshold: float = 0,
        force_refresh: bool = False,
        triggered_by: str = "manual",
    ) -> dict:
        settings = get_settings()
        if tickers:
            full_universe = tickers
        elif settings.default_screen_universe.strip().upper() == "FULL_US_FREE":
            full_universe = current_us_equity_universe()
        else:
            full_universe = settings.default_screen_universe_list
        full_universe = list(dict.fromkeys(ticker.upper() for ticker in full_universe if ticker))
        screening_universe = self._select_active_universe(full_universe, settings.universe_scan_budget)
        coverage_count = len(screening_universe)
        eligible_count = len(screening_universe)
        coverage_method = "rotating_universe"

        can_prefilter_full_market = (
            tickers is None
            and settings.default_screen_universe.strip().upper() == "FULL_US_FREE"
            and hasattr(self.market_provider, "prefilter_market")
        )
        if can_prefilter_full_market:
            cache_key = "full_market_prefilter:v3"
            cached_prefilter = self.repository.get_cache(cache_key) if self.repository else None
            refresh_prefilter = triggered_by == "scheduler" or not cached_prefilter
            if refresh_prefilter:
                prefilter = await self.market_provider.prefilter_market(full_universe, settings.deep_analysis_max_symbols)
                if self.repository and prefilter.get("tickers"):
                    self.repository.set_cache(
                        cache_key,
                        prefilter,
                        datetime.utcnow() + timedelta(hours=settings.full_market_prefilter_cache_hours),
                    )
            else:
                prefilter = cached_prefilter

            if prefilter and prefilter.get("tickers"):
                screening_universe = list(prefilter["tickers"])
                coverage_count = int(prefilter.get("screened_count") or len(full_universe))
                eligible_count = int(prefilter.get("eligible_count") or len(screening_universe))
                coverage_method = "full_market_technical_prefilter"

        market_indices = await self._get_market_overview(force_refresh=force_refresh)
        market = self.market_analyzer.evaluate(market_indices)
        if coverage_method == "full_market_technical_prefilter":
            note = (
                f"Screened {coverage_count:,} of {len(full_universe):,} current US listings for price, liquidity, and momentum, "
                f"then deep-analysed {len(screening_universe)} leading candidates."
            )
        elif len(screening_universe) < len(full_universe):
            note = f"Scanning a rotating slice of {len(screening_universe)} from {len(full_universe)} symbols."
        else:
            note = ""
        if note:
            warning = market.get("warning_banner")
            market["warning_banner"] = f"{warning} {note}".strip() if warning else note
        market["coverage"] = {
            "universe_count": len(full_universe),
            "screened_count": coverage_count,
            "eligible_count": eligible_count,
            "analyzed_count": len(screening_universe),
            "method": coverage_method,
        }
        stocks = await self._get_stock_universe(screening_universe, force_refresh=force_refresh)
        stocks = await self.news_provider.enrich(stocks)
        stocks = self._enrich_cross_sectional_metrics(stocks, market)

        ranked_results = []
        for stock in stocks:
            score_data = self.scorer.final_score(stock, market)
            ranked_results.append(self._build_result(stock, score_data))

        ranked_results.sort(key=lambda item: item["score"], reverse=True)
        for rank, result in enumerate(ranked_results, start=1):
            result["rank"] = rank

        latest_timestamp = max((result["as_of_date"] for result in ranked_results), default=None)
        run_date = latest_timestamp.date() if latest_timestamp else date.today()
        previous_rows = self.repository.previous_rows_by_ticker(run_date) if self.repository and ranked_results else {}
        for result in ranked_results:
            previous_row = previous_rows.get(result["ticker"])
            if previous_row:
                result["score_delta"] = round(result["score"] - previous_row.score, 2)
                result["rank_delta"] = previous_row.rank - result["rank"]
            else:
                result["score_delta"] = None
                result["rank_delta"] = None

        filtered_results = [result for result in ranked_results if result["score"] >= threshold]
        payload = {
            "market": market,
            "results": filtered_results,
            "threshold": threshold,
            "scanned_count": coverage_count,
            "universe_count": len(full_universe),
            "analyzed_count": len(stocks),
            "eligible_count": eligible_count,
            "coverage_method": coverage_method,
            "last_updated": latest_timestamp,
            "data_source": "LIVE" if not settings.use_mock_data else "MOCK",
        }

        if self.repository and ranked_results:
            self.repository.replace_daily_rows([self._to_daily_row(result, run_date) for result in ranked_results], run_date)
            self.repository.record_scan_run(triggered_by, coverage_count, ranked_results[0]["score"], market)

        return payload

    def _select_active_universe(self, universe: list[str], budget: int) -> list[str]:
        deduped = list(dict.fromkeys(ticker.upper() for ticker in universe if ticker))
        if len(deduped) <= budget:
            return deduped

        today_seed = date.today().timetuple().tm_yday
        rotated_offset = today_seed % len(deduped)
        rotated = deduped[rotated_offset:] + deduped[:rotated_offset]
        stride = max(1, len(rotated) // budget)
        sampled = rotated[::stride][:budget]

        anchors = [ticker for ticker in LIQUID_US_UNIVERSE if ticker in deduped]
        merged = list(dict.fromkeys(anchors + sampled))
        return merged[:budget]

    async def evaluate_alerts(self) -> list[dict]:
        if not self.repository:
            return []

        latest_rows = self.repository.latest_scan_rows(limit=100)
        by_ticker = {row.ticker: row for row in latest_rows}
        triggered: list[dict] = []
        for alert in self.repository.active_alerts():
            if alert.ticker and alert.ticker in by_ticker:
                row = by_ticker[alert.ticker]
                if alert.min_score is not None and row.score >= alert.min_score:
                    triggered.append({"ticker": row.ticker, "score": row.score, "reason": f"score above {alert.min_score}"})
            if alert.top_n_rank is not None:
                for row in latest_rows:
                    if row.rank <= alert.top_n_rank:
                        triggered.append({"ticker": row.ticker, "score": row.score, "reason": f"entered top {alert.top_n_rank}"})
        return triggered

    async def _get_market_overview(self, force_refresh: bool) -> list[dict]:
        if self.data_service:
            return await self.data_service.get_market_overview(force_refresh=force_refresh)
        return await self.market_provider.fetch_market_overview()

    async def _get_stock_universe(self, tickers: list[str], force_refresh: bool) -> list[dict]:
        if self.data_service:
            return await self.data_service.get_stock_data(tickers, force_refresh=force_refresh)
        return await self.market_provider.fetch_stock_universe(tickers)

    def _build_result(self, stock: dict, score_data: dict) -> dict:
        confidence_score = self._confidence_score(stock, score_data)
        risk_level = self._risk_level(score_data["score"], stock)
        sparkline = [round(point["close"], 2) for point in stock.get("price_history", [])[-20:]]
        why_this_stock = self._why_this_stock(stock, score_data, confidence_score, risk_level)
        reason_summary = self._reason_summary(stock, score_data)

        return {
            "ticker": stock["ticker"],
            "company_name": stock["company_name"],
            "sector": stock["sector"],
            "industry": stock["industry"],
            "as_of_date": stock["as_of_date"],
            "rank": 0,
            "score": score_data["score"],
            "raw_score": score_data["raw_score"],
            "confidence_score": confidence_score,
            "confidence_label": self._confidence_label(confidence_score),
            "risk_level": risk_level,
            "grade": numeric_to_grade(score_data["score"]),
            "data_source": "LIVE" if not get_settings().use_mock_data else "MOCK",
            "market_cap_factor": score_data["market_cap_factor"],
            "breakdown": score_data["breakdown"],
            "strengths": score_data["strengths"],
            "weaknesses": score_data["weaknesses"],
            "flags": score_data["flags"],
            "current_price": stock.get("current_price"),
            "current_volume": stock.get("current_volume"),
            "average_volume_50d": stock.get("average_volume_50d"),
            "fundamentals": {
                "quarterly_eps_growth_yoy": stock["current_quarter"]["eps_growth_yoy"],
                "quarterly_revenue_growth_yoy": stock["current_quarter"]["revenue_growth_yoy"],
                "margin_change_bps": stock["current_quarter"]["margin_change_bps"],
                "annual_eps_cagr_3y": stock["annual"]["eps_cagr_3y"],
                "roe": stock["annual"]["roe"],
                "relative_strength": stock["leadership"]["relative_strength"],
                "industry_percentile": stock["leadership"]["industry_percentile"] * 100.0,
                "market_cap": stock.get("market_cap", 0.0),
            },
            "institutional": stock["institutional"],
            "catalyst_signals": stock["new_factors"],
            "recent_headlines": stock.get("recent_headlines", []),
            "sparkline": sparkline,
            "why_this_stock": why_this_stock,
            "reason_summary": reason_summary,
            "score_delta": None,
            "rank_delta": None,
        }

    def _to_daily_row(self, result: dict, run_date: date) -> dict:
        return {
            "ticker": result["ticker"],
            "company_name": result["company_name"],
            "sector": result["sector"],
            "industry": result["industry"],
            "date": run_date,
            "rank": result["rank"],
            "score": result["score"],
            "raw_score": result["raw_score"],
            "confidence_score": result["confidence_score"],
            "risk_level": result["risk_level"],
            "grade": result["grade"],
            "data_source": result["data_source"],
            "market_cap_factor": result["market_cap_factor"],
            "current_price": result["current_price"],
            "current_volume": result["current_volume"],
            "average_volume_50d": result["average_volume_50d"],
            "breakdown": result["breakdown"],
            "strengths": result["strengths"],
            "weaknesses": result["weaknesses"],
            "flags": result["flags"],
            "fundamentals": result["fundamentals"],
            "institutional": result["institutional"],
            "catalyst_signals": result["catalyst_signals"],
            "recent_headlines": result["recent_headlines"],
            "sparkline": result["sparkline"],
            "why_this_stock": result["why_this_stock"],
        }

    def _enrich_cross_sectional_metrics(self, stocks: list[dict], market: dict) -> list[dict]:
        if not stocks:
            return stocks

        ranked = sorted(stocks, key=lambda stock: stock.get("performance_6m", 0.0))
        total = len(ranked)
        spy_index = next((index for index in market["indices"] if index["symbol"] == "SPY"), None)
        spy_return = 0.0
        if spy_index and spy_index["ma_200"]:
            spy_return = ((spy_index["close"] / spy_index["ma_200"]) - 1.0) * 100.0

        sector_groups: dict[str, list[float]] = {}
        industry_groups: dict[str, list[float]] = {}
        for stock in stocks:
            sector_groups.setdefault(stock["sector"], []).append(stock.get("performance_6m", 0.0))
            industry_groups.setdefault(stock["industry"], []).append(stock.get("performance_6m", 0.0))

        for index, stock in enumerate(ranked):
            performance_6m = stock.get("performance_6m", 0.0)
            rs = 1 + ((index / max(1, total - 1)) * 98)
            stock["leadership"]["relative_strength"] = rs
            stock["leadership"]["performance_vs_index_6m"] = performance_6m - spy_return
            stock["leadership"]["sector_percentile"] = self._percentile(performance_6m, sector_groups.get(stock["sector"], [performance_6m]))
            stock["leadership"]["industry_percentile"] = self._percentile(performance_6m, industry_groups.get(stock["industry"], [performance_6m]))
        return stocks

    def _percentile(self, value: float, peers: list[float]) -> float:
        if not peers:
            return 0.0
        less_or_equal = sum(1 for peer in peers if peer <= value)
        return less_or_equal / len(peers)

    def _confidence_score(self, stock: dict, score_data: dict) -> float:
        score = score_data["score"]
        data_completeness = 0.0
        if stock.get("current_price"):
            data_completeness += 20
        if stock.get("recent_headlines"):
            data_completeness += 20
        if stock["institutional"].get("ownership_pct") is not None:
            data_completeness += 20
        if stock["annual"].get("roe") is not None:
            data_completeness += 20
        if stock["leadership"].get("relative_strength") is not None:
            data_completeness += 20
        return round(min(100.0, score * 0.65 + data_completeness * 0.35), 2)

    def _risk_level(self, score: float, stock: dict) -> str:
        if score >= 85 and stock["technicals"]["distance_to_52w_high_pct"] <= 5:
            return "Low"
        if score >= 70:
            return "Medium"
        return "High"

    def _why_this_stock(self, stock: dict, score_data: dict, confidence_score: float, risk_level: str) -> str:
        reasons = []
        if stock["current_quarter"]["eps_growth_yoy"] >= 25:
            reasons.append("quarterly EPS growth clears the CANSLIM hurdle")
        if stock["annual"]["eps_cagr_3y"] >= 25:
            reasons.append("multi-year earnings compounding is strong")
        if stock["leadership"]["relative_strength"] >= 80:
            reasons.append("relative strength is leading the market")
        if stock["new_factors"].get("positive_news_sentiment"):
            reasons.append("recent news flow is constructive")
        if stock["institutional"].get("fund_holders_qoq_change", 0) > 0:
            reasons.append("institutional sponsorship is expanding")
        joined = ", ".join(reasons[:4]) if reasons else "the setup is mixed and needs more confirmation"
        return f"{stock['ticker']} scores {score_data['score']:.1f}/100 because {joined}. Confidence is {confidence_score:.0f}/100 and current risk is {risk_level.lower()}."

    def _reason_summary(self, stock: dict, score_data: dict) -> str:
        positives: list[str] = []
        cautions: list[str] = []
        if stock["current_quarter"]["eps_growth_yoy"] >= 25:
            positives.append("strong EPS")
        if stock["current_quarter"]["revenue_growth_yoy"] >= 20:
            positives.append("strong sales")
        if stock["leadership"]["relative_strength"] >= 80:
            positives.append("market leader")
        if stock["new_factors"].get("positive_news_sentiment"):
            positives.append("news support")
        if stock["technicals"]["distance_to_52w_high_pct"] > 8:
            cautions.append("off highs")
        if score_data["breakdown"]["M"]["score"] < 7:
            cautions.append("weak market")
        if score_data["breakdown"]["S"]["score"] < 4:
            cautions.append("weak volume")

        left = ", ".join(positives[:2]) if positives else "mixed setup"
        right = ", ".join(cautions[:2]) if cautions else "no major technical penalty"
        return f"{left}; {right}"

    def _confidence_label(self, confidence_score: float) -> str:
        if confidence_score >= 75:
            return "High Data Confidence"
        if confidence_score >= 55:
            return "Moderate Data Confidence"
        return "Partial Data Confidence"
