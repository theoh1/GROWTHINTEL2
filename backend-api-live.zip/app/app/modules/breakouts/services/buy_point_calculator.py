from __future__ import annotations


def breakout_status(
    *,
    buy_point: float,
    current_price: float,
    previous_close: float,
    current_volume: float,
    average_volume: float,
    day_high: float,
    day_low: float,
    pattern_confidence: float,
) -> dict:
    if buy_point <= 0:
        return {
            "status": "Faulty Base",
            "distance_from_buy_point_pct": 0.0,
            "volume_vs_average_pct": 0.0,
            "close_strength": 0.0,
            "is_valid_breakout": False,
        }

    distance_pct = ((current_price - buy_point) / buy_point) * 100.0
    volume_ratio = (current_volume / average_volume) if average_volume > 0 else 0.0
    volume_vs_average_pct = (volume_ratio - 1.0) * 100.0
    intraday_range = max(0.01, day_high - day_low)
    close_strength = (current_price - day_low) / intraday_range

    crossed_today = previous_close < buy_point <= current_price
    in_buy_zone = 0 <= distance_pct <= 5
    strong_volume = volume_ratio >= 1.5
    strong_close = close_strength >= 0.75
    held_pivot = day_low >= buy_point * 0.97
    valid_breakout = crossed_today and in_buy_zone and strong_volume and strong_close and held_pivot

    if pattern_confidence < 72:
        status = "Faulty Base"
    elif valid_breakout:
        status = "Breaking Out"
    elif in_buy_zone and strong_volume and strong_close:
        status = "In Buy Zone"
    elif in_buy_zone:
        status = "Needs Volume"
    elif distance_pct > 5:
        status = "Extended"
    elif -12 <= distance_pct < 0:
        status = "Below Buy Point"
    else:
        status = "Faulty Base"

    return {
        "status": status,
        "distance_from_buy_point_pct": round(distance_pct, 2),
        "volume_vs_average_pct": round(volume_vs_average_pct, 2),
        "close_strength": round(close_strength * 100.0, 2),
        "is_valid_breakout": valid_breakout,
        "safety_checks": {
            "crossed_pivot_today": crossed_today,
            "inside_5_pct_buy_zone": in_buy_zone,
            "volume_at_least_50_pct_above_average": strong_volume,
            "closed_in_top_quarter_of_range": strong_close,
            "held_within_3_pct_of_pivot_intraday": held_pivot,
            "pattern_confidence_at_least_72": pattern_confidence >= 72,
        },
    }
