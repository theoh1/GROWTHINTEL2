from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PatternCandidate:
    pattern_type: str
    buy_point: float
    confidence: float
    base_start_index: int
    base_end_index: int
    notes: list[str]


def _max_drawdown_pct(high: float, low: float) -> float:
    if high <= 0:
        return 0.0
    return ((high - low) / high) * 100.0


def _window(values: list[float], start: int, end: int) -> list[float]:
    return values[max(0, start) : min(len(values), end)]


def _find_local_min(values: list[float], start: int, end: int) -> tuple[int, float] | None:
    segment = _window(values, start, end)
    if not segment:
        return None
    local_idx = segment.index(min(segment))
    return start + local_idx, segment[local_idx]


def _find_local_max(values: list[float], start: int, end: int) -> tuple[int, float] | None:
    segment = _window(values, start, end)
    if not segment:
        return None
    local_idx = segment.index(max(segment))
    return start + local_idx, segment[local_idx]


def _sma(values: list[float], end: int, length: int) -> float:
    segment = values[max(0, end - length + 1) : end + 1]
    return sum(segment) / max(1, len(segment))


def _prior_uptrend(closes: list[float], pivot_index: int) -> bool:
    lookback = max(0, pivot_index - 70)
    if pivot_index - lookback < 35:
        return False
    prior_low = min(closes[lookback : max(lookback + 1, pivot_index - 20)])
    prior_gain = ((closes[pivot_index] - prior_low) / max(0.01, prior_low)) * 100.0
    ma50 = _sma(closes, pivot_index, 50)
    return prior_gain >= 25 and closes[pivot_index] >= ma50


def _avg(values: list[float]) -> float:
    return sum(values) / max(1, len(values))


def _tightness_score(closes: list[float]) -> float:
    if len(closes) < 10:
        return 0.0
    ranges = []
    for start in range(0, len(closes), 5):
        week = closes[start : start + 5]
        if len(week) >= 3:
            ranges.append(_max_drawdown_pct(max(week), min(week)))
    if not ranges:
        return 0.0
    avg_range = _avg(ranges)
    return max(0.0, 1.0 - min(1.0, avg_range / 8.0))


def _rounded_u_score(closes: list[float], left: int, trough: int, right: int) -> float:
    if trough <= left or trough >= right:
        return 0.0
    left_leg = closes[left] - closes[trough]
    right_leg = closes[right] - closes[trough]
    if left_leg <= 0 or right_leg <= 0:
        return 0.0
    symmetry = 1.0 - min(1.0, abs(left_leg - right_leg) / max(left_leg, right_leg))
    trough_position = (trough - left) / max(1, (right - left))
    center_score = 1.0 - abs(0.5 - trough_position) * 2.0
    return max(0.0, (symmetry * 0.6) + (center_score * 0.4))


def detect_cup_with_handle(closes: list[float], highs: list[float], volumes: list[float]) -> PatternCandidate | None:
    if len(closes) < 70:
        return None
    right = len(closes) - 1
    left = max(0, right - 120)
    left_high = max(highs[left : left + 35])
    left_idx = left + highs[left : left + 35].index(left_high)
    if not _prior_uptrend(closes, left_idx):
        return None

    trough = _find_local_min(closes, left_idx + 12, right - 18)
    if trough is None:
        return None
    trough_idx, trough_price = trough
    depth = _max_drawdown_pct(left_high, trough_price)
    cup_length = right - left_idx
    if depth < 12 or depth > 33 or cup_length < 35:
        return None

    right_side_max = _find_local_max(highs, trough_idx + 12, right - 7)
    if right_side_max is None:
        return None
    right_idx, right_high = right_side_max
    if right_high < left_high * 0.95 or right_high > left_high * 1.08:
        return None

    handle_start = right_idx + 1
    handle_length = right - handle_start + 1
    if handle_length < 5 or handle_length > 20:
        return None
    handle_closes = closes[handle_start : right + 1]
    handle_high = max(highs[handle_start : right + 1])
    handle_low = min(handle_closes)
    handle_depth = _max_drawdown_pct(handle_high, handle_low)
    upper_half_threshold = trough_price + ((left_high - trough_price) * 0.5)
    if handle_depth < 3 or handle_depth > 12 or handle_low < upper_half_threshold:
        return None
    if handle_closes[-1] < handle_closes[0] * 0.82:
        return None
    if max(handle_closes) > left_high * 1.08:
        return None

    handle_vol = sum(volumes[handle_start : right + 1]) / max(1, right - handle_start + 1)
    prior_vol = sum(volumes[max(left_idx, handle_start - 20) : handle_start]) / max(1, handle_start - max(left_idx, handle_start - 20))
    vol_dryup = prior_vol > 0 and handle_vol <= prior_vol * 0.9
    u_score = _rounded_u_score(closes, left_idx, trough_idx, right_idx)
    if u_score < 0.68:
        return None
    confidence = 58 + (u_score * 20) + (10 if vol_dryup else 0) + (8 if 12 <= depth <= 25 else 3)
    buy_point = handle_high * 1.001
    notes = [
        "confirmed prior uptrend",
        "cup depth 12-33%",
        ">=7 week cup",
        "right side recovered near old high",
        "handle 5-20 sessions",
        "handle depth 3-12%",
        "handle upper half",
        "volume dry-up" if vol_dryup else "handle volume not ideal",
        "buy point is handle high + safety buffer",
    ]
    return PatternCandidate("Cup with Handle", buy_point, min(98.0, confidence), left_idx, right, notes)


def detect_cup_without_handle(closes: list[float], highs: list[float]) -> PatternCandidate | None:
    # O'Neil-style cup-without-handle entries are more failure-prone. Keep this
    # out of the breakout feed unless a later, explicit ruleset is added.
    return None
    if len(closes) < 45:
        return None
    right = len(closes) - 1
    left = max(0, right - 120)
    left_max = _find_local_max(closes, left, left + 30)
    if left_max is None:
        return None
    left_idx, left_high = left_max
    trough = _find_local_min(closes, left_idx + 8, right - 6)
    if trough is None:
        return None
    trough_idx, trough_price = trough
    depth = _max_drawdown_pct(left_high, trough_price)
    if depth < 12 or depth > 33 or (right - left_idx) < 35:
        return None
    right_max = _find_local_max(highs, trough_idx + 10, right + 1)
    if right_max is None:
        return None
    right_idx, right_high = right_max
    if right_high < left_high * 0.92:
        return None
    confidence = 55 + (_rounded_u_score(closes, left_idx, trough_idx, right_idx) * 18)
    return PatternCandidate("Cup without Handle", right_high * 1.001, min(95.0, confidence), left_idx, right, ["depth 12-33%", "rounded recovery"])


def detect_flat_base(closes: list[float], highs: list[float]) -> PatternCandidate | None:
    if len(closes) < 55:
        return None
    right = len(closes) - 1
    base_start = right - 29
    if not _prior_uptrend(closes, base_start):
        return None
    base = closes[base_start : right + 1]
    base_high = max(base)
    base_low = min(base)
    depth = _max_drawdown_pct(base_high, base_low)
    if depth <= 15:
        tightness = _tightness_score(base)
        if tightness < 0.45:
            return None
        confidence = 62 + (tightness * 20) + (5 if depth <= 10 else 0)
        buy_point = max(highs[base_start : right + 1]) * 1.001
        return PatternCandidate(
            "Flat Base",
            buy_point,
            min(92.0, confidence),
            base_start,
            right,
            ["confirmed prior uptrend", "5+ week base", "depth <=15%", "tight weekly closes", "buy point is base high + safety buffer"],
        )
    return None


def detect_double_bottom(closes: list[float], highs: list[float]) -> PatternCandidate | None:
    if len(closes) < 75:
        return None
    right = len(closes) - 1
    start = max(0, right - 80)
    first = _find_local_min(closes, start + 8, start + 35)
    second = _find_local_min(closes, start + 35, right - 8)
    if first is None or second is None:
        return None
    first_idx, first_low = first
    second_idx, second_low = second
    if not _prior_uptrend(closes, start + 8):
        return None
    if second_idx - first_idx < 15:
        return None
    if second_low >= first_low:
        return None
    undercut = ((first_low - second_low) / max(0.01, first_low)) * 100.0
    if undercut < 0.2 or undercut > 5:
        return None
    middle_peak = _find_local_max(highs, first_idx + 3, second_idx - 2)
    if middle_peak is None:
        return None
    peak_idx, peak = middle_peak
    if peak_idx <= first_idx or peak_idx >= second_idx:
        return None
    base_high = max(highs[start : right + 1])
    base_low = min(closes[start : right + 1])
    if _max_drawdown_pct(base_high, base_low) > 33:
        return None
    confidence = 66 + (10 if undercut >= 1.0 else 4) + (5 if closes[-1] > closes[second_idx] else 0)
    return PatternCandidate(
        "Double Bottom",
        peak * 1.001,
        min(92.0, confidence),
        start,
        right,
        ["confirmed prior uptrend", "W-base", "second low undercuts first by 0.2-5%", "pivot is middle peak + safety buffer"],
    )


def detect_ascending_base(closes: list[float], highs: list[float]) -> PatternCandidate | None:
    if len(closes) < 60:
        return None
    right = len(closes) - 1
    start = max(0, right - 75)
    if not _prior_uptrend(closes, start + 10):
        return None
    lows = []
    slices = [(start, start + 20), (start + 20, start + 40), (start + 40, right)]
    for left, end in slices:
        found = _find_local_min(closes, left, end)
        if found is None:
            return None
        lows.append(found[1])
    if not (lows[0] < lows[1] < lows[2]):
        return None
    pullbacks = []
    for idx, (left, end) in enumerate(slices):
        local_high = max(closes[left:end])
        pullback = _max_drawdown_pct(local_high, lows[idx])
        pullbacks.append(pullback)
    if any(value > 12 for value in pullbacks):
        return None
    buy_point = max(highs[start : right + 1]) * 1.001
    confidence = 65 + (10 if max(pullbacks) <= 9 else 4)
    return PatternCandidate("Ascending Base", buy_point, min(90.0, confidence), start, right, ["three rising pullbacks", "shallow declines"])


def detect_ipo_base(closes: list[float], highs: list[float]) -> PatternCandidate | None:
    age = len(closes)
    if age < 25 or age > 260:
        return None
    right = len(closes) - 1
    start = max(0, right - 45)
    base_high = max(highs[start : right + 1])
    base_low = min(closes[start : right + 1])
    depth = _max_drawdown_pct(base_high, base_low)
    if depth > 25:
        return None
    confidence = 58 + (12 if age < 140 else 5)
    return PatternCandidate("IPO Base", base_high * 1.001, min(88.0, confidence), start, right, ["early post-IPO consolidation"])


def detect_base_on_base(closes: list[float], highs: list[float]) -> PatternCandidate | None:
    if len(closes) < 80:
        return None
    right = len(closes) - 1
    first_start = max(0, right - 80)
    if not _prior_uptrend(closes, first_start + 10):
        return None
    mid = right - 40
    first_high = max(highs[first_start:mid])
    first_low = min(closes[first_start:mid])
    second_high = max(highs[mid:right])
    second_low = min(closes[mid:right])
    first_depth = _max_drawdown_pct(first_high, first_low)
    second_depth = _max_drawdown_pct(second_high, second_low)
    if first_depth > 28 or second_depth > 18:
        return None
    if second_low < (first_low + (first_high - first_low) * 0.45):
        return None
    confidence = 62 + (12 if second_depth <= 12 else 5)
    return PatternCandidate("Base-on-Base", second_high * 1.001, min(90.0, confidence), first_start, right, ["second base stacked above first"])


def detect_high_tight_flag(closes: list[float], highs: list[float]) -> PatternCandidate | None:
    if len(closes) < 60:
        return None
    right = len(closes) - 1
    run_start = max(0, right - 55)
    run_mid = right - 15
    if run_mid <= run_start + 10:
        return None
    run_low = min(closes[run_start : run_start + 8])
    run_high = max(highs[run_start:run_mid])
    run_gain = ((run_high - run_low) / max(0.01, run_low)) * 100.0
    if run_gain < 100:
        return None
    flag_high = max(highs[run_mid : right + 1])
    flag_low = min(closes[run_mid : right + 1])
    flag_depth = _max_drawdown_pct(flag_high, flag_low)
    if flag_depth > 25:
        return None
    confidence = 72 + (8 if flag_depth <= 15 else 0)
    return PatternCandidate("High Tight Flag", flag_high * 1.001, min(99.0, confidence), run_start, right, ["100%+ run in 4-8 weeks", "tight flag"])


def detect_best_pattern(closes: list[float], highs: list[float], lows: list[float], volumes: list[float]) -> PatternCandidate | None:
    detectors = [
        detect_cup_with_handle(closes, highs, volumes),
        detect_cup_without_handle(closes, highs),
        detect_flat_base(closes, highs),
        detect_double_bottom(closes, highs),
        detect_ascending_base(closes, highs),
        detect_ipo_base(closes, highs),
        detect_base_on_base(closes, highs),
        detect_high_tight_flag(closes, highs),
    ]
    valid = [item for item in detectors if item is not None]
    if not valid:
        return None
    valid.sort(key=lambda item: item.confidence, reverse=True)
    best = valid[0]
    return best if best.confidence >= 72 else None
