from __future__ import annotations

import csv
import io
import re
import time
from urllib.request import Request, urlopen

from app.data.universe import FULL_US_UNIVERSE


NASDAQ_LISTED_URL = "https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt"
OTHER_LISTED_URL = "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt"
UNIVERSE_CACHE_SECONDS = 12 * 60 * 60
EXCLUDED_NAME_PARTS = (
    " warrant",
    " warrants",
    " unit",
    " units",
    " rights",
    " right",
    " preferred",
    " notes due",
    " bond",
    " etf",
    " exchange traded",
    " closed-end fund",
)

_cached_at = 0.0
_cached_symbols: list[str] = []


def _normalize_symbol(value: str) -> str:
    symbol = value.strip().upper().replace(".", "-")
    return symbol if re.fullmatch(r"[A-Z]{1,5}(?:-[A-Z])?", symbol) else ""


def _is_operating_equity(name: str, etf_flag: str, test_flag: str) -> bool:
    normalized_name = f" {name.strip().lower()}"
    if etf_flag.strip().upper() == "Y" or test_flag.strip().upper() == "Y":
        return False
    return not any(part in normalized_name for part in EXCLUDED_NAME_PARTS)


def _download_directory(url: str) -> list[dict[str, str]]:
    request = Request(url, headers={"User-Agent": "GrowthIntel market research contact: support@growthintel.app"})
    with urlopen(request, timeout=18) as response:
        text = response.read().decode("utf-8", errors="replace")
    return list(csv.DictReader(io.StringIO(text), delimiter="|"))


def current_us_equity_universe() -> list[str]:
    global _cached_at, _cached_symbols
    if _cached_symbols and time.time() - _cached_at < UNIVERSE_CACHE_SECONDS:
        return list(_cached_symbols)

    symbols: list[str] = []
    try:
        for row in _download_directory(NASDAQ_LISTED_URL):
            symbol = _normalize_symbol(row.get("Symbol", ""))
            if symbol and _is_operating_equity(
                row.get("Security Name", ""),
                row.get("ETF", ""),
                row.get("Test Issue", ""),
            ):
                symbols.append(symbol)

        for row in _download_directory(OTHER_LISTED_URL):
            symbol = _normalize_symbol(row.get("ACT Symbol", "") or row.get("NASDAQ Symbol", ""))
            if symbol and _is_operating_equity(
                row.get("Security Name", ""),
                row.get("ETF", ""),
                row.get("Test Issue", ""),
            ):
                symbols.append(symbol)
    except Exception:
        return list(FULL_US_UNIVERSE)

    deduped = list(dict.fromkeys(symbols))
    if len(deduped) < 3_000:
        return list(FULL_US_UNIVERSE)

    _cached_symbols = deduped
    _cached_at = time.time()
    return list(_cached_symbols)
